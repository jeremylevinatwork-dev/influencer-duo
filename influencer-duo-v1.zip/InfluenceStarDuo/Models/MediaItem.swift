import Foundation

/// One finished piece of media that lives on the device: a merged
/// dual-camera video or a photo taken in the app. The file itself lives
/// in the app's Documents/Media folder under `fileName`; this record is
/// the Library's index of it (persisted as library.json).
struct MediaItem: Identifiable, Codable, Equatable {
    enum Kind: String, Codable {
        case video
        case photo
    }

    var id: UUID
    var kind: Kind
    var fileName: String
    var createdAt: Date
    /// Video length in seconds; nil for photos.
    var duration: TimeInterval?
    /// Caption that goes with the post when this is shared or auto-posted.
    var caption: String
    /// A link the operator typed while filming (see LinkEvent). It is
    /// burned into the video as a visible chip AND appended to the post
    /// text when this auto-posts to Facebook, Instagram or TikTok.
    /// Nil when no link was added during the take.
    var link: String?
    /// Platform keys this item has already been posted to ("facebook",
    /// "instagram"). A post is never silently re-sent.
    var postedPlatforms: [String]

    init(id: UUID = UUID(),
         kind: Kind,
         fileName: String,
         createdAt: Date = Date(),
         duration: TimeInterval? = nil,
         caption: String,
         link: String? = nil,
         postedPlatforms: [String] = []) {
        self.id = id
        self.kind = kind
        self.fileName = fileName
        self.createdAt = createdAt
        self.duration = duration
        self.caption = caption
        self.link = link
        self.postedPlatforms = postedPlatforms
    }
}
