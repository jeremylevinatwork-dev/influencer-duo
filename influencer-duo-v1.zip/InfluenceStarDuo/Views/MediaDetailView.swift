import AVKit
import SwiftUI

/// One item, full screen: play the video or look at the photo, edit
/// the caption and link that go with the post, post it now to a
/// chosen account, share it anywhere, retry a failed post, or delete
/// it. The queue status for this item is always on screen — a failed
/// post shows its plain-words reason and a Retry button.
struct MediaDetailView: View {
    var item: MediaItem
    @ObservedObject var viewModel: LibraryViewModel
    @ObservedObject var subscription: SubscriptionService
    var proRequests: ProRequestStore

    @State private var caption: String
    @State private var link: String
    @State private var showShare = false
    @State private var showDeleteConfirm = false

    init(item: MediaItem, viewModel: LibraryViewModel, subscription: SubscriptionService, proRequests: ProRequestStore) {
        self.item = item
        self.viewModel = viewModel
        self.subscription = subscription
        self.proRequests = proRequests
        _caption = State(initialValue: item.caption)
        _link = State(initialValue: item.link ?? "")
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Brand.background.ignoresSafeArea()
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        preview
                        jobStatus
                        captionEditor
                        postSection
                        shareSection
                        deleteButton
                    }
                    .padding(16)
                }
            }
            .navigationTitle(item.kind == .video ? "Video" : "Photo")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(Brand.navy, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .sheet(isPresented: $showShare) {
                ShareSheet(items: [viewModel.library.mediaURL(for: item)])
            }
            .sheet(isPresented: $viewModel.showPaywall) {
                PaywallView(subscription: subscription, proRequests: proRequests)
            }
            .alert("Delete this \(item.kind == .video ? "video" : "photo")?", isPresented: $showDeleteConfirm) {
                Button("Delete", role: .destructive) {
                    viewModel.delete(item: currentItem)
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("It will be removed from the Library and any queued posts for it will be cancelled.")
            }
        }
    }

    private var currentItem: MediaItem {
        viewModel.library.item(id: item.id) ?? item
    }

    // MARK: - Preview

    @ViewBuilder
    private var preview: some View {
        if item.kind == .video {
            VideoPlayer(player: AVPlayer(url: viewModel.library.mediaURL(for: item)))
                .frame(height: 360)
                .clipShape(RoundedRectangle(cornerRadius: 12))
        } else if let uiImage = UIImage(contentsOfFile: viewModel.library.mediaURL(for: item).path) {
            Image(uiImage: uiImage)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(maxWidth: .infinity)
                .clipShape(RoundedRectangle(cornerRadius: 12))
        }
    }

    // MARK: - Queue status

    @ViewBuilder
    private var jobStatus: some View {
        let jobs = viewModel.jobs(for: currentItem)
        if !jobs.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                ForEach(jobs) { job in
                    HStack(alignment: .top, spacing: 10) {
                        Image(systemName: jobIcon(job.state))
                            .foregroundColor(jobColor(job.state))
                        VStack(alignment: .leading, spacing: 2) {
                            Text("\(platformLabel(job.platform)) — \(stateLabel(job.state))")
                                .font(.system(size: 14, weight: .bold))
                                .foregroundColor(.white)
                            if let error = job.lastError {
                                Text(error)
                                    .font(.system(size: 13))
                                    .foregroundColor(.white.opacity(0.75))
                            }
                        }
                        Spacer()
                        if job.state == .failed {
                            Button("Retry") { viewModel.retry(job: job) }
                                .font(.system(size: 13, weight: .bold))
                                .foregroundColor(.black)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 6)
                                .background(Brand.neonGradient)
                                .clipShape(Capsule())
                        }
                    }
                    .padding(12)
                    .background(Brand.navyLight)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                }
            }
        }
    }

    private func jobIcon(_ state: PostJob.State) -> String {
        switch state {
        case .queued: return "clock"
        case .uploading: return "arrow.up.circle"
        case .posted: return "checkmark.circle.fill"
        case .failed: return "exclamationmark.circle.fill"
        }
    }

    private func jobColor(_ state: PostJob.State) -> Color {
        switch state {
        case .queued: return Brand.gold
        case .uploading: return Brand.cyan
        case .posted: return .green
        case .failed: return .red
        }
    }

    private func stateLabel(_ state: PostJob.State) -> String {
        switch state {
        case .queued: return "Queued"
        case .uploading: return "Uploading"
        case .posted: return "Posted"
        case .failed: return "Failed"
        }
    }

    private func platformLabel(_ platform: PostJob.Platform) -> String {
        switch platform {
        case .facebook: return "Facebook"
        case .instagram: return "Instagram"
        case .tiktok: return "TikTok"
        }
    }

    // MARK: - Caption + link

    private var captionEditor: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("POST CAPTION")
                .font(.system(size: 12, weight: .bold))
                .foregroundColor(.white.opacity(0.6))
            TextField("Write the caption for this post…", text: $caption, axis: .vertical)
                .lineLimit(3...6)
                .padding(10)
                .background(Color.white.opacity(0.08))
                .foregroundColor(.white)
                .clipShape(RoundedRectangle(cornerRadius: 10))
            TextField("Link (optional)", text: $link)
                .keyboardType(.URL)
                .autocorrectionDisabled(true)
                .textInputAutocapitalization(.never)
                .padding(10)
                .background(Color.white.opacity(0.08))
                .foregroundColor(.white)
                .clipShape(RoundedRectangle(cornerRadius: 10))
            Button("Save caption") {
                viewModel.updateCaption(item: currentItem, caption: caption, link: link)
            }
            .font(.system(size: 14, weight: .bold))
            .foregroundColor(.black)
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
            .background(Brand.neonGradient)
            .clipShape(Capsule())
        }
    }

    // MARK: - Post now

    @ViewBuilder
    private var postSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("POST NOW")
                .font(.system(size: 12, weight: .bold))
                .foregroundColor(.white.opacity(0.6))
            if let limit = viewModel.postLimits(for: currentItem) {
                Text(limit)
                    .font(.system(size: 14))
                    .foregroundColor(.white.opacity(0.8))
                    .padding(12)
                    .background(Brand.navyLight)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
            }
            let postable = viewModel.postableAccounts(for: currentItem)
            if !postable.isEmpty {
                Text("Only the accounts you switched on in Accounts are listed. Nothing posts anywhere you didn't choose.")
                    .font(.system(size: 13))
                    .foregroundColor(.white.opacity(0.7))
                ForEach(postable) { account in
                    Button {
                        viewModel.postNow(item: currentItem, to: account)
                    } label: {
                        HStack {
                            Text("Post to \(account.displayName)")
                                .font(.system(size: 15, weight: .bold))
                            Spacer()
                            Text(account.platformLabel)
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundColor(.white.opacity(0.7))
                        }
                        .foregroundColor(.white)
                        .padding(14)
                        .background(Brand.navyLight)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    // MARK: - Share / delete

    private var shareSection: some View {
        Button {
            showShare = true
        } label: {
            Label("Share…", systemImage: "square.and.arrow.up")
                .font(.system(size: 15, weight: .bold))
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(Color.white.opacity(0.16))
                .clipShape(RoundedRectangle(cornerRadius: 12))
        }
        .buttonStyle(.plain)
    }

    private var deleteButton: some View {
        Button(role: .destructive) {
            showDeleteConfirm = true
        } label: {
            Label("Delete", systemImage: "trash")
                .font(.system(size: 15, weight: .bold))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(Color.red.opacity(0.15))
                .clipShape(RoundedRectangle(cornerRadius: 12))
        }
        .buttonStyle(.plain)
    }
}
