import AVFoundation
import CoreGraphics
import Foundation
import Photos
import UIKit

/// Turns raw captures into finished media: merges the two dual-camera
/// files into one video (main picture full-frame, influencer as
/// picture-in-picture), burns the live lower third into the frames
/// where it was on air, and saves to the Camera Roll.
///
/// Every step fails soft: a failed merge or burn returns the original
/// recording instead of nothing. A finished take is never lost because
/// the polish step broke.
enum RecordingService {

    struct LowerThirdContent {
        let name: String
        let title: String
    }

    /// A picked picture, ready to burn, with the on-screen rectangle
    /// the operator placed it in (normalized, origin top-left).
    struct PictureOverlay {
        var image: UIImage
        var rect: CGRect
        var start: TimeInterval
        var end: TimeInterval
    }

    // MARK: - Video

    /// Merges a dual recording and burns the live overlays in,
    /// returning the finished file. `pipURL` is nil for single-camera
    /// takes. Returns the best available file on any failure: the
    /// merged file, the main file with the overlays burned, or the raw
    /// main file.
    static func finalize(mainURL: URL,
                         pipURL: URL?,
                         lowerThird: LowerThirdContent,
                         events: [LowerThirdEvent],
                         captions: [CaptionEvent] = [],
                         pictures: [PictureOverlay] = [],
                         links: [LinkEvent] = []) async -> URL {
        let mainUpright = await normalizeOrientation(mainURL) ?? mainURL
        let pipUpright: URL?
        if let pipURL {
            pipUpright = await normalizeOrientation(pipURL)
        } else {
            pipUpright = nil
        }
        // Nothing to compose: no second camera and no overlay on air
        // at any point — skip the re-encode entirely.
        if pipUpright == nil && events.isEmpty && captions.isEmpty && pictures.isEmpty && links.isEmpty {
            return mainUpright
        }
        if let finished = await compose(mainURL: mainUpright,
                                        pipURL: pipUpright,
                                        lowerThird: lowerThird,
                                        events: events,
                                        captions: captions,
                                        pictures: pictures,
                                        links: links) {
            return finished
        }
        return mainUpright
    }

    /// One export that does the whole job: main track full-frame, PiP
    /// track top-right when there is one, sound from the main file
    /// (falling back to the PiP file), and the lower third drawn over
    /// the stretches it was on air. Nil when the export fails.
    private static func compose(mainURL: URL,
                                pipURL: URL?,
                                lowerThird: LowerThirdContent,
                                events: [LowerThirdEvent],
                                captions: [CaptionEvent],
                                pictures: [PictureOverlay],
                                links: [LinkEvent]) async -> URL? {
        let mainAsset = AVURLAsset(url: mainURL)
        let pipAsset = pipURL.map { AVURLAsset(url: $0) }
        do {
            let mainDuration = try await mainAsset.load(.duration)
            guard mainDuration.seconds > 0.5 else { return nil }
            guard let mainVideo = try await mainAsset.loadTracks(withMediaType: .video).first else { return nil }
            let mainSize = try await mainVideo.load(.naturalSize)
            guard mainSize.width > 0, mainSize.height > 0 else { return nil }

            var duration = mainDuration
            var pipVideo: AVAssetTrack?
            if let pipAsset {
                let pipDuration = try await pipAsset.load(.duration)
                duration = min(mainDuration, pipDuration)
                guard duration.seconds > 0.5 else { return nil }
                pipVideo = try await pipAsset.loadTracks(withMediaType: .video).first
                guard pipVideo != nil else { return nil }
            }

            let composition = AVMutableComposition()
            guard let compMain = composition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid) else { return nil }
            try compMain.insertTimeRange(CMTimeRange(start: .zero, duration: duration), of: mainVideo, at: .zero)
            var compPip: AVMutableCompositionTrack?
            if let pipVideo {
                guard let track = composition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid) else { return nil }
                try track.insertTimeRange(CMTimeRange(start: .zero, duration: duration), of: pipVideo, at: .zero)
                compPip = track
            }
            // Sound from the main file; the PiP file only as a fallback.
            if let mainAudio = try await mainAsset.loadTracks(withMediaType: .audio).first,
               let compAudio = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) {
                try compAudio.insertTimeRange(CMTimeRange(start: .zero, duration: duration), of: mainAudio, at: .zero)
            } else if let pipAsset,
                      let pipAudio = try await pipAsset.loadTracks(withMediaType: .audio).first,
                      let compAudio = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) {
                try compAudio.insertTimeRange(CMTimeRange(start: .zero, duration: duration), of: pipAudio, at: .zero)
            }

            let videoComposition = AVMutableVideoComposition()
            videoComposition.renderSize = mainSize
            videoComposition.frameDuration = CMTime(value: 1, timescale: 30)
            let instruction = AVMutableVideoCompositionInstruction()
            instruction.timeRange = CMTimeRange(start: .zero, duration: duration)
            let mainLayerInstruction = AVMutableVideoCompositionLayerInstruction(assetTrack: compMain)
            var layerInstructions: [AVMutableVideoCompositionLayerInstruction] = [mainLayerInstruction]
            if let compPip, let pipVideo {
                let pipSize = try await pipVideo.load(.naturalSize)
                guard pipSize.width > 0, pipSize.height > 0 else { return nil }
                // PiP: 30% of the frame width, top-right, small margin.
                let pipWidth = mainSize.width * 0.30
                let pipHeight = pipWidth * pipSize.height / pipSize.width
                let pipScale = pipWidth / pipSize.width
                let margin = mainSize.width * 0.03
                var pipTransform = CGAffineTransform(scaleX: pipScale, y: pipScale)
                pipTransform = pipTransform.concatenating(CGAffineTransform(
                    translationX: mainSize.width - pipWidth - margin,
                    y: margin * 2))
                _ = pipHeight
                let pipLayerInstruction = AVMutableVideoCompositionLayerInstruction(assetTrack: compPip)
                pipLayerInstruction.setTransform(pipTransform, at: .zero)
                // First instruction renders frontmost: PiP on top.
                layerInstructions = [pipLayerInstruction, mainLayerInstruction]
            }
            instruction.layerInstructions = layerInstructions
            videoComposition.instructions = [instruction]

            // Overlay: the brand bug, plus the lower third, captions,
            // pictures and link chips over the stretches each was on air.
            let parentLayer = CALayer()
            parentLayer.frame = CGRect(origin: .zero, size: mainSize)
            let videoLayer = CALayer()
            videoLayer.frame = parentLayer.frame
            parentLayer.addSublayer(videoLayer)
            for layer in overlayLayers(size: mainSize, lowerThird: lowerThird, events: events,
                                       captions: captions, pictures: pictures, links: links,
                                       duration: duration.seconds) {
                parentLayer.addSublayer(layer)
            }
            videoComposition.animationTool = AVVideoCompositionCoreAnimationTool(
                postProcessingAsVideoLayer: videoLayer, in: parentLayer)

            guard let exporter = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetHighestQuality) else { return nil }
            let outURL = FileManager.default.temporaryDirectory
                .appendingPathComponent("isd-final-\(UUID().uuidString).mp4")
            exporter.outputURL = outURL
            exporter.outputFileType = .mp4
            exporter.videoComposition = videoComposition
            await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
                exporter.exportAsynchronously { continuation.resume() }
            }
            return exporter.status == .completed ? outURL : nil
        } catch {
            return nil
        }
    }

    /// Bakes a video track's rotation into the pixels, so every later
    /// step works on upright video whose own transform is identity.
    /// Returns the input URL when the footage is already upright, and
    /// nil on failure (the caller then works with the original file).
    private static func normalizeOrientation(_ videoURL: URL) async -> URL? {
        let asset = AVURLAsset(url: videoURL)
        do {
            let duration = try await asset.load(.duration)
            guard duration.seconds > 0 else { return nil }
            guard let sourceVideo = try await asset.loadTracks(withMediaType: .video).first else { return nil }
            let transform = try await sourceVideo.load(.preferredTransform)
            if transform.isIdentity {
                return videoURL
            }
            let natural = try await sourceVideo.load(.naturalSize)
            let composition = AVMutableComposition()
            guard let compVideo = composition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid) else { return nil }
            try compVideo.insertTimeRange(CMTimeRange(start: .zero, duration: duration), of: sourceVideo, at: .zero)
            if let sourceAudio = try await asset.loadTracks(withMediaType: .audio).first,
               let compAudio = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) {
                try compAudio.insertTimeRange(CMTimeRange(start: .zero, duration: duration), of: sourceAudio, at: .zero)
            }
            let displayRect = CGRect(origin: .zero, size: natural).applying(transform)
            let renderSize = CGSize(width: abs(displayRect.width), height: abs(displayRect.height))
            guard renderSize.width > 0, renderSize.height > 0 else { return nil }
            var rebased = transform
            rebased = rebased.concatenating(CGAffineTransform(
                translationX: -displayRect.origin.x, y: -displayRect.origin.y))
            let videoComposition = AVMutableVideoComposition()
            videoComposition.renderSize = renderSize
            videoComposition.frameDuration = CMTime(value: 1, timescale: 30)
            let instruction = AVMutableVideoCompositionInstruction()
            instruction.timeRange = CMTimeRange(start: .zero, duration: duration)
            let layerInstruction = AVMutableVideoCompositionLayerInstruction(assetTrack: compVideo)
            layerInstruction.setTransform(rebased, at: .zero)
            instruction.layerInstructions = [layerInstruction]
            videoComposition.instructions = [instruction]
            guard let exporter = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetHighestQuality) else { return nil }
            let outURL = FileManager.default.temporaryDirectory
                .appendingPathComponent("isd-upright-\(UUID().uuidString).mp4")
            exporter.outputURL = outURL
            exporter.outputFileType = .mp4
            exporter.videoComposition = videoComposition
            await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
                exporter.exportAsynchronously { continuation.resume() }
            }
            return exporter.status == .completed ? outURL : nil
        } catch {
            return nil
        }
    }

    // MARK: - Overlay layers (Core Animation space: origin bottom-left)

    /// Brand bug (always on) plus one layer group per live overlay,
    /// each visible only for its own time range. Core Animation space
    /// here: origin bottom-left, so top-left screen rectangles are
    /// flipped when they are converted.
    private static func overlayLayers(size: CGSize,
                                      lowerThird: LowerThirdContent,
                                      events: [LowerThirdEvent],
                                      captions: [CaptionEvent],
                                      pictures: [PictureOverlay],
                                      links: [LinkEvent],
                                      duration: Double) -> [CALayer] {
        var layers: [CALayer] = []
        let scale = size.width / 1170.0

        // Brand bug, top-left, small and quiet.
        let bug = CATextLayer()
        bug.string = "\u{2605} INFLUENCER DÚO"
        bug.font = "Helvetica-Bold" as CFTypeRef
        bug.fontSize = 30 * scale
        bug.foregroundColor = UIColor.white.cgColor
        bug.shadowColor = UIColor.black.cgColor
        bug.shadowOpacity = 0.6
        bug.shadowOffset = CGSize(width: 0, height: -2 * scale)
        bug.contentsScale = 2.0
        bug.frame = CGRect(x: 28 * scale, y: size.height - 58 * scale,
                           width: size.width - 56 * scale, height: 40 * scale)
        layers.append(bug)

        // A shared fade: in fast, hold, out fast. Every timed overlay
        // uses the same shape so nothing pops on or off mid-word.
        func fadeInOut(for layer: CALayer, start: TimeInterval, end: TimeInterval) {
            let length = max(0.5, end - start)
            let fade = CAKeyframeAnimation(keyPath: "opacity")
            fade.values = [0.0, 1.0, 1.0, 0.0]
            fade.keyTimes = [0, 0.04, 0.96, 1]
            fade.duration = length
            fade.beginTime = AVCoreAnimationBeginTimeAtZero + start
            fade.isRemovedOnCompletion = false
            fade.fillMode = .both
            layer.opacity = 0
            layer.add(fade, forKey: "onAir")
        }

        if !lowerThird.name.isEmpty || !lowerThird.title.isEmpty {
            for event in events {
                guard event.start < duration, event.end > event.start else { continue }
                // The event's own snapshot wins; the shared content is
                // the fallback for events fired before a name was typed.
                let content = (event.name.isEmpty && event.title.isEmpty)
                    ? lowerThird
                    : LowerThirdContent(name: event.name, title: event.title)
                let group = lowerThirdGroup(size: size, lowerThird: content, scale: scale)
                fadeInOut(for: group, start: event.start, end: event.end)
                layers.append(group)
            }
        }

        // Captions: big bold text, centred, upper-middle of frame.
        for caption in captions where !caption.text.isEmpty {
            guard caption.start < duration, caption.end > caption.start else { continue }
            let fontSize = fitSize(caption.text, base: 64 * scale, maxWidth: size.width - 80 * scale)
            let text = CATextLayer()
            text.string = caption.text
            text.font = "Helvetica-Bold" as CFTypeRef
            text.fontSize = fontSize
            text.foregroundColor = UIColor.white.cgColor
            text.shadowColor = UIColor.black.cgColor
            text.shadowOpacity = 0.75
            text.shadowOffset = CGSize(width: 0, height: -3 * scale)
            text.alignmentMode = .center
            text.contentsScale = 2.0
            text.frame = CGRect(x: 40 * scale, y: size.height * 0.62,
                                width: size.width - 80 * scale, height: 90 * scale)
            fadeInOut(for: text, start: caption.start, end: caption.end)
            layers.append(text)
        }

        // Link chips: a navy pill with the URL, top-centre under the bug.
        for link in links where !link.url.isEmpty {
            guard link.start < duration, link.end > link.start else { continue }
            let label = "\u{1F517} " + link.url
            let fontSize: CGFloat = 34 * scale
            let font = UIFont.boldSystemFont(ofSize: fontSize)
            let textWidth = (label as NSString).size(withAttributes: [.font: font]).width
            let pillWidth = min(size.width - 56 * scale, textWidth + 44 * scale)
            let pillHeight: CGFloat = 56 * scale
            let group = CALayer()
            group.frame = CGRect(x: (size.width - pillWidth) / 2,
                                 y: size.height - 58 * scale - pillHeight - 12 * scale,
                                 width: pillWidth, height: pillHeight)
            let background = CALayer()
            background.frame = group.bounds
            background.backgroundColor = UIColor(red: 0.043, green: 0.071, blue: 0.125, alpha: 0.92).cgColor
            background.cornerRadius = pillHeight / 2
            group.addSublayer(background)
            let text = CATextLayer()
            text.string = label
            text.font = "Helvetica-Bold" as CFTypeRef
            text.fontSize = fontSize
            text.foregroundColor = UIColor.white.cgColor
            text.alignmentMode = .center
            text.contentsScale = 2.0
            text.frame = CGRect(x: 0, y: pillHeight * 0.18, width: pillWidth, height: pillHeight * 0.7)
            group.addSublayer(text)
            fadeInOut(for: group, start: link.start, end: link.end)
            layers.append(group)
        }

        // Pictures: the operator's placed rectangle, flipped from
        // top-left screen space to bottom-left video space.
        for picture in pictures {
            guard picture.start < duration, picture.end > picture.start,
                  let cgImage = picture.image.cgImage else { continue }
            let rect = picture.rect
            let frame = CGRect(x: rect.minX * size.width,
                               y: size.height - rect.maxY * size.height,
                               width: rect.width * size.width,
                               height: rect.height * size.height)
            guard frame.width > 8, frame.height > 8 else { continue }
            let layer = CALayer()
            layer.contents = cgImage
            layer.contentsGravity = .resizeAspect
            layer.frame = frame
            layer.shadowColor = UIColor.black.cgColor
            layer.shadowOpacity = 0.35
            layer.shadowOffset = CGSize(width: 0, height: -4 * scale)
            fadeInOut(for: layer, start: picture.start, end: picture.end)
            layers.append(layer)
        }
        return layers
    }

    /// One lower third: gold bar on the left, name on navy, title on
    /// white, sitting just above the bottom edge.
    private static func lowerThirdGroup(size: CGSize,
                                        lowerThird: LowerThirdContent,
                                        scale: CGFloat) -> CALayer {
        let group = CALayer()
        let nameH = 76 * scale
        let titleH = lowerThird.title.isEmpty ? 0 : 56 * scale
        let totalH = nameH + titleH
        let width = size.width - 56 * scale
        group.frame = CGRect(x: 28 * scale, y: 28 * scale, width: width, height: totalH)

        let navy = UIColor(red: 0.043, green: 0.071, blue: 0.125, alpha: 0.94).cgColor
        let gold = UIColor(red: 0.949, green: 0.753, blue: 0.094, alpha: 1).cgColor

        let nameBand = CALayer()
        nameBand.frame = CGRect(x: 0, y: titleH, width: width, height: nameH)
        nameBand.backgroundColor = navy
        group.addSublayer(nameBand)
        if titleH > 0 {
            let titleBand = CALayer()
            titleBand.frame = CGRect(x: 0, y: 0, width: width, height: titleH)
            titleBand.backgroundColor = UIColor.white.cgColor
            group.addSublayer(titleBand)
        }
        let bar = CALayer()
        bar.frame = CGRect(x: 0, y: 0, width: 12 * scale, height: totalH)
        bar.backgroundColor = gold
        group.addSublayer(bar)

        func textLayer(_ string: String, y: CGFloat, height: CGFloat, size fontSize: CGFloat, color: CGColor) -> CATextLayer {
            let layer = CATextLayer()
            layer.string = string
            layer.font = "Helvetica-Bold" as CFTypeRef
            layer.fontSize = fontSize
            layer.foregroundColor = color
            layer.contentsScale = 2.0
            layer.frame = CGRect(x: 26 * scale, y: y, width: width - 40 * scale, height: height)
            return layer
        }
        if !lowerThird.name.isEmpty {
            group.addSublayer(textLayer(lowerThird.name.uppercased(),
                                        y: titleH + nameH * 0.16, height: nameH * 0.7,
                                        size: fitSize(lowerThird.name.uppercased(), base: 52 * scale, maxWidth: width - 40 * scale),
                                        color: UIColor.white.cgColor))
        }
        if !lowerThird.title.isEmpty {
            group.addSublayer(textLayer(lowerThird.title,
                                        y: titleH * 0.14, height: titleH * 0.72,
                                        size: fitSize(lowerThird.title, base: 38 * scale, maxWidth: width - 40 * scale),
                                        color: UIColor(red: 0.043, green: 0.071, blue: 0.125, alpha: 1).cgColor))
        }
        return group
    }

    /// Largest size at or below `base` whose text fits `maxWidth`.
    private static func fitSize(_ string: String, base: CGFloat, maxWidth: CGFloat) -> CGFloat {
        var size = base
        while size > base * 0.45 {
            let font = UIFont.boldSystemFont(ofSize: size)
            let width = (string as NSString).size(withAttributes: [.font: font]).width
            if width <= maxWidth { break }
            size -= 2
        }
        return size
    }

    // MARK: - Photo

    /// Burns the live overlays into a photo so it looks like the
    /// screen at the moment it was taken: lower third, caption, link
    /// chip and picture overlay, each only if it was on air. Returns
    /// the plain photo when nothing was on air.
    static func finalizePhoto(data: Data,
                              lowerThird: LowerThirdContent? = nil,
                              caption: String? = nil,
                              picture: (image: UIImage, rect: CGRect)? = nil,
                              link: String? = nil) -> UIImage? {
        guard let base = UIImage(data: data) else { return nil }
        let hasLowerThird = lowerThird.map { !$0.name.isEmpty || !$0.title.isEmpty } ?? false
        let hasCaption = !(caption ?? "").isEmpty
        let hasLink = !(link ?? "").isEmpty
        guard hasLowerThird || hasCaption || picture != nil || hasLink else { return base }
        let size = base.size
        let scale = size.width / 1170.0
        let renderer = UIGraphicsImageRenderer(size: size)
        return renderer.image { _ in
            base.draw(in: CGRect(origin: .zero, size: size))
            let navy = UIColor(red: 0.043, green: 0.071, blue: 0.125, alpha: 0.94)
            let gold = UIColor(red: 0.949, green: 0.753, blue: 0.094, alpha: 1)
            // Picture overlay, at the rectangle the operator placed.
            if let picture {
                let rect = CGRect(x: picture.rect.minX * size.width,
                                  y: picture.rect.minY * size.height,
                                  width: picture.rect.width * size.width,
                                  height: picture.rect.height * size.height)
                picture.image.draw(in: rect)
            }
            // Caption, big and centred, upper-middle.
            if let caption, !caption.isEmpty {
                let font = UIFont.boldSystemFont(ofSize: fitSize(caption, base: 64 * scale, maxWidth: size.width - 80 * scale))
                let textSize = (caption as NSString).size(withAttributes: [.font: font])
                // A soft shadow so white text reads on any background.
                let shadow = NSShadow()
                shadow.shadowOffset = CGSize(width: 0, height: 3 * scale)
                shadow.shadowBlurRadius = 6 * scale
                shadow.shadowColor = UIColor.black.withAlphaComponent(0.75)
                let shadowAttrs: [NSAttributedString.Key: Any] = [
                    .font: font, .foregroundColor: UIColor.white, .shadow: shadow
                ]
                (caption as NSString).draw(at: CGPoint(x: (size.width - textSize.width) / 2, y: size.height * 0.30), withAttributes: shadowAttrs)
            }
            // Link chip, top-centre under the bug.
            if let link, !link.isEmpty {
                let label = "\u{1F517} " + link
                let font = UIFont.boldSystemFont(ofSize: 34 * scale)
                let textSize = (label as NSString).size(withAttributes: [.font: font])
                let pillWidth = min(size.width - 56 * scale, textSize.width + 44 * scale)
                let pillHeight: CGFloat = 56 * scale
                let pill = CGRect(x: (size.width - pillWidth) / 2, y: 70 * scale, width: pillWidth, height: pillHeight)
                let path = UIBezierPath(roundedRect: pill, cornerRadius: pillHeight / 2)
                UIColor(red: 0.043, green: 0.071, blue: 0.125, alpha: 0.92).setFill()
                path.fill()
                let attrs: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: UIColor.white]
                (label as NSString).draw(at: CGPoint(x: pill.minX + (pillWidth - textSize.width) / 2, y: pill.minY + pillHeight * 0.18), withAttributes: attrs)
            }
            // Lower third, bottom edge.
            if let lowerThird, hasLowerThird {
                let nameH = 76 * scale
                let titleH = lowerThird.title.isEmpty ? 0 : 56 * scale
                let totalH = nameH + titleH
                let width = size.width - 56 * scale
                let bottomY = size.height - 28 * scale - totalH
                if titleH > 0 {
                    UIColor.white.setFill()
                    UIRectFill(CGRect(x: 28 * scale, y: bottomY, width: width, height: titleH))
                    let titleFont = UIFont.boldSystemFont(ofSize: fitSize(lowerThird.title, base: 38 * scale, maxWidth: width - 40 * scale))
                    let titleAttrs: [NSAttributedString.Key: Any] = [.font: titleFont, .foregroundColor: navy]
                    (lowerThird.title as NSString).draw(
                        at: CGPoint(x: 28 * scale + 26 * scale, y: bottomY + titleH * 0.14),
                        withAttributes: titleAttrs)
                }
                navy.setFill()
                UIRectFill(CGRect(x: 28 * scale, y: bottomY + titleH, width: width, height: nameH))
                if !lowerThird.name.isEmpty {
                    let nameFont = UIFont.boldSystemFont(ofSize: fitSize(lowerThird.name.uppercased(), base: 52 * scale, maxWidth: width - 40 * scale))
                    let nameAttrs: [NSAttributedString.Key: Any] = [.font: nameFont, .foregroundColor: UIColor.white]
                    (lowerThird.name.uppercased() as NSString).draw(
                        at: CGPoint(x: 28 * scale + 26 * scale, y: bottomY + titleH + nameH * 0.16),
                        withAttributes: nameAttrs)
                }
                gold.setFill()
                UIRectFill(CGRect(x: 28 * scale, y: bottomY, width: 12 * scale, height: totalH))
            }
            // Brand bug, top-left.
            let bugAttrs: [NSAttributedString.Key: Any] = [
                .font: UIFont.boldSystemFont(ofSize: 30 * scale),
                .foregroundColor: UIColor.white
            ]
            ("\u{2605} INFLUENCER DÚO" as NSString).draw(
                at: CGPoint(x: 28 * scale, y: 28 * scale), withAttributes: bugAttrs)
        }
    }

    // MARK: - Save to Camera Roll

    static func saveVideoToLibrary(_ url: URL) async -> Bool {
        let status = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
        guard status == .authorized || status == .limited else { return false }
        return await withCheckedContinuation { continuation in
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: url)
            }) { ok, _ in
                continuation.resume(returning: ok)
            }
        }
    }

    static func saveImageToLibrary(_ image: UIImage) async -> Bool {
        let status = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
        guard status == .authorized || status == .limited else { return false }
        return await withCheckedContinuation { continuation in
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAsset(from: image)
            }) { ok, _ in
                continuation.resume(returning: ok)
            }
        }
    }

    static func videoDuration(_ url: URL) async -> TimeInterval? {
        let asset = AVURLAsset(url: url)
        do {
            let duration = try await asset.load(.duration)
            return duration.seconds > 0 ? duration.seconds : nil
        } catch {
            return nil
        }
    }
}
