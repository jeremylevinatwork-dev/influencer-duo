import Foundation
import UIKit

/// The Camera screen's brain. It owns the take: recording state, the
/// elapsed clock, every live overlay's on-air timeline, Talent Flip,
/// and the finish flow (merge, burn, save, queue auto-posts).
///
/// The design rule for this screen: the OPERATOR behind the phone
/// runs the show while recording. Every control here is one tap, works
/// mid-take, and never stops the recording to do its job. The person
/// on camera does nothing — in Talent Flip mode they only get a huge
/// STOP button and the volume buttons.
final class CameraViewModel: ObservableObject {
    let camera: CameraService
    private let library: LibraryStore
    private let posting: PostingService
    private let network: NetworkMonitor
    private let subscription: SubscriptionService
    private let accounts: AccountStore
    private let volumeButtons = VolumeButtonObserver()

    // MARK: - Take state

    @Published private(set) var isRecording = false
    @Published private(set) var elapsed: TimeInterval = 0
    @Published private(set) var isFinishing = false
    /// A short plain-words note shown at the bottom of the screen.
    @Published var toast: String?
    /// True when a Pro feature was tapped without Pro: the Camera
    /// screen shows the paywall sheet.
    @Published var showPaywall = false

    // MARK: - Live overlays (operator-fired, mid-take)

    /// The lower third's text, typed by the operator.
    @Published var lowerThird = LowerThird(name: "", title: "")
    @Published private(set) var lowerThirdOnAir = false
    @Published var captionText = ""
    @Published private(set) var captionOnAir = false
    @Published var linkText = ""
    @Published private(set) var linkOnAir = false

    /// The picture the operator picked, on screen now. Its rectangle
    /// is normalized to the preview (origin top-left, 0...1).
    @Published var pictureImage: UIImage?
    @Published var pictureRect = CGRect(x: 0.60, y: 0.10, width: 0.32, height: 0.18)
    @Published private(set) var pictureOnAir = false

    /// The link that goes on the finished item, so auto-posts carry it
    /// in the post text. Set when a link is fired; the last one wins.
    @Published private(set) var linkForPost: String?

    // MARK: - Talent Flip

    /// True when the phone is turned around facing the influencer:
    /// front camera main, monitor on their side, operator controls
    /// hidden. The take keeps recording through the flip and back.
    ///
    /// LIMIT (settled, do not re-litigate): the Duo phone's OUTER
    /// display / Duo Preview belongs to Apple's Camera app only.
    /// There is no third-party API for it, so this app cannot turn it
    /// on or show anything on it. Flip mode on the main screen is the
    /// talent monitor in this app.
    @Published private(set) var isTalentFlipped = false
    /// The front camera's screen glow — the "front light". It lights
    /// whoever the front camera is pointed at.
    @Published var frontLightOn = false

    // MARK: - Timelines (built during the take, burned at the end)

    private var lowerThirdEvents: [LowerThirdEvent] = []
    private var lowerThirdOpen: LowerThirdEvent?
    private var captionEvents: [CaptionEvent] = []
    private var captionOpen: CaptionEvent?
    private var linkEvents: [LinkEvent] = []
    private var linkOpen: LinkEvent?
    private var pictureEvents: [ImageOverlayEvent] = []
    private var pictureOpen: ImageOverlayEvent?
    /// The image for each picture event, by event id. Held in memory
    /// for the take — a take is finalized before the app can lose it.
    private var pictureImages: [UUID: UIImage] = [:]
    /// The caption text that becomes the post caption (the creator's
    /// words for this take). The last caption fired wins.
    private var lastCaptionText = ""

    private var recordingStart: Date?
    private var elapsedTimer: Timer?
    private var volumeActive = false

    init(camera: CameraService, library: LibraryStore, posting: PostingService, network: NetworkMonitor, subscription: SubscriptionService, accounts: AccountStore) {
        self.camera = camera
        self.library = library
        self.posting = posting
        self.network = network
        self.subscription = subscription
        self.accounts = accounts
    }

    // MARK: - Lifecycle

    func onAppear() {
        camera.resumeIfNeeded()
        startVolumeButtons()
    }

    func onDisappear() {
        stopVolumeButtons()
    }

    private func startVolumeButtons() {
        guard !volumeActive else { return }
        volumeActive = true
        volumeButtons.onPress = { [weak self] in
            self?.toggleRecording()
        }
        volumeButtons.start()
    }

    private func stopVolumeButtons() {
        guard volumeActive else { return }
        volumeActive = false
        volumeButtons.stop()
    }

    // MARK: - Recording

    /// One tap: start if stopped, stop if recording. Also what the
    /// volume buttons call. Never does anything else mid-take.
    func toggleRecording() {
        if isRecording {
            stopRecording()
        } else {
            startRecording()
        }
    }

    func startRecording() {
        guard !isRecording, !isFinishing, camera.isRunning else { return }
        resetTimelines()
        recordingStart = Date()
        elapsed = 0
        isRecording = true
        startElapsedTimer()
        camera.startRecording()
        toast = nil
    }

    func stopRecording() {
        guard isRecording else { return }
        isRecording = false
        isFinishing = true
        stopElapsedTimer()
        let finalElapsed = elapsed
        closeOpenOverlays(at: finalElapsed)
        let frontWasMain = camera.mainIsFront
        let multiCam = camera.multiCamActive
        camera.stopRecording { [weak self] backURL, frontURL in
            guard let self else { return }
            Task { await self.finishTake(backURL: backURL, frontURL: frontURL, frontWasMain: frontWasMain, multiCam: multiCam) }
        }
    }

    /// Merges the two files, burns the overlays, saves the finished
    /// video to the Library and the Camera Roll, and queues auto-posts
    /// to every account the user switched on. Nothing here can lose
    /// the take: a failed merge or burn still saves the raw main file.
    private func finishTake(backURL: URL?, frontURL: URL?, frontWasMain: Bool, multiCam: Bool) async {
        defer {
            Task { @MainActor in
                self.isFinishing = false
                if self.isTalentFlipped {
                    self.flipBackToOperator()
                }
            }
        }
        let mainURL = frontWasMain ? (frontURL ?? backURL) : backURL
        let pipURL = frontWasMain ? backURL : frontURL
        guard let mainURL else {
            await MainActor.run { toast = "The recording didn't save — nothing was written. Try again." }
            return
        }
        let pictures: [RecordingService.PictureOverlay] = pictureEvents.compactMap { event in
            guard let image = pictureImages[event.id] else { return nil }
            return RecordingService.PictureOverlay(image: image, rect: event.rect, start: event.start, end: event.end)
        }
        let lowerThirdContent = RecordingService.LowerThirdContent(name: lowerThird.name, title: lowerThird.title)
        let finishedURL = await RecordingService.finalize(
            mainURL: mainURL,
            pipURL: multiCam ? pipURL : nil,
            lowerThird: lowerThirdContent,
            events: lowerThirdEvents,
            captions: captionEvents,
            pictures: pictures,
            links: linkEvents)
        let duration = await RecordingService.videoDuration(finishedURL)
        let postCaption = lastCaptionText
        guard let item = library.addVideoFile(finishedURL, duration: duration, caption: postCaption) else {
            await MainActor.run { toast = "The video finished but couldn't be saved to the Library." }
            return
        }
        if let link = linkForPost {
            var copy = item
            copy.link = link
            library.update(copy)
        }
        let savedToPhotos = await RecordingService.saveVideoToLibrary(finishedURL)
        let queued = posting.enqueueAutoPosts(for: library.item(id: item.id) ?? item)
        if !queued.isEmpty {
            posting.processOutbox()
        }
        let destinationNames = queued.compactMap { job in
            posting.accountName(for: job.accountID)
        }
        let hasAutoPostAccounts = accounts.accounts.contains { $0.autoPost }
        await MainActor.run {
            if !queued.isEmpty {
                if network.isOnline {
                    toast = "Saved. Posting to \(destinationNames.joined(separator: ", "))."
                } else {
                    toast = "Saved. You're offline — it will post to \(destinationNames.joined(separator: ", ")) when you're back online."
                }
            } else if !subscription.isPro && hasAutoPostAccounts {
                toast = "Saved to Library. Auto-post needs Pro — tap PRO to unlock it."
            } else if savedToPhotos {
                toast = "Saved to Library and Photos."
            } else {
                toast = "Saved to Library. (Photos needs permission — check Settings.)"
            }
        }
        // The raw files were only a means to the finished video.
        try? FileManager.default.removeItem(at: mainURL)
        if let pipURL { try? FileManager.default.removeItem(at: pipURL) }
    }

    // MARK: - Photo

    /// A still from whichever camera is main right now. The photo
    /// looks like the screen at that moment: any overlay on air is
    /// burned in. Never stops a recording.
    func takePhoto() {
        guard camera.isRunning, !isFinishing else { return }
        camera.capturePhoto { [weak self] data in
            guard let self, let data else {
                Task { @MainActor in self?.toast = "Couldn't take the photo." }
                return
            }
            Task {
                let lowerThirdContent = self.lowerThirdOnAir
                    ? RecordingService.LowerThirdContent(name: self.lowerThird.name, title: self.lowerThird.title)
                    : nil
                let picture: (image: UIImage, rect: CGRect)? = {
                    guard self.pictureOnAir, let image = self.pictureImage else { return nil }
                    return (image, self.pictureRect)
                }()
                let image = RecordingService.finalizePhoto(
                    data: data,
                    lowerThird: lowerThirdContent,
                    caption: self.captionOnAir ? self.captionText : nil,
                    picture: picture,
                    link: self.linkOnAir ? self.linkText : nil)
                guard let image else {
                    await MainActor.run { self.toast = "Couldn't take the photo." }
                    return
                }
                guard let item = self.library.addPhotoImage(image, caption: "") else {
                    await MainActor.run { self.toast = "The photo couldn't be saved." }
                    return
                }
                if let link = self.linkForPost {
                    var copy = item
                    copy.link = link
                    self.library.update(copy)
                }
                let savedToPhotos = await RecordingService.saveImageToLibrary(image)
                await MainActor.run {
                    self.toast = savedToPhotos ? "Photo saved." : "Photo saved to Library. (Photos needs permission.)"
                }
            }
        }
    }

    // MARK: - Lower third

    /// Live-edit overlays are a Pro feature. The camera, recording
    /// and photos work without Pro; firing an overlay without it
    /// opens the paywall instead of doing nothing.
    private func requirePro() -> Bool {
        guard subscription.isPro else {
            showPaywall = true
            return false
        }
        return true
    }

    func fireLowerThird() {
        guard requirePro() else { return }
        guard !lowerThird.isEmpty else {
            toast = "Type a name or title first, then fire it."
            return
        }
        guard !lowerThirdOnAir else { return }
        lowerThirdOnAir = true
        if isRecording {
            lowerThirdOpen = LowerThirdEvent(start: elapsed,
                                             end: elapsed,
                                             name: lowerThird.name,
                                             title: lowerThird.title)
        }
    }

    func hideLowerThird() {
        guard lowerThirdOnAir else { return }
        lowerThirdOnAir = false
        if var open = lowerThirdOpen {
            open.end = elapsed
            lowerThirdEvents.append(open)
            lowerThirdOpen = nil
        }
    }

    // MARK: - Caption overlay

    func fireCaption() {
        guard requirePro() else { return }
        let text = captionText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else {
            toast = "Type the caption first, then fire it."
            return
        }
        guard !captionOnAir else { return }
        captionOnAir = true
        lastCaptionText = text
        if isRecording {
            captionOpen = CaptionEvent(start: elapsed, end: elapsed, text: text)
        }
    }

    func hideCaption() {
        guard captionOnAir else { return }
        captionOnAir = false
        if var open = captionOpen {
            open.end = elapsed
            captionEvents.append(open)
            captionOpen = nil
        }
    }

    // MARK: - Link chip

    func fireLink() {
        guard requirePro() else { return }
        let url = normalizedLink(linkText)
        guard !url.isEmpty else {
            toast = "Type a link first, then fire it."
            return
        }
        guard !linkOnAir else { return }
        linkOnAir = true
        linkForPost = url
        if isRecording {
            linkOpen = LinkEvent(start: elapsed, end: elapsed, url: url)
        }
    }

    func hideLink() {
        guard linkOnAir else { return }
        linkOnAir = false
        if var open = linkOpen {
            open.end = elapsed
            linkEvents.append(open)
            linkOpen = nil
        }
    }

    /// Accepts "example.com" as well as "https://example.com".
    private func normalizedLink(_ raw: String) -> String {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return "" }
        if trimmed.contains("://") { return trimmed }
        return "https://" + trimmed
    }

    // MARK: - Picture overlay

    /// Called when the operator taps PICTURE. Pro members get the
    /// picker; everyone else gets the paywall.
    func requestPicturePicker() -> Bool {
        requirePro()
    }

    /// Called when the operator picks a picture. It appears on screen
    /// at once, in its default corner — the operator drags it where
    /// they want it and pinches to resize, all while recording.
    func setPicture(_ image: UIImage) {
        guard subscription.isPro else {
            showPaywall = true
            return
        }
        pictureImage = image
        pictureRect = CGRect(x: 0.60, y: 0.10, width: 0.32, height: 0.18)
        pictureOnAir = true
        if isRecording {
            pictureOpen = ImageOverlayEvent(start: elapsed, end: elapsed, rect: pictureRect)
            if let open = pictureOpen {
                pictureImages[open.id] = image
            }
        }
    }

    func hidePicture() {
        guard pictureOnAir else { return }
        pictureOnAir = false
        if var open = pictureOpen {
            open.end = elapsed
            pictureEvents.append(open)
            pictureOpen = nil
        }
    }

    /// The operator finished moving or resizing the picture. The burn
    /// needs one rectangle per stretch, so a move while on air closes
    /// the old stretch and opens a new one at the new rectangle.
    func pictureMoved(to rect: CGRect) {
        pictureRect = rect
        guard pictureOnAir, isRecording, let image = pictureImage else { return }
        if var open = pictureOpen {
            open.end = elapsed
            pictureEvents.append(open)
        }
        pictureOpen = ImageOverlayEvent(start: elapsed, end: elapsed, rect: rect)
        if let open = pictureOpen {
            pictureImages[open.id] = image
        }
    }

    // MARK: - Swap / Talent Flip

    /// Trades which camera is main, operator side. Pure state — the
    /// take never stops.
    func swapMain() {
        camera.swapMainCamera()
    }

    /// Flips the phone around so the screen faces the influencer:
    /// the FRONT camera becomes the main feed (they watch themselves
    /// live, mirror-style), the back camera keeps recording as the
    /// PiP. Both cameras keep recording through the flip — the take
    /// never stops. Flipping back restores the operator view the same
    /// way. ROTATE and every live overlay keep working in both views.
    func toggleTalentFlip() {
        // Talent Flip is a Pro feature.
        guard requirePro() else { return }
        guard camera.multiCamActive else {
            toast = "Dual camera isn't running right now — Talent Flip needs both cameras."
            return
        }
        if isTalentFlipped {
            flipBackToOperator()
        } else {
            if !camera.mainIsFront {
                camera.swapMainCamera()
            }
            isTalentFlipped = true
        }
    }

    private func flipBackToOperator() {
        if camera.mainIsFront {
            camera.swapMainCamera()
        }
        isTalentFlipped = false
    }

    // MARK: - Rotation / light

    func rotate() {
        camera.rotateBy90()
    }

    // MARK: - Timelines

    private func resetTimelines() {
        lowerThirdEvents = []
        lowerThirdOpen = nil
        captionEvents = []
        captionOpen = nil
        linkEvents = []
        linkOpen = nil
        pictureEvents = []
        pictureOpen = nil
        pictureImages = [:]
        lastCaptionText = ""
        linkForPost = nil
        // Anything already on air when RECORD starts counts from 0:00.
        if lowerThirdOnAir, !lowerThird.isEmpty {
            lowerThirdOpen = LowerThirdEvent(start: 0, end: 0, name: lowerThird.name, title: lowerThird.title)
        }
        if captionOnAir, !captionText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            captionOpen = CaptionEvent(start: 0, end: 0, text: captionText)
            lastCaptionText = captionText
        }
        if linkOnAir {
            let url = normalizedLink(linkText)
            if !url.isEmpty {
                linkOpen = LinkEvent(start: 0, end: 0, url: url)
                linkForPost = url
            }
        }
        if pictureOnAir, let image = pictureImage {
            pictureOpen = ImageOverlayEvent(start: 0, end: 0, rect: pictureRect)
            if let open = pictureOpen {
                pictureImages[open.id] = image
            }
        }
    }

    private func closeOpenOverlays(at time: TimeInterval) {
        if var open = lowerThirdOpen {
            open.end = time
            lowerThirdEvents.append(open)
            lowerThirdOpen = nil
        }
        if var open = captionOpen {
            open.end = time
            captionEvents.append(open)
            captionOpen = nil
        }
        if var open = linkOpen {
            open.end = time
            linkEvents.append(open)
            linkOpen = nil
        }
        if var open = pictureOpen {
            open.end = time
            pictureEvents.append(open)
            pictureOpen = nil
        }
    }

    private func startElapsedTimer() {
        stopElapsedTimer()
        elapsedTimer = Timer.scheduledTimer(withTimeInterval: 0.25, repeats: true) { [weak self] _ in
            guard let self, let start = self.recordingStart else { return }
            self.elapsed = Date().timeIntervalSince(start)
        }
    }

    private func stopElapsedTimer() {
        elapsedTimer?.invalidate()
        elapsedTimer = nil
    }
}
