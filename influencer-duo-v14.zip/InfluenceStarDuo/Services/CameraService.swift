import AVFoundation
import Foundation
import os

/// Camera-service log: v10 failed silently (both previews black,
/// nothing in the console), so every refused preview connection is
/// logged here from v11 on.
private let cameraLog = Logger(subsystem: "com.jhnlsecuritytech.influencestar", category: "camera")

/// Owns the capture hardware and nothing else. It runs the back and
/// front cameras at the same time (AVCaptureMultiCamSession) — the
/// whole point of this app. Built for iPhone 15 Pro and up (iOS 17+),
/// every one of which runs multi-cam. If multi-cam is ever unavailable
/// on a device, there is no fallback: `configure()` sets a plain-words
/// status message instead, and the Camera screen shows it.
/// The UI never touches AVFoundation directly — it reads @Published
/// state and calls the plain methods below.
///
/// Design notes, learned from the platform:
/// - The front camera's preview is mirrored so the talent monitor
///   reads like a mirror; the recorded front file is true-to-life.
/// - Rotation comes from AVCaptureDevice.RotationCoordinator (iOS 17+),
///   which keeps preview and captures horizon-level; the manual
///   ROTATE offset sits on top of it and is remembered between launches.
final class CameraService: NSObject, ObservableObject {
    // MARK: - Published state (always set on the main queue)

    @Published private(set) var isRunning = false
    @Published private(set) var isRecording = false
    @Published private(set) var multiCamActive = false
    /// Which camera the UI treats as main. SWAP flips it; the other
    /// camera rides picture-in-picture.
    @Published private(set) var mainIsFront = false
    /// Each camera can be turned off by the operator, mid-take —
    /// at least one always stays on. Persisted between launches.
    /// The value is the operator's switch, not the hardware state:
    /// a camera is "on" here when its connections are enabled.
    @Published private(set) var backCameraOn: Bool = UserDefaults.standard.object(forKey: "isd.camera.backOn") as? Bool ?? true
    @Published private(set) var frontCameraOn: Bool = UserDefaults.standard.object(forKey: "isd.camera.frontOn") as? Bool ?? true
    /// Pinch zoom on the main camera, 1x up to 5x (or the device's
    /// own max, whichever is smaller). Session-only, not persisted.
    @Published private(set) var zoomFactor: CGFloat = 1.0

    /// The talent monitor on the outer display (see
    /// OuterDisplayController). Lazy so the service can hand itself
    /// to the controller once it exists.
    lazy var outerDisplay = OuterDisplayController(camera: self)
    /// Plain-words status for the screen (permission problems, no
    /// camera, and so on). Nil when everything is fine.
    @Published private(set) var statusMessage: String?

    /// Preview layers are owned by the VIEWS now (the Apple Way
    /// — see CameraPreviewView): each view's backing layer IS its
    /// preview layer, and the view registers it here under its role
    /// so the service can connect it to a camera port. The service
    /// never creates a preview layer. `back` is the scene and
    /// `front` is the influencer; which one is main is
    /// `mainIsFront`.

    /// Manual rotation correction in degrees (0/90/180/270), added on
    /// top of the coordinator's horizon-level angle and remembered.
    @Published var rotationOffset: CGFloat = CGFloat(UserDefaults.standard.double(forKey: "isd.camera.rotationOffset")) {
        didSet {
            UserDefaults.standard.set(rotationOffset, forKey: "isd.camera.rotationOffset")
            applyCurrentAngles()
        }
    }

    var multiCamSupported: Bool { AVCaptureMultiCamSession.isMultiCamSupported }

    // MARK: - Private state

    private let sessionQueue = DispatchQueue(label: "com.jhnlsecuritytech.influencestar.camera")

    private var duoSession: AVCaptureMultiCamSession?
    private var started = false

    private var backDevice: AVCaptureDevice?
    private var frontDevice: AVCaptureDevice?

    private var duoBackPhotoOutput: AVCapturePhotoOutput?
    private var duoFrontPhotoOutput: AVCapturePhotoOutput?
    private var duoBackMovieOutput: AVCaptureMovieFileOutput?
    private var duoFrontMovieOutput: AVCaptureMovieFileOutput?

    private var backCoordinator: AVCaptureDevice.RotationCoordinator?
    private var frontCoordinator: AVCaptureDevice.RotationCoordinator?
    private var backPreviewObservation: NSKeyValueObservation?
    private var frontPreviewObservation: NSKeyValueObservation?

    /// Connections that need the rotation angle re-applied.
    private var backPreviewConnection: AVCaptureConnection?
    private var frontPreviewConnection: AVCaptureConnection?
    private var backMovieConnection: AVCaptureConnection?
    private var frontMovieConnection: AVCaptureConnection?
    private var backPhotoConnection: AVCaptureConnection?
    private var frontPhotoConnection: AVCaptureConnection?
    /// Connections feeding the outer display's layers.
    private var outerBackConnection: AVCaptureConnection?
    private var outerFrontConnection: AVCaptureConnection?

    /// Layers registered by the preview views (the Apple Way):
    /// each view's backing layer, keyed by the layer's identity,
    /// with the role it currently shows. The service never creates
    /// preview layers — it only connects the views' layers to
    /// camera ports.
    private var registeredPreviewLayers: [ObjectIdentifier: AVCaptureVideoPreviewLayer] = [:]
    private var registeredPreviewRoles: [ObjectIdentifier: CameraPreviewView.Role] = [:]
    /// The camera ports, once the dual session is configured, so a
    /// layer that registers late (the outer display) can be
    /// connected at once.
    private var duoBackPort: AVCaptureInput.Port?
    private var duoFrontPort: AVCaptureInput.Port?
    /// Which layer each rotation coordinator was built with, so a
    /// re-created view gets a fresh coordinator for its new layer.
    private var backCoordinatorLayer: AVCaptureVideoPreviewLayer?
    private var frontCoordinatorLayer: AVCaptureVideoPreviewLayer?

    private var photoCompletion: ((Data?) -> Void)?
    private var duoStopCompletion: ((URL?, URL?) -> Void)?
    private var duoBackURL: URL?
    private var duoFrontURL: URL?
    private var duoBackDone = false
    private var duoFrontDone = false
    /// Whether each camera is actually recording this take. An
    /// off camera never starts, and stop never waits for it — so
    /// turning a camera off mid-take can never hang the stop.
    private var duoBackRecording = false
    private var duoFrontRecording = false

    override init() {
        super.init()
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(sessionInterruptedEnded),
            name: .AVCaptureSessionInterruptionEnded,
            object: nil)
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(sessionRuntimeError),
            name: .AVCaptureSessionRuntimeError,
            object: nil)
    }

    // MARK: - Startup

    func start() {
        guard !started else { return }
        started = true
        AVCaptureDevice.requestAccess(for: .video) { [weak self] videoOK in
            guard let self else { return }
            AVCaptureDevice.requestAccess(for: .audio) { _ in
                guard videoOK else {
                    DispatchQueue.main.async {
                        self.statusMessage = "Camera access is off — turn it on in Settings to film."
                    }
                    return
                }
                self.sessionQueue.async { self.configure() }
            }
        }
    }

    /// Another app can take the camera and stop a session; when it lets
    /// go, start again instead of staying black.
    func resumeIfNeeded() {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if self.multiCamActive, let session = self.duoSession, !session.isRunning {
                session.startRunning()
            }
        }
    }

    @objc private func sessionInterruptedEnded(_ note: Notification) {
        resumeIfNeeded()
    }

    @objc private func sessionRuntimeError(_ note: Notification) {
        resumeIfNeeded()
    }

    private func configure() {
        if multiCamSupported {
            startDual { }
        } else {
            // No fallback: this app is built for iPhone 15 Pro and up,
            // and every one of those runs multi-cam. Say so plainly.
            DispatchQueue.main.async {
                self.statusMessage = "This iPhone can't run both cameras at once, so dual recording isn't available. Influencer Dúo needs an iPhone 15 Pro or newer."
            }
        }
    }

    // MARK: - Dual camera

    private struct DuoWiring {
        var backPhotoOutput: AVCapturePhotoOutput?
        var frontPhotoOutput: AVCapturePhotoOutput?
        var backMovieOutput: AVCaptureMovieFileOutput?
        var frontMovieOutput: AVCaptureMovieFileOutput?
        var backPhotoConnection: AVCaptureConnection?
        var frontPhotoConnection: AVCaptureConnection?
        var backMovieConnection: AVCaptureConnection?
        var frontMovieConnection: AVCaptureConnection?
    }

    /// Starts the dual session: back and front cameras at the same time.
    /// The preview views own their layers (the Apple Way) and register
    /// them here; once the ports exist, every registered layer is
    /// connected to its camera. The completion just reports the
    /// session is up (or refused, with the plain-words status set).
    func startDual(completion: @escaping () -> Void) {
        guard multiCamSupported else {
            DispatchQueue.main.async {
                self.statusMessage = "This iPhone can't run both cameras at once, so dual recording isn't available. Influencer Dúo needs an iPhone 15 Pro or newer."
            }
            completion()
            return
        }
        sessionQueue.async { [weak self] in
            guard let self else { return }
            // duoSession is set on this queue, so it closes the race
            // multiCamActive leaves open: multiCamActive flips on main
            // after startRunning, so a second startDual (onAppear firing
            // twice) could build a second session while the layers still
            // belong to the first — and rebinding them would abort the
            // app inside AVCaptureVideoPreviewLayer (the v11 crash).
            if self.multiCamActive || self.duoSession != nil {
                DispatchQueue.main.async { completion() }
                return
            }
            let session = AVCaptureMultiCamSession()
            session.beginConfiguration()
            guard let backDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
                  let backInput = try? AVCaptureDeviceInput(device: backDevice),
                  session.canAddInput(backInput),
                  let frontDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front),
                  let frontInput = try? AVCaptureDeviceInput(device: frontDevice),
                  session.canAddInput(frontInput) else {
                session.commitConfiguration()
                DispatchQueue.main.async {
                    self.statusMessage = "This iPhone can't run both cameras at once, so dual recording isn't available. Influencer Dúo needs an iPhone 15 Pro or newer."
                    completion()
                }
                return
            }
            session.addInputWithNoConnections(backInput)
            session.addInputWithNoConnections(frontInput)

            guard let backPort = backInput.ports(for: .video, sourceDeviceType: backDevice.deviceType, sourceDevicePosition: backDevice.position).first,
                  let frontPort = frontInput.ports(for: .video, sourceDeviceType: frontDevice.deviceType, sourceDevicePosition: frontDevice.position).first else {
                session.commitConfiguration()
                DispatchQueue.main.async { completion() }
                return
            }
            // The preview views own their layers (the Apple Way) —
            // no layer is created here. The ports are remembered so
            // every registered layer can be connected now, and any
            // layer that registers later (the outer display) can be
            // connected the moment it arrives.
            self.duoBackPort = backPort
            self.duoFrontPort = frontPort

            let wiring = self.wireDuoOutputs(session: session, backPort: backPort, frontPort: frontPort)
            session.commitConfiguration()

            self.duoSession = session
            self.backDevice = backDevice
            self.frontDevice = frontDevice
            self.backMovieConnection = wiring.backMovieConnection
            self.frontMovieConnection = wiring.frontMovieConnection
            self.backPhotoConnection = wiring.backPhotoConnection
            self.frontPhotoConnection = wiring.frontPhotoConnection
            self.duoBackPhotoOutput = wiring.backPhotoOutput
            self.duoFrontPhotoOutput = wiring.frontPhotoOutput
            self.duoBackMovieOutput = wiring.backMovieOutput
            self.duoFrontMovieOutput = wiring.frontMovieOutput
            // Connect every preview view that already registered its
            // layer, and set up rotation for the ones on screen.
            self.connectRegisteredPreviewLayers()
            self.maybeCreateCoordinators()
            session.startRunning()
            DispatchQueue.main.async {
                self.multiCamActive = true
                self.isRunning = true
                self.statusMessage = nil
                completion()
            }
        }
    }

    /// Stops the dual session.
    func stopDual(completion: (() -> Void)? = nil) {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if self.multiCamActive {
                self.duoSession?.stopRunning()
                self.duoSession = nil
                self.backDevice = nil
                self.frontDevice = nil
                self.backCoordinator = nil
                self.frontCoordinator = nil
                self.backCoordinatorLayer = nil
                self.frontCoordinatorLayer = nil
                self.duoBackPort = nil
                self.duoFrontPort = nil
                self.backPreviewObservation = nil
                self.frontPreviewObservation = nil
                self.backPreviewConnection = nil
                self.frontPreviewConnection = nil
                self.outerBackConnection = nil
                self.outerFrontConnection = nil
                self.backMovieConnection = nil
                self.frontMovieConnection = nil
                self.backPhotoConnection = nil
                self.frontPhotoConnection = nil
                self.duoBackPhotoOutput = nil
                self.duoFrontPhotoOutput = nil
                self.duoBackMovieOutput = nil
                self.duoFrontMovieOutput = nil
                self.duoStopCompletion = nil
                DispatchQueue.main.async {
                    self.multiCamActive = false
                    self.mainIsFront = false
                }
            }
            if let completion { DispatchQueue.main.async(execute: completion) }
        }
    }

    /// The capture outputs on the dual session: a photo output on each
    /// camera (so a still always comes from whichever camera is main)
    /// and a movie output on each camera. Sound rides in the back
    /// camera's file, when the device allows a mic alongside two
    /// cameras.
    private func wireDuoOutputs(session: AVCaptureMultiCamSession,
                                backPort: AVCaptureInput.Port,
                                frontPort: AVCaptureInput.Port) -> DuoWiring {
        var wiring = DuoWiring()
        let backPhoto = AVCapturePhotoOutput()
        if session.canAddOutput(backPhoto) {
            session.addOutputWithNoConnections(backPhoto)
            let connection = AVCaptureConnection(inputPorts: [backPort], output: backPhoto)
            if session.canAddConnection(connection) {
                session.addConnection(connection)
                wiring.backPhotoOutput = backPhoto
                wiring.backPhotoConnection = connection
            }
        }
        let frontPhoto = AVCapturePhotoOutput()
        if session.canAddOutput(frontPhoto) {
            session.addOutputWithNoConnections(frontPhoto)
            let connection = AVCaptureConnection(inputPorts: [frontPort], output: frontPhoto)
            // The saved still is true-to-life, not mirrored: only the
            // on-screen preview is mirrored, so the talent monitor
            // reads like a mirror while the file stays honest.
            connection.automaticallyAdjustsVideoMirroring = false
            connection.isVideoMirrored = false
            if session.canAddConnection(connection) {
                session.addConnection(connection)
                wiring.frontPhotoOutput = frontPhoto
                wiring.frontPhotoConnection = connection
            }
        }
        let backMovie = AVCaptureMovieFileOutput()
        if session.canAddOutput(backMovie) {
            session.addOutputWithNoConnections(backMovie)
            let connection = AVCaptureConnection(inputPorts: [backPort], output: backMovie)
            if session.canAddConnection(connection) {
                session.addConnection(connection)
                wiring.backMovieOutput = backMovie
                wiring.backMovieConnection = connection
            }
        }
        let frontMovie = AVCaptureMovieFileOutput()
        if session.canAddOutput(frontMovie) {
            session.addOutputWithNoConnections(frontMovie)
            let connection = AVCaptureConnection(inputPorts: [frontPort], output: frontMovie)
            // Recorded file is true-to-life, not mirrored — only the
            // preview is mirrored, so the talent monitor reads like a
            // mirror while the finished video stays honest.
            connection.automaticallyAdjustsVideoMirroring = false
            connection.isVideoMirrored = false
            if session.canAddConnection(connection) {
                session.addConnection(connection)
                wiring.frontMovieOutput = frontMovie
                wiring.frontMovieConnection = connection
            }
        }
        if let backMovie = wiring.backMovieOutput,
           let mic = AVCaptureDevice.default(for: .audio),
           let micInput = try? AVCaptureDeviceInput(device: mic),
           session.canAddInput(micInput) {
            session.addInputWithNoConnections(micInput)
            if let micPort = micInput.ports(for: .audio, sourceDeviceType: mic.deviceType, sourceDevicePosition: .unspecified).first {
                let audioConnection = AVCaptureConnection(inputPorts: [micPort], output: backMovie)
                if session.canAddConnection(audioConnection) {
                    session.addConnection(audioConnection)
                }
            }
        }
        return wiring
    }

    // MARK: - Preview layers (the Apple Way)

    /// A preview view registers its backing layer under the role it
    /// shows. If the session is already configured, the layer is
    /// connected to its camera's port at once; otherwise startDual
    /// connects every registered layer once the ports exist.
    func registerPreviewLayer(_ layer: AVCaptureVideoPreviewLayer, role: CameraPreviewView.Role) {
        let id = ObjectIdentifier(layer)
        sessionQueue.async { [weak self] in
            guard let self else { return }
            // A role belongs to one view at a time: if another layer
            // already shows this role (a view was re-created), drop
            // the old one first. Keys are collected before removing
            // — a dictionary cannot be mutated while it is iterated.
            let stale = self.registeredPreviewRoles.filter { $0.value == role && $0.key != id }.map { $0.key }
            for otherID in stale {
                if let other = self.registeredPreviewLayers[otherID] {
                    self.removePreviewConnection(for: other)
                }
                self.registeredPreviewLayers.removeValue(forKey: otherID)
                self.registeredPreviewRoles.removeValue(forKey: otherID)
            }
            self.registeredPreviewLayers[id] = layer
            self.registeredPreviewRoles[id] = role
            self.connectPreviewLayer(layer, role: role)
            self.maybeCreateCoordinators()
        }
    }

    /// Rebinds a view's layer when its role changed (SWAP): the main
    /// view's layer moves to the other camera's port, and the PiP's
    /// layer moves the other way. No-op when nothing changed.
    func rebindPreviewLayerIfNeeded(_ layer: AVCaptureVideoPreviewLayer, role: CameraPreviewView.Role) {
        let id = ObjectIdentifier(layer)
        sessionQueue.async { [weak self] in
            guard let self else { return }
            guard self.registeredPreviewRoles[id] != nil, self.registeredPreviewRoles[id] != role else { return }
            self.removePreviewConnection(for: layer)
            self.registeredPreviewRoles[id] = role
            self.connectPreviewLayer(layer, role: role)
        }
    }

    /// A preview view going away takes its layer (and connection)
    /// with it.
    func unregisterPreviewLayer(_ layer: AVCaptureVideoPreviewLayer) {
        let id = ObjectIdentifier(layer)
        sessionQueue.async { [weak self] in
            guard let self else { return }
            self.removePreviewConnection(for: layer)
            self.registeredPreviewLayers.removeValue(forKey: id)
            self.registeredPreviewRoles.removeValue(forKey: id)
        }
    }

    /// Connects every registered layer — the step startDual takes
    /// once the ports exist.
    private func connectRegisteredPreviewLayers() {
        for (id, layer) in Array(registeredPreviewLayers) {
            guard let role = registeredPreviewRoles[id] else { continue }
            connectPreviewLayer(layer, role: role)
        }
    }

    /// Connects one registered layer to its role's camera port, if
    /// the session is configured. The connection is stored on the
    /// port's property so rotation and the on/off toggles keep
    /// working on it.
    private func connectPreviewLayer(_ layer: AVCaptureVideoPreviewLayer, role: CameraPreviewView.Role) {
        guard let session = duoSession else {
            // Normal during startup: the view registers before the
            // session exists, and startDual connects it once the
            // ports are ready.
            cameraLog.debug("Preview connect: no session yet for role \(String(describing: role))")
            return
        }
        let port = (role == .back || role == .outerBack) ? duoBackPort : duoFrontPort
        guard let port else {
            cameraLog.error("Preview connect: no camera port yet for role \(String(describing: role))")
            DispatchQueue.main.async {
                self.statusMessage = "The cameras started but the preview couldn't connect. Close the app and open it again — if it stays black, tell me and I'll fix it."
            }
            return
        }
        // Already feeding this exact layer? Nothing to do — this runs
        // from register, from startDual, and from a SWAP rebind, and
        // a second bind of one layer aborts the app (the v11 crash).
        let existingConnection: AVCaptureConnection?
        switch role {
        case .back: existingConnection = backPreviewConnection
        case .front: existingConnection = frontPreviewConnection
        case .outerBack: existingConnection = outerBackConnection
        case .outerFront: existingConnection = outerFrontConnection
        }
        if let existingConnection, existingConnection.videoPreviewLayer === layer {
            return
        }
        // The layer belongs to its view (the Apple Way), so it starts
        // with no session at all — until this call, the session
        // refuses every preview connection and both pictures stay
        // black, with nothing in the log. That was the v10 bug: zero
        // calls to setSessionWithNoConnection anywhere in the app.
        // But the call is one-shot per layer: a layer that already
        // has a session (a SWAP rebind, or a second connect) must
        // never get it again — that is the assertion that killed v11
        // at launch. A layer bound to a DIFFERENT session is left
        // alone rather than crashed on.
        // And the call belongs on the MAIN thread. Apple's own
        // multi-cam sample binds the layer in viewDidLoad (main),
        // before the session is configured — never from the session
        // queue. v11 and v13 bound it from the session queue (a
        // background thread) and the app died at launch both times
        // (Thread 19, Thread 22 — the same preview-layer
        // assertion). The session config stays on the session queue;
        // only the layer bind moves to main, synchronously so the
        // connection below is created after the bind.
        func bindLayerIfNeeded() -> Bool {
            if layer.session == nil {
                layer.setSessionWithNoConnection(session)
                return true
            }
            return layer.session === session
        }
        let bindOK: Bool
        if Thread.isMainThread {
            bindOK = bindLayerIfNeeded()
        } else {
            bindOK = DispatchQueue.main.sync(execute: bindLayerIfNeeded)
        }
        guard bindOK else {
            cameraLog.error("Preview connect: layer already belongs to another session for role \(String(describing: role))")
            return
        }
        let connection = AVCaptureConnection(inputPort: port, videoPreviewLayer: layer)
        if role == .front || role == .outerFront {
            connection.automaticallyAdjustsVideoMirroring = false
            connection.isVideoMirrored = true
        }
        guard session.canAddConnection(connection) else {
            cameraLog.error("Preview connect: session refused the \(String(describing: role)) preview connection")
            DispatchQueue.main.async {
                self.statusMessage = "The cameras started but the preview couldn't connect. Close the app and open it again — if it stays black, tell me and I'll fix it."
            }
            return
        }
        // A layer can register late (the outer display), while the
        // session is already running, so the add goes through a
        // configuration block.
        session.beginConfiguration()
        session.addConnection(connection)
        session.commitConfiguration()
        cameraLog.info("Preview connected for role \(String(describing: role))")
        switch role {
        case .back: backPreviewConnection = connection
        case .front: frontPreviewConnection = connection
        case .outerBack: outerBackConnection = connection
        case .outerFront: outerFrontConnection = connection
        }
        // The camera's on/off switch and the current rotation angle
        // apply to the new connection at once.
        let on = (role == .back || role == .outerBack) ? backCameraOn : frontCameraOn
        connection.isEnabled = on
        applyCurrentAngles()
    }

    /// Drops the preview connection feeding one layer, if any.
    private func removePreviewConnection(for layer: AVCaptureVideoPreviewLayer) {
        guard let session = duoSession else { return }
        for connection in [backPreviewConnection, frontPreviewConnection, outerBackConnection, outerFrontConnection] {
            guard let connection, connection.videoPreviewLayer === layer else { continue }
            session.removeConnection(connection)
            if connection === backPreviewConnection { backPreviewConnection = nil }
            if connection === frontPreviewConnection { frontPreviewConnection = nil }
            if connection === outerBackConnection { outerBackConnection = nil }
            if connection === outerFrontConnection { outerFrontConnection = nil }
        }
    }

    /// The layer currently showing one role, if any.
    private func layer(for role: CameraPreviewView.Role) -> AVCaptureVideoPreviewLayer? {
        registeredPreviewRoles.first(where: { $0.value == role }).flatMap { registeredPreviewLayers[$0.key] }
    }

    /// Creates the rotation coordinators once the session is
    /// configured AND the operator screen's back and front layers
    /// are registered — a coordinator measures its layer's place in
    /// the view hierarchy, so it needs a real, on-screen layer.
    /// Called from startDual and from every registration; safe to
    /// call any time, and re-creates a side's coordinator when its
    /// layer is replaced.
    private func maybeCreateCoordinators() {
        guard duoSession != nil else { return }
        if let device = backDevice, let layer = layer(for: .back), backCoordinatorLayer !== layer {
            let coordinator = AVCaptureDevice.RotationCoordinator(device: device, previewLayer: layer)
            backCoordinator = coordinator
            backCoordinatorLayer = layer
            backPreviewObservation = coordinator.observe(
                \.videoRotationAngleForHorizonLevelPreview,
                options: [.initial, .new]) { [weak self] coordinator, change in
                    guard let self, let rawAngle = change.newValue else { return }
                    self.applyAngle(rawAngle, to: self.backPreviewConnection)
                    self.applyAngle(rawAngle, to: self.outerBackConnection)
                    let captureAngle = coordinator.videoRotationAngleForHorizonLevelCapture
                    self.applyAngle(captureAngle, to: self.backMovieConnection)
                    self.applyAngle(captureAngle, to: self.backPhotoConnection)
                }
        }
        if let device = frontDevice, let layer = layer(for: .front), frontCoordinatorLayer !== layer {
            let coordinator = AVCaptureDevice.RotationCoordinator(device: device, previewLayer: layer)
            frontCoordinator = coordinator
            frontCoordinatorLayer = layer
            frontPreviewObservation = coordinator.observe(
                \.videoRotationAngleForHorizonLevelPreview,
                options: [.initial, .new]) { [weak self] coordinator, change in
                    guard let self, let rawAngle = change.newValue else { return }
                    self.applyAngle(rawAngle, to: self.frontPreviewConnection)
                    self.applyAngle(rawAngle, to: self.outerFrontConnection)
                    let captureAngle = coordinator.videoRotationAngleForHorizonLevelCapture
                    self.applyAngle(captureAngle, to: self.frontMovieConnection)
                    self.applyAngle(captureAngle, to: self.frontPhotoConnection)
                }
        }
        // Apply the current angles right away — do not wait for the
        // phone to move before the pictures sit the right way up.
        applyCurrentAngles()
    }

    // MARK: - Rotation

    private func effectiveAngle(_ angle: CGFloat) -> CGFloat {
        var result = (angle + rotationOffset).truncatingRemainder(dividingBy: 360)
        if result < 0 { result += 360 }
        return result
    }

    private func applyAngle(_ angle: CGFloat, to connection: AVCaptureConnection?) {
        guard let connection else { return }
        let effective = effectiveAngle(angle)
        guard connection.isVideoRotationAngleSupported(effective) else { return }
        connection.videoRotationAngle = effective
    }

    private func applyCurrentAngles() {
        if let coordinator = backCoordinator {
            applyAngle(coordinator.videoRotationAngleForHorizonLevelPreview, to: backPreviewConnection)
            applyAngle(coordinator.videoRotationAngleForHorizonLevelPreview, to: outerBackConnection)
            applyAngle(coordinator.videoRotationAngleForHorizonLevelCapture, to: backMovieConnection)
            applyAngle(coordinator.videoRotationAngleForHorizonLevelCapture, to: backPhotoConnection)
        }
        if let coordinator = frontCoordinator {
            applyAngle(coordinator.videoRotationAngleForHorizonLevelPreview, to: frontPreviewConnection)
            applyAngle(coordinator.videoRotationAngleForHorizonLevelPreview, to: outerFrontConnection)
            applyAngle(coordinator.videoRotationAngleForHorizonLevelCapture, to: frontMovieConnection)
            applyAngle(coordinator.videoRotationAngleForHorizonLevelCapture, to: frontPhotoConnection)
        }
    }

    /// One tap = 90 degrees more correction, everywhere at once. The
    /// new offset is remembered for the next launch.
    func rotateBy90() {
        var next = rotationOffset + 90
        next = next.truncatingRemainder(dividingBy: 360)
        if next < 0 { next += 360 }
        rotationOffset = next
    }

    // MARK: - Main / PiP swap

    /// Trades which dual camera is main and which rides
    /// picture-in-picture. Pure state — no session reconfiguration.
    func swapMainCamera() {
        guard multiCamActive else { return }
        // No swap when only one camera is on — the on camera is
        // already main.
        guard backCameraOn && frontCameraOn else { return }
        DispatchQueue.main.async {
            self.mainIsFront.toggle()
            // The zoom belongs to the camera, not the side: re-apply
            // the current factor to whichever camera just became main.
            self.setZoomFactor(self.zoomFactor)
        }
    }

    // MARK: - Per-camera on/off

    /// Turns one camera's preview, movie and photo connections off
    /// or on, live, mid-take. If the main camera goes off, the other
    /// one becomes main at once. The caller guards the last camera
    /// (see CameraViewModel.toggleCamera) — this only applies.
    func setCameraOn(back: Bool, on: Bool) {
        guard multiCamActive else { return }
        sessionQueue.async { [weak self] in
            guard let self else { return }
            let preview = back ? self.backPreviewConnection : self.frontPreviewConnection
            let movie = back ? self.backMovieConnection : self.frontMovieConnection
            let photo = back ? self.backPhotoConnection : self.frontPhotoConnection
            let outer = back ? self.outerBackConnection : self.outerFrontConnection
            preview?.isEnabled = on
            movie?.isEnabled = on
            photo?.isEnabled = on
            outer?.isEnabled = on
            DispatchQueue.main.async {
                if back { self.backCameraOn = on } else { self.frontCameraOn = on }
                UserDefaults.standard.set(on, forKey: back ? "isd.camera.backOn" : "isd.camera.frontOn")
                let mainTurnedOff = !on && ((back && !self.mainIsFront) || (!back && self.mainIsFront))
                if mainTurnedOff { self.mainIsFront.toggle() }
            }
        }
    }

    /// Rebuilds the dual session from scratch — the recovery when a
    /// camera comes up black or a connection stalls. Safe to call
    /// while not recording; the caller guards that.
    func restartDual() {
        stopDual { [weak self] in
            guard let self else { return }
            self.zoomFactor = 1.0
            self.startDual { }
        }
    }

    // MARK: - Zoom + torch

    /// Pinch zoom on the main camera, 1x up to 5x (or the device's
    /// own max, whichever is smaller).
    func setZoomFactor(_ factor: CGFloat) {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            let device = self.mainIsFront ? self.frontDevice : self.backDevice
            guard let device else { return }
            let maxZoom = min(device.activeFormat.videoMaxZoomFactor, 5.0)
            let clamped = min(max(1.0, factor), maxZoom)
            do {
                try device.lockForConfiguration()
                device.videoZoomFactor = clamped
                device.unlockForConfiguration()
            } catch { return }
            DispatchQueue.main.async { self.zoomFactor = clamped }
        }
    }

    /// The rear torch, so LIGHT brightens the scene the back camera
    /// sees as well as glowing the screen for the front camera.
    func setTorch(_ on: Bool) {
        sessionQueue.async { [weak self] in
            guard let self, let device = self.backDevice, device.hasTorch else { return }
            do {
                try device.lockForConfiguration()
                device.torchMode = on ? .on : .off
                device.unlockForConfiguration()
            } catch { return }
        }
    }

    // MARK: - Photo

    /// A still from whichever camera is main right now.
    func capturePhoto(completion: @escaping (Data?) -> Void) {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            self.photoCompletion = completion
            // Never fire a capture on a dead or rebuilding session —
            // a photo taken while the cameras are restarting must
            // just do nothing, never crash.
            guard self.multiCamActive, let session = self.duoSession, session.isRunning else {
                self.finishPhoto(nil)
                return
            }
            let settings = AVCapturePhotoSettings()
            settings.photoQualityPrioritization = .quality
            let output: AVCapturePhotoOutput? = self.mainIsFront ? self.duoFrontPhotoOutput : self.duoBackPhotoOutput
            guard let output else {
                self.finishPhoto(nil)
                return
            }
            output.capturePhoto(with: settings, delegate: self)
        }
    }

    private func finishPhoto(_ data: Data?) {
        guard let completion = photoCompletion else { return }
        photoCompletion = nil
        DispatchQueue.main.async { completion(data) }
    }

    // MARK: - Video

    /// Starts recording on both cameras at once. The files land in the
    /// temporary directory; the caller merges them on stop.
    func startRecording() {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if self.multiCamActive {
                // An off camera never starts — and stop never waits
                // for it. At least one camera is always on.
                self.duoBackRecording = self.backCameraOn && self.duoBackMovieOutput != nil
                self.duoFrontRecording = self.frontCameraOn && self.duoFrontMovieOutput != nil
                self.duoBackDone = !self.duoBackRecording
                self.duoFrontDone = !self.duoFrontRecording
                self.duoBackURL = nil
                self.duoFrontURL = nil
                if self.duoBackRecording, let back = self.duoBackMovieOutput {
                    back.startRecording(to: self.temporaryURL(prefix: "isd-duo-back"), recordingDelegate: self)
                }
                if self.duoFrontRecording, let front = self.duoFrontMovieOutput {
                    front.startRecording(to: self.temporaryURL(prefix: "isd-duo-front"), recordingDelegate: self)
                }
            }
        }
    }

    /// Stops recording. The completion runs on the main queue with the
    /// back camera's file first and the front camera's second.
    func stopRecording(completion: @escaping (URL?, URL?) -> Void) {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if self.multiCamActive {
                self.duoStopCompletion = completion
                self.duoBackDone = !self.duoBackRecording
                self.duoFrontDone = !self.duoFrontRecording
                if self.duoBackRecording { self.duoBackMovieOutput?.stopRecording() }
                if self.duoFrontRecording { self.duoFrontMovieOutput?.stopRecording() }
                if self.duoBackDone && self.duoFrontDone {
                    self.finishDuoStop()
                }
            } else {
                DispatchQueue.main.async { completion(nil, nil) }
            }
        }
    }

    private func finishDuoStop() {
        guard let completion = duoStopCompletion else { return }
        duoStopCompletion = nil
        let back = duoBackURL
        let front = duoFrontURL
        DispatchQueue.main.async { completion(back, front) }
    }

    private func temporaryURL(prefix: String) -> URL {
        FileManager.default.temporaryDirectory
            .appendingPathComponent("\(prefix)-\(UUID().uuidString).mov")
    }
}

extension CameraService: AVCapturePhotoCaptureDelegate {
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        finishPhoto(error == nil ? photo.fileDataRepresentation() : nil)
    }
}

extension CameraService: AVCaptureFileOutputRecordingDelegate {
    func fileOutput(_ output: AVCaptureFileOutput, didStartRecordingTo fileURL: URL, from connections: [AVCaptureConnection]) {
        DispatchQueue.main.async { self.isRecording = true }
    }

    func fileOutput(_ output: AVCaptureFileOutput, didFinishRecordingTo outputFileURL: URL, from connections: [AVCaptureConnection], error: Error?) {
        guard output === duoBackMovieOutput || output === duoFrontMovieOutput else { return }
        if output === duoBackMovieOutput {
            duoBackURL = error == nil ? outputFileURL : nil
            duoBackDone = true
        } else {
            duoFrontURL = error == nil ? outputFileURL : nil
            duoFrontDone = true
        }
        if duoBackDone && duoFrontDone {
            DispatchQueue.main.async { self.isRecording = false }
            finishDuoStop()
        }
    }
}
