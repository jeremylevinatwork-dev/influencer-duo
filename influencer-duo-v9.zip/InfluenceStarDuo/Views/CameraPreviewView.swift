import AVFoundation
import SwiftUI

/// Embeds an AVCaptureVideoPreviewLayer in SwiftUI. The layer is
/// handed in from the camera service; this view only hosts it and
/// keeps its frame in step with the view's bounds.
struct CameraPreviewView: UIViewRepresentable {
    var layer: AVCaptureVideoPreviewLayer?

    func makeUIView(context: Context) -> PreviewHostView {
        PreviewHostView()
    }

    func updateUIView(_ uiView: PreviewHostView, context: Context) {
        if uiView.hostedLayer !== layer {
            uiView.hostedLayer?.removeFromSuperlayer()
            uiView.hostedLayer = layer
            if let layer {
                uiView.layer.addSublayer(layer)
            }
        }
        if let layer {
            layer.frame = uiView.bounds
        }
        // Force a layout pass now: if the host view was just sized,
        // the layer's frame must follow at once instead of waiting
        // for a later pass that may never come.
        uiView.setNeedsLayout()
        uiView.layoutIfNeeded()
    }

    final class PreviewHostView: UIView {
        var hostedLayer: AVCaptureVideoPreviewLayer?
        override func layoutSubviews() {
            super.layoutSubviews()
            // Re-attach if the layer ever left the hierarchy, then
            // keep its frame in step with the view's bounds.
            if let hostedLayer, hostedLayer.superlayer !== layer {
                layer.addSublayer(hostedLayer)
            }
            hostedLayer?.frame = bounds
        }
    }
}
