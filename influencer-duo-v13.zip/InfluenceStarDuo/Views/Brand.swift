import SwiftUI

/// The app's look: deep navy, and the neon chrome star's cyan and
/// magenta as the accents. The logo's gradient — neon cyan (left) to
/// hot magenta (right) — is the primary accent: FIRE buttons, active
/// tools, highlights. Everything on the Camera screen is built from
/// these pieces so the operator can read it at a glance, mid-take.
enum Brand {
    static let navy = Color(red: 0.043, green: 0.071, blue: 0.125)
    static let navyLight = Color(red: 0.09, green: 0.14, blue: 0.23)
    static let gold = Color(red: 0.949, green: 0.753, blue: 0.094)
    static let cyan = Color(red: 0.05, green: 0.85, blue: 0.95)
    static let magenta = Color(red: 0.98, green: 0.15, blue: 0.65)
    static let background = Color.black
    static let panel = Color(red: 0.05, green: 0.08, blue: 0.14).opacity(0.92)

    /// The logo's neon gradient, cyan to magenta, left to right.
    static let neonGradient = LinearGradient(
        colors: [cyan, magenta],
        startPoint: .leading,
        endPoint: .trailing)

    static let appName = "Influencer Dúo"
    static let buildStamp = "Build v13"
}

/// A big thumb-sized control button for the Camera screen. The
/// operator runs the show with one thumb mid-take — nothing here is
/// small, fiddly, or two taps.
struct OperatorButton: View {
    var label: String
    var systemImage: String
    var isActive: Bool = false
    var isDestructive: Bool = false
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: systemImage)
                    .font(.system(size: 24, weight: .semibold))
                Text(label)
                    .font(.system(size: 11, weight: .bold))
            }
            .frame(width: 64, height: 60)
            .foregroundColor(isActive && !isDestructive ? .black : .white)
            .background(
                Group {
                    if isDestructive {
                        Color.red
                    } else if isActive {
                        Brand.neonGradient
                    } else {
                        Color.white.opacity(0.16)
                    }
                }
            )
            .clipShape(RoundedRectangle(cornerRadius: 14))
        }
        .buttonStyle(.plain)
    }
}

/// The record button: huge, round, impossible to miss with a thumb.
struct RecordButton: View {
    var isRecording: Bool
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            ZStack {
                Circle()
                    .fill(Color.white.opacity(0.25))
                    .frame(width: 84, height: 84)
                Circle()
                    .fill(isRecording ? Color.red : Color.white)
                    .frame(width: 68, height: 68)
                if isRecording {
                    RoundedRectangle(cornerRadius: 6)
                        .fill(Color.white)
                        .frame(width: 28, height: 28)
                }
            }
        }
        .buttonStyle(.plain)
        .accessibilityLabel(isRecording ? "Stop recording" : "Start recording")
    }
}

/// A small pill label, used for the recording clock and status notes.
struct PillLabel: View {
    var text: String
    var color: Color = .white

    var body: some View {
        Text(text)
            .font(.system(size: 13, weight: .bold))
            .foregroundColor(color)
            .padding(.horizontal, 12)
            .padding(.vertical, 6)
            .background(Color.black.opacity(0.55))
            .clipShape(Capsule())
    }
}
