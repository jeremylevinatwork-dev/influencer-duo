# Influencer Dúo — v1

A native iOS camera app for influencers, built from scratch in SwiftUI +
AVFoundation. Dual camera (front + back at once, picture-in-picture), live
editing while recording by the person behind the camera, and auto-post to
Facebook, Instagram and TikTok — with a monthly subscription for the Pro
features and a free camera that is genuinely good on its own.

**Build v1** — the stamp is on the Camera screen's top bar, so every test
build is identifiable on the phone.

## What v1 includes

- **Dual camera, always.** Back camera full-screen, front camera as a
  draggable picture-in-picture. Both record at the same time; the finished
  video is merged main-full + PiP with sound from the main camera. SWAP
  trades which camera is main mid-take. ROTATE in 90° steps, remembered
  across launches. Front LIGHT is a screen glow that lights whoever faces
  the phone. Photos come from whichever camera is main.
- **Operator-first live edit.** The person behind the camera runs the show
  while recording: big one-tap FIRE/HIDE for lower thirds (name + title),
  captions, links and pictures — all burned into the recorded video. A
  picture picked from the library mid-take is draggable and pinchable on
  screen. A link typed mid-take appears as a chip on screen AND is stored
  on the finished video, so it goes into the auto-post caption on Facebook,
  Instagram and TikTok.
- **Talent Flip.** One big FLIP button: the phone turns around, the screen
  faces the influencer, the front camera becomes the main feed and the back
  camera keeps recording as the PiP. The take never stops. The flipped
  screen is the influencer's live monitor — themselves plus every live
  overlay — with one huge STOP button and volume buttons that start/stop
  recording (the operator can't reach the screen while it's flipped).
  Flipping back restores the operator view without stopping the take.
- **No login wall, offline-first.** The Camera works the moment the app
  opens — permissions are the only first-launch step. Recording and photos
  work with no network at all. Finished media lives on the device; auto-post
  uploads go into a persistent outbox queue and upload automatically when the
  phone is back online. Nothing is ever lost or silently dropped — queue
  status and plain-words failures are shown in the Library, with Retry.
- **Auto-post, on the user's terms.** Accounts tab lists Facebook Page,
  Instagram Business and TikTok, each with its own connect button and its
  own auto-post toggle. The app posts ONLY to accounts that are connected
  AND switched on — never to a platform the user didn't choose, never to a
  switched-off account. Tokens live in the Keychain, never in files or code.
- **Monthly subscription (StoreKit 2).** One product,
  `com.jhnlsecuritytech.influencestar.monthly`, $9.99/month by default
  (single constant in `Services/SubscriptionService.swift` —
  `SubscriptionConfig`), with a **5-day free trial** as its introductory
  offer. Pro unlocks auto-post, live-edit overlays and the flip talent
  monitor. Without Pro the camera, recording and photos still work, and
  recorded videos are never locked away. Subscribed, in trial, expired,
  cancelled and restore are all handled; a comped user never sees a paywall.
- **Famous influencers get it free.** App Store offer codes are supported
  (redeem sheet on the paywall; a redeemed code is a real subscription
  transaction, so it unlocks exactly like a paid one). The paywall also has
  a "Request free Pro access" flow: name + social handle, saved on-device,
  shareable to Jeremy. Nothing is free self-serve — an unapproved request
  just says it was received.
- **The logo.** The neon chrome star with light beams is the AppIcon
  (wordless) and the worded version is the start screen and paywall
  logo: `logo-options/influencer-duo-accent-final.png` — the star with
  "INFLUENCER DÚO", accent over the U. Cyan-to-magenta neon accents run
  through the whole UI. The brand bug burned into finished videos reads
  "★ INFLUENCER DÚO".
- **Add location (check-in + quick review).** The LOCATION tool on the
  Camera screen pinpoints where the phone is and shows the place card —
  name and address from Apple's free reverse-geocode, plus Google's star
  rating when a Places key is set (see below). The influencer gives the
  place a quick take right there: 1–5 stars and a one-line verdict, their
  words. Attaching shows a location chip on the preview (tap it to edit
  the take or remove it), burns the place + take into the finished video
  and photo, shows the place name in the Library, and appends
  "📍 <place> — ★★★★★ "<one-liner>"" to the auto-post caption. Google's
  rating and the influencer's own stars are always shown separately —
  never mixed up, never invented. Location is off by default and only
  runs when the operator taps Add location; a denied permission is a
  plain-words message and filming carries on normally.

## Install

1. Open `InfluenceStarDuo.xcodeproj` in Xcode 16+.
2. Select the **InfluenceStarDuo** target → Signing & Capabilities →
   pick the **jeremy levin** team (the project ships with automatic
   signing and an empty team, as the reference projects do).
3. Run on an **iPhone 15 Pro or newer** (iOS 17+). Every iPhone 15 Pro and
   up supports multi-cam; if dual camera is ever unavailable on a supported
   device, the camera screen says so in plain words instead of failing
   silently.
4. First launch asks only for camera, microphone and photo-add permissions,
   then opens straight onto the Camera tab.

## Jeremy-side setup (before auto-post and subscriptions work for real people)

- **App Store Connect — subscription.** Create the auto-renewable monthly
  subscription product `com.jhnlsecuritytech.influencestar.monthly` at
  $9.99/month, with a **5-day** free trial as its introductory offer, and
  create offer codes for famous influencers. Until the product exists, the
  paywall shows the $9.99 fallback and buying waits — the camera still works.
- **Meta — Facebook Page + Instagram.** Create an app at
  developers.facebook.com, add Facebook Login and the Instagram Graph API
  products, and allow the redirect `influencestar://oauth`. Enter the App ID
  on the Accounts tab. **Meta app review is a separate step** — auto-post
  does not work for other people's accounts until Meta approves the app.
  Personal Facebook profiles can never be auto-posted (Meta removed that);
  the app offers Share for those.
- **TikTok.** Create an app at developers.tiktok.com, add Login Kit and the
  Content Posting API, allow the redirect `influencestar://tiktok-auth`.
  Enter the Client Key and Client Secret on the Accounts tab. The secret is
  kept in the device Keychain, never in code — but its proper home is a
  small server, because the token exchange needs the secret; v1 does it
  on-device with a user-entered secret and says so in the app and here.
  **TikTok app review is also a separate step.**
- **Google Places — optional, for the star rating on place cards.**
  The place name and address work without it (Apple's free geocode).
  To also show Google's rating: console.cloud.google.com → enable the
  "Places API" → Credentials → create an API key → paste it into
  `Services/GooglePlacesConfig.swift` (`apiKey`). Restrict the key to
  iOS apps in the Cloud console. Without a key the card shows the place
  with no Google rating — never a made-up one. The key is never
  hardcoded anywhere else, and the rating is only used when Google
  returns a result that is clearly the place being stood at (name match
  or within 75 m).
- **Trademark.** A name can't be copyrighted — it needs a trademark. No
  exact "Influencer Duo" app or trademark was found (the name is now
  spelled "Influencer Dúo", with the accent over the U — the earlier
  "DUOO" spelling is dead), but Google owns "DUO"
  (Reg. 5788195, video/communications software), so a lawyer must clear
  the "Duo" part before filing. Filing is not done; needs Jeremy's lawyer
  or a direct USPTO filing, Class 9.

## What's NOT in v1

- **Meta/TikTok app review** (see above) — Jeremy's step with Meta and TikTok.
- **The App Store Connect subscription product, trial and offer codes**
  (see above) — Jeremy's step.
- **Instagram photo auto-post and TikTok photo auto-post.** Their APIs take
  video only, so photos go through the iOS share sheet — the app offers
  that, never a fake auto-post. Facebook photos do auto-post.
- **Background uploads.** The outbox drains while the app is active or in
  the foreground. No background URLSession uploads yet.
- **Long-lived tokens.** Token refresh needs an app secret, which cannot
  live in the client, so tokens are short-lived in v1 and the app asks to
  reconnect when one expires. Same story for TikTok.
- **Back-camera torch and pinch zoom were removed, not shipped half-done.**
  The LIGHT button is the front screen glow, which is wired and works.
  The torch/zoom code was unwired dead code and was deleted rather than
  shipped as a button that does nothing.
- **The Duo phone's outer display / Duo Preview.** That is Apple's own
  Camera app only — there is no third-party API for it, and this app does
  not attempt to access or control it in any way. The talent monitor is
  the FLIP mode, where the main screen faces the influencer.

## Must verify on a real phone (Xcode build + device test)

The project was written carefully against the iOS 17 SDK but could not be
compiled on the Linux build machine — no Swift compiler exists there.
Before calling v1 done, on a Mac:

1. `xcodebuild -project InfluenceStarDuo.xcodeproj -scheme InfluenceStarDuo
   -destination 'generic/platform=iOS' build` — must succeed.
2. Install on an iPhone 15 Pro+ and check: dual preview on first open;
   Record → Stop → merged video in Library and Photos; Photo; SWAP;
   ROTATE remembered after relaunch; FLIP mid-take with volume-button
   stop; live lower third / caption / link / picture burned in.
3. Location: tap LOCATION, allow the prompt, and check the place card
   names the spot; give it 4 stars + a one-liner, attach, and check the
   chip shows on the preview, the finished video carries the location
   chip, the Library tile shows the place name, and the caption reads
   "📍 <place> — ★★★★☆ "<one-liner>"". Deny location in Settings and
   check filming still works with a plain-words message. (Google's rating
   only appears with a Places key set — without one the card has no
   Google rating, which is correct.)
4. With a Pro subscription active (sandbox): connect a real Facebook Page
   and post a video; connect TikTok and post a video; connect Instagram
   and post a Reel. In particular, verify the Instagram resumable-upload
   endpoint details (`rupload.facebook.com` host and headers) against
   Meta's current docs — the flow is implemented from the documented API,
   but the exact upload host/headers must be confirmed live.
4. Offline test: record with Airplane Mode on, confirm the video saves and
   the post queues, then turn the network back on and watch it go out.
5. Paywall: sandbox purchase starts the 5-day trial; restore works;
   redeeming an offer code unlocks Pro and never shows the paywall again;
   expiry locks Pro features but leaves the Library untouched.
6. Confirm the Info.plist is not copied into the bundle as a resource
   (the synchronized group should exclude it automatically; if Xcode
   flags it, add it to the group's exceptions).

## Structure

```
InfluenceStarDuo/
  InfluenceStarDuoApp.swift      App entry — wires every store once
  Info.plist                     Usage strings, influencestar:// scheme, launch screen
  Assets.xcassets/               AppIcon (neon star), LaunchLogo (worded), AccentColor
  Models/                        MediaItem, SocialAccount, LowerThird (+ events), PostJob,
                                 Place (+ LocationEvent)
  Services/                      CameraService, RecordingService, PostingService,
                                 AccountStore, LibraryStore, OutboxStore, KeychainHelper,
                                 MetaConfig, TikTokConfig, NetworkMonitor,
                                 VolumeButtonObserver, SubscriptionService, ProRequestStore,
                                 LocationService, GooglePlacesConfig
  ViewModels/                    CameraViewModel, LibraryViewModel, AccountsViewModel
  Views/                         RootView, CameraView, CameraPreviewView, EditPanelView,
                                 PhotoPicker, LibraryView, MediaDetailView,
                                 AccountsView, PaywallView, ShareSheet, Brand
```

Notes for future work: the project targets the Swift 5 language mode
(`SWIFT_VERSION = 5.0`); the subscription service is deliberately not
`@MainActor` because the posting service reads `isPro` from background
upload tasks, and its published state is confined to the main queue
inside. The lower third in the finished video still uses the navy+gold
band from before the logo was chosen — a possible follow-up is swapping
the gold bar for the neon gradient. The final video's main/PiP assignment
is whichever camera was main at STOP time (flip mid-take, flip back, and
the video is back-main; end while flipped and the video is front-main).
