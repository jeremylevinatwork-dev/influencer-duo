import SwiftUI

/// The root of the app: three tabs — Camera, Library, Accounts.
///
/// There is no login wall. The Camera tab is the first screen, and
/// it works the moment the app opens — permissions are the only
/// first-launch step. Accounts are only needed for auto-post.
struct RootView: View {
    @ObservedObject var camera: CameraService
    @ObservedObject var cameraVM: CameraViewModel
    @ObservedObject var libraryVM: LibraryViewModel
    @ObservedObject var accountsVM: AccountsViewModel
    @ObservedObject var subscription: SubscriptionService
    @ObservedObject var proRequests: ProRequestStore
    @ObservedObject var network: NetworkMonitor
    @ObservedObject var posting: PostingService

    var body: some View {
        TabView {
            CameraView(viewModel: cameraVM, camera: camera, subscription: subscription, proRequests: proRequests)
                .tabItem {
                    Label("Camera", systemImage: "video.fill")
                }
            LibraryView(viewModel: libraryVM, subscription: subscription, proRequests: proRequests)
                .tabItem {
                    Label("Library", systemImage: "square.grid.2x2.fill")
                }
            AccountsView(viewModel: accountsVM, subscription: subscription, proRequests: proRequests)
                .tabItem {
                    Label("Accounts", systemImage: "person.crop.circle")
                }
        }
        .tint(Brand.cyan)
        .onAppear {
            camera.start()
            network.start()
            network.onChange = { online in
                if online {
                    posting.processOutbox()
                }
            }
            Task {
                await subscription.refresh()
            }
        }
    }
}
