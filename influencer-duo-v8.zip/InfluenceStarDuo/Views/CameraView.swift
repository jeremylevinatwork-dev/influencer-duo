import AVFoundation
import SwiftUI

/// The Camera screen — the app's first screen, no login wall. The
/// OPERATOR behind the phone runs the show: they watch the live feed
/// and fire lower thirds, captions, links and pictures with one thumb
/// while the take keeps running. The person on camera does nothing.
///
/// Layout rule: every control lives in the bottom thumb zone. The
/// edit panel is a short strip docked at the bottom — it never reaches
/// up over the person being filmed. The top bar holds only the clock
/// and ROTATE.
///
/// Talent Flip: one big FLIP button turns the phone around so the
/// screen faces the influencer. The front camera becomes the main
/// feed (they watch themselves live, mirror-style), the back camera
/// keeps recording as the PiP, and the take never stops. The flipped
/// screen shows only a huge STOP button and a small flip-back — the
/// volume buttons also start/stop the take, because the operator
/// behind the phone cannot reach the screen while flipped.
struct CameraView: View {
    @ObservedObject var viewModel: CameraViewModel
    @ObservedObject var camera: CameraService
    @ObservedObject var subscription: SubscriptionService
    var proRequests: ProRequestStore

    @State private var pipOffset = CGSize.zero
    @State private var pipStartOffset = CGSize.zero
    @State private var selectedTool: EditTool?
    @State private var showPhotoPicker = false
    @State private var dragStartRect: CGRect?
    @State private var pinchStartRect: CGRect?
    /// Owner unlock: taps on the build stamp. Five taps turns the
    /// owner unlock on — Jeremy never pays for his own app.
    @State private var stampTaps = 0
    /// Pinch zoom: the zoom factor when the pinch started.
    @State private var pinchStartZoom: CGFloat?

    var body: some View {
        GeometryReader { geo in
            ZStack {
                // Live preview, full screen.
                previewLayers(in: geo)

                // Front light: a white glow that lights whoever the
                // front camera is pointed at. Behind the controls.
                if viewModel.frontLightOn {
                    Color.white.opacity(0.88)
                }

                // Live overlays the operator fired (and the talent
                // watches in Flip mode): caption, link chip, picture.
                // The lower third rides in the bottom stack instead —
                // it belongs with the controls, above the thumb zone.
                if viewModel.captionOnAir {
                    captionOverlay(in: geo)
                }
                if viewModel.linkOnAir {
                    linkChipOverlay(in: geo)
                }
                if viewModel.locationOnAir, let place = viewModel.attachedPlace {
                    locationChipOverlay(place: place)
                }
                if let image = viewModel.pictureImage, viewModel.pictureOnAir {
                    pictureOverlay(image: image, in: geo)
                }

                VStack(spacing: 0) {
                    topBar
                    if camera.multiCamActive, !viewModel.isTalentFlipped {
                        cameraRow
                    }
                    Spacer()
                    bottomStack(in: geo)
                }
            }
            .background(Color.black)
            .ignoresSafeArea()
        }
        .onAppear { viewModel.onAppear() }
        .onDisappear { viewModel.onDisappear() }
        .sheet(isPresented: $viewModel.showPaywall) {
            PaywallView(subscription: subscription, proRequests: proRequests)
        }
        .sheet(isPresented: $showPhotoPicker) {
            PhotoPicker { image in
                viewModel.setPicture(image)
            }
        }
        .onChange(of: viewModel.toast) { _, newValue in
            guard newValue != nil else { return }
            Task {
                try? await Task.sleep(nanoseconds: 4_000_000_000)
                await MainActor.run {
                    if viewModel.toast == newValue { viewModel.toast = nil }
                }
            }
        }
    }

    // MARK: - Preview layers

    @ViewBuilder
    private func previewLayers(in geo: GeometryProxy) -> some View {
        if camera.multiCamActive {
            // Main feed full-screen; the other camera rides PiP.
            // The frame is explicit on purpose: a bare representable
            // with no intrinsic size can collapse to zero in a
            // ZStack, and its preview layer stays black — that is
            // exactly what Jeremy's screenshots showed (both cameras
            // live in the PiP, main black for either one). The PiP
            // works because it carries an explicit frame; the main
            // feed gets one too.
            // Pinch on the main feed zooms in and out; the picture
            // overlay and the PiP keep their own gestures.
            CameraPreviewView(layer: camera.mainIsFront ? camera.frontLayer : camera.backLayer)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .gesture(
                    MagnificationGesture()
                        .onChanged { scale in
                            if pinchStartZoom == nil {
                                pinchStartZoom = camera.zoomFactor
                            }
                            guard let start = pinchStartZoom else { return }
                            viewModel.setZoom(start * scale)
                        }
                        .onEnded { _ in
                            pinchStartZoom = nil
                        }
                )
            if (camera.mainIsFront ? camera.backCameraOn : camera.frontCameraOn) {
                pipView(layer: camera.mainIsFront ? camera.backLayer : camera.frontLayer, in: geo)
            }
        } else {
            // Session not up yet (or no camera): the status message
            // says what is wrong, in plain words.
            VStack(spacing: 12) {
                Image(systemName: "video.slash")
                    .font(.system(size: 44))
                    .foregroundColor(.white.opacity(0.6))
                Text(camera.statusMessage ?? "Starting camera…")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 32)
                if let message = camera.statusMessage,
                   message.lowercased().contains("permission") {
                    Button("Open Settings") {
                        if let url = URL(string: UIApplication.openSettingsURLString) {
                            UIApplication.shared.open(url)
                        }
                    }
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(.black)
                    .padding(.horizontal, 20)
                    .padding(.vertical, 12)
                    .background(Brand.neonGradient)
                    .clipShape(Capsule())
                }
            }
        }
    }

    private func pipView(layer: AVCaptureVideoPreviewLayer?, in geo: GeometryProxy) -> some View {
        let pipWidth = geo.size.width * 0.32
        let pipHeight = pipWidth * 4 / 3
        return CameraPreviewView(layer: layer)
            .frame(width: pipWidth, height: pipHeight)
            .clipShape(RoundedRectangle(cornerRadius: 12))
            .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.white.opacity(0.7), lineWidth: 1.5))
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
            .padding(.top, 64)
            .padding(.trailing, 16)
            .offset(pipOffset)
            .gesture(
                DragGesture()
                    .onChanged { value in
                        // Clamp so the PiP can never be dragged off
                        // screen or under the bottom controls.
                        let maxLeft = -(geo.size.width - pipWidth - 32)
                        let maxDown = geo.size.height - pipHeight - 300
                        pipOffset = CGSize(
                            width: min(0, max(maxLeft, pipStartOffset.width + value.translation.width)),
                            height: min(maxDown, max(-48, pipStartOffset.height + value.translation.height)))
                    }
                    .onEnded { _ in
                        pipStartOffset = pipOffset
                    }
            )
    }

    // MARK: - Live overlays on the preview

    private func captionOverlay(in geo: GeometryProxy) -> some View {
        Text(viewModel.captionText)
            .font(.system(size: 34, weight: .bold))
            .foregroundColor(.white)
            .shadow(color: .black.opacity(0.75), radius: 6, x: 0, y: 3)
            .multilineTextAlignment(.center)
            .padding(.horizontal, 24)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
            .offset(y: -geo.size.height * 0.18)
    }

    private func linkChipOverlay(in geo: GeometryProxy) -> some View {
        HStack(spacing: 6) {
            Image(systemName: "link")
                .font(.system(size: 14, weight: .bold))
            Text(viewModel.linkText)
                .font(.system(size: 15, weight: .bold))
                .lineLimit(1)
        }
        .foregroundColor(.white)
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(Brand.navy.opacity(0.92))
        .clipShape(Capsule())
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        .padding(.top, 108)
    }

    /// The checked-in place, top-left under the link row: pin + name,
    /// then the influencer's stars + one-liner, or Google's rating.
    /// Tapping it reopens the place card to edit the take or remove it.
    private func locationChipOverlay(place: Place) -> some View {
        Button {
            selectedTool = .location
        } label: {
            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 5) {
                    Image(systemName: "mappin.circle.fill")
                        .font(.system(size: 14, weight: .bold))
                    Text(place.name)
                        .font(.system(size: 15, weight: .bold))
                        .lineLimit(1)
                }
                if let stars = place.userStarString {
                    HStack(spacing: 6) {
                        Text(stars)
                            .font(.system(size: 13, weight: .bold))
                            .foregroundColor(Brand.gold)
                        if let verdict = place.userVerdict?.trimmingCharacters(in: .whitespacesAndNewlines), !verdict.isEmpty {
                            Text("“\(verdict)”")
                                .font(.system(size: 13, weight: .semibold))
                                .lineLimit(1)
                        }
                    }
                } else if let google = place.googleLine {
                    Text(google)
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(.white.opacity(0.85))
                }
            }
            .foregroundColor(.white)
            .padding(.horizontal, 14)
            .padding(.vertical, 9)
            .background(Brand.navy.opacity(0.92))
            .clipShape(Capsule())
        }
        .buttonStyle(.plain)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .padding(.top, viewModel.linkOnAir ? 168 : 108)
        .padding(.leading, 16)
    }

    private func pictureOverlay(image: UIImage, in geo: GeometryProxy) -> some View {
        let rect = viewModel.pictureRect
        let frame = CGRect(x: rect.minX * geo.size.width,
                           y: rect.minY * geo.size.height,
                           width: rect.width * geo.size.width,
                           height: rect.height * geo.size.height)
        return Image(uiImage: image)
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: frame.width, height: frame.height)
            .clipShape(RoundedRectangle(cornerRadius: 8))
            .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.white.opacity(0.8), lineWidth: 1.5))
            .shadow(radius: 8)
            .position(x: frame.midX, y: frame.midY)
            .gesture(
                DragGesture()
                    .onChanged { value in
                        // Move live from the rectangle where the drag
                        // started; the event closes and reopens when
                        // the drag ends, so the burn matches.
                        if dragStartRect == nil {
                            dragStartRect = rect
                        }
                        guard let start = dragStartRect else { return }
                        var moved = start
                        moved.origin.x += value.translation.width / geo.size.width
                        moved.origin.y += value.translation.height / geo.size.height
                        moved.origin.x = min(max(0, moved.origin.x), 1 - moved.width)
                        moved.origin.y = min(max(0, moved.origin.y), 1 - moved.height)
                        viewModel.pictureRect = moved
                    }
                    .onEnded { _ in
                        dragStartRect = nil
                        viewModel.pictureMoved(to: viewModel.pictureRect)
                    }
            )
            .simultaneousGesture(
                MagnificationGesture()
                    .onChanged { scale in
                        guard let start = pinchStartRect else {
                            pinchStartRect = rect
                            return
                        }
                        var resized = start
                        let newWidth = min(0.9, max(0.12, start.width * scale))
                        let newHeight = min(0.9, max(0.12, start.height * scale))
                        let center = CGPoint(x: start.midX, y: start.midY)
                        resized = CGRect(x: center.x - newWidth / 2,
                                         y: center.y - newHeight / 2,
                                         width: newWidth, height: newHeight)
                        resized.origin.x = min(max(0, resized.origin.x), 1 - resized.width)
                        resized.origin.y = min(max(0, resized.origin.y), 1 - resized.height)
                        viewModel.pictureRect = resized
                    }
                    .onEnded { _ in
                        pinchStartRect = nil
                        viewModel.pictureMoved(to: viewModel.pictureRect)
                    }
            )
    }

    // MARK: - Top bar

    private var topBar: some View {
        HStack {
            // Build stamp + recording clock, always visible.
            HStack(spacing: 8) {
                // The build stamp is also the owner's hidden unlock:
                // five taps and the owner never sees a paywall again,
                // in any build. Regular users just see a stamp.
                Button(action: stampTapped) {
                    PillLabel(text: Brand.buildStamp, color: Brand.cyan)
                }
                .buttonStyle(.plain)
                if viewModel.isRecording {
                    HStack(spacing: 6) {
                        Circle().fill(Color.red).frame(width: 10, height: 10)
                        Text(formattedElapsed)
                            .font(.system(size: 15, weight: .bold, design: .monospaced))
                            .foregroundColor(.white)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(Color.black.opacity(0.55))
                    .clipShape(Capsule())
                }
            }
            Spacer()
            if !viewModel.isTalentFlipped {
                Button(action: { viewModel.showPaywall = true }) {
                    Text(subscription.isPro ? "PRO ✓" : "GO PRO")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(subscription.isPro ? .black : .white)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(
                            Group {
                                if subscription.isPro {
                                    Brand.neonGradient
                                } else {
                                    Color.white.opacity(0.16)
                                }
                            }
                        )
                        .clipShape(Capsule())
                }
                .buttonStyle(.plain)
                Button(action: { viewModel.rotate() }) {
                    Label("ROTATE", systemImage: "rotate.right")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(Color.black.opacity(0.55))
                        .clipShape(Capsule())
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 16)
        .padding(.top, 56)
    }

    private var formattedElapsed: String {
        let total = Int(viewModel.elapsed)
        return String(format: "%02d:%02d", total / 60, total % 60)
    }

    // MARK: - Camera row

    /// Five taps on the build stamp turns the owner unlock on.
    private func stampTapped() {
        guard !subscription.ownerUnlocked else { return }
        stampTaps += 1
        if stampTaps >= 5 {
            stampTaps = 0
            subscription.unlockOwner()
            viewModel.toast = "Owner access on — everything unlocked."
        }
    }

    /// Which cameras are on, the zoom, and a restart — one slim row
    /// under the top bar. The toggles work live, mid-take.
    private var cameraRow: some View {
        HStack(spacing: 8) {
            cameraTogglePill(back: true)
            cameraTogglePill(back: false)
            zoomPill
            Spacer()
            Button(action: { viewModel.restartCameras() }) {
                Label("RESTART", systemImage: "arrow.clockwise")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 7)
                    .background(Color.black.opacity(0.55))
                    .clipShape(Capsule())
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 16)
        .padding(.top, 8)
    }

    private func cameraTogglePill(back: Bool) -> some View {
        let isOn = back ? camera.backCameraOn : camera.frontCameraOn
        return Button(action: { viewModel.toggleCamera(back: back) }) {
            HStack(spacing: 5) {
                Image(systemName: isOn ? "video.fill" : "video.slash.fill")
                    .font(.system(size: 11, weight: .bold))
                Text(back ? "BACK" : "FRONT")
                    .font(.system(size: 11, weight: .bold))
            }
            .foregroundColor(isOn ? .black : .white)
            .padding(.horizontal, 10)
            .padding(.vertical, 7)
            .background(
                Group {
                    if isOn {
                        Brand.neonGradient
                    } else {
                        Color.white.opacity(0.16)
                    }
                }
            )
            .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }

    /// The zoom, as a number. Tap to step 1x → 2x → 3x → 1x;
    /// pinch the picture for anything in between.
    private var zoomPill: some View {
        Button(action: { viewModel.cycleZoom() }) {
            Text(String(format: "%.1f×", camera.zoomFactor))
                .font(.system(size: 12, weight: .bold, design: .monospaced))
                .foregroundColor(.white)
                .padding(.horizontal, 10)
                .padding(.vertical, 7)
                .background(Color.black.opacity(0.55))
                .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }

    // MARK: - Bottom stack

    @ViewBuilder
    private func bottomStack(in geo: GeometryProxy) -> some View {
        if viewModel.isTalentFlipped {
            talentBottom
        } else {
            VStack(spacing: 10) {
                if viewModel.lowerThirdOnAir {
                    lowerThirdLiveView
                }
                if let toast = viewModel.toast {
                    PillLabel(text: toast)
                }
                EditPanelView(viewModel: viewModel, selectedTool: $selectedTool) {
                    if viewModel.requestPicturePicker() {
                        showPhotoPicker = true
                    }
                }
                operatorControls
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 28)
        }
    }

    /// The live lower third, as the operator and the talent see it:
    /// name on navy, title on white, gold bar on the left.
    private var lowerThirdLiveView: some View {
        let name = viewModel.lowerThird.name
        let title = viewModel.lowerThird.title
        return HStack(spacing: 0) {
            Rectangle()
                .fill(Brand.gold)
                .frame(width: 6)
            VStack(alignment: .leading, spacing: 0) {
                if !name.isEmpty {
                    Text(name.uppercased())
                        .font(.system(size: 20, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Brand.navy)
                }
                if !title.isEmpty {
                    Text(title)
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(Brand.navy)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 7)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.white)
                }
            }
        }
        .frame(maxWidth: .infinity)
        .clipShape(RoundedRectangle(cornerRadius: 8))
    }

    /// Operator controls: five big thumb buttons around a huge REC.
    private var operatorControls: some View {
        HStack(spacing: 12) {
            OperatorButton(label: "PHOTO", systemImage: "camera") {
                viewModel.takePhoto()
            }
            OperatorButton(label: "SWAP", systemImage: "arrow.triangle.2.circlepath") {
                viewModel.swapMain()
            }
            RecordButton(isRecording: viewModel.isRecording) {
                viewModel.toggleRecording()
            }
            OperatorButton(label: "FLIP", systemImage: "person.crop.rectangle") {
                viewModel.toggleTalentFlip()
            }
            OperatorButton(label: "LIGHT", systemImage: "sun.max.fill", isActive: viewModel.frontLightOn) {
                viewModel.frontLightOn.toggle()
            }
        }
        .frame(maxWidth: .infinity)
        .opacity(viewModel.isFinishing ? 0.5 : 1.0)
        .disabled(viewModel.isFinishing)
    }

    /// The flipped screen: the influencer's side. One huge STOP they
    /// cannot miss, a small flip-back, and nothing else — the operator
    /// runs the edit panel, not the talent. The volume buttons stop
    /// the take too.
    private var talentBottom: some View {
        VStack(spacing: 12) {
            if viewModel.isRecording {
                HStack(spacing: 6) {
                    Circle().fill(Color.red).frame(width: 10, height: 10)
                    Text(formattedElapsed)
                        .font(.system(size: 17, weight: .bold, design: .monospaced))
                        .foregroundColor(.white)
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 8)
                .background(Color.black.opacity(0.55))
                .clipShape(Capsule())
            }
            Button(action: { viewModel.toggleRecording() }) {
                Text(viewModel.isRecording ? "■  STOP" : "●  RECORD")
                    .font(.system(size: 26, weight: .bold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 88)
                    .background(viewModel.isRecording ? AnyShapeStyle(Color.red) : AnyShapeStyle(Brand.neonGradient))
                    .clipShape(RoundedRectangle(cornerRadius: 18))
            }
            .buttonStyle(.plain)
            .disabled(viewModel.isFinishing)
            Button(action: { viewModel.toggleTalentFlip() }) {
                Text("Flip back to operator")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(.white.opacity(0.85))
                    .padding(.horizontal, 18)
                    .padding(.vertical, 10)
                    .background(Color.white.opacity(0.16))
                    .clipShape(Capsule())
            }
            .buttonStyle(.plain)
            if let toast = viewModel.toast {
                PillLabel(text: toast)
            }
        }
        .padding(.horizontal, 20)
        .padding(.bottom, 36)
    }
}
