import AVFoundation
import SwiftUI

/// Embeds an AVCaptureVideoPreviewLayer in SwiftUI. The layer is
/// handed in from the camera service; this view only hosts it and
/// keeps its frame in step with the view's bounds.
struct CameraPreviewView: UIViewRepresentable {
    var layer: AVCaptureVideoPreviewLayer?

    func makeUIView(context: Context) -> PreviewHostView {
        PreviewHostView()
    }

    func updateUIView(_ uiView: PreviewHostView, context: Context) {
        if uiView.hostedLayer !== layer {
            uiView.hostedLayer?.removeFromSuperlayer()
            uiView.hostedLayer = layer
            if let layer {
                uiView.layer.addSublayer(layer)
            }
        }
        if let layer {
            layer.frame = uiView.bounds
        }
    }

    final class PreviewHostView: UIView {
        var hostedLayer: AVCaptureVideoPreviewLayer?
        override func layoutSubviews() {
            super.layoutSubviews()
            hostedLayer?.frame = bounds
        }
    }
}
