import SwiftUI

/// The paywall, in the logo's cyan-to-magenta style. It shows what Pro
/// unlocks, the price, the 5-day free trial, and Subscribe + Restore.
/// It also holds the two free-access paths for famous influencers:
/// redeeming an offer code Jeremy issued, and asking for free Pro
/// access (name + handle) for Jeremy to approve.
///
/// The paywall never appears for a Pro user — subscribed, in trial or
/// comped all count as Pro, and the state machine is the only thing
/// that decides that.
struct PaywallView: View {
    @ObservedObject var subscription: SubscriptionService
    @ObservedObject var proRequests: ProRequestStore
    @Environment(\.dismiss) private var dismiss

    @State private var showRequestForm = false
    @State private var requestName = ""
    @State private var requestHandle = ""
    @State private var requestPlatform = "Instagram"
    @State private var submittedRequest: ProRequest?
    @State private var showShareRequest = false

    private let requestPlatforms = ["Instagram", "TikTok", "Facebook", "YouTube", "Other"]

    var body: some View {
        NavigationStack {
            ZStack {
                Brand.background.ignoresSafeArea()
                ScrollView {
                    VStack(spacing: 20) {
                        logo
                        if subscription.isPro {
                            proState
                        } else {
                            offer
                            subscribeButton
                            restoreAndRedeem
                            requestFreeAccess
                        }
                    }
                    .padding(20)
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                        .foregroundColor(.white)
                }
            }
            .toolbarBackground(Brand.navy, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .sheet(isPresented: $showShareRequest) {
                if let request = submittedRequest {
                    ShareSheet(items: [request.shareText])
                }
            }
            .task {
                await subscription.refresh()
            }
        }
    }

    // MARK: - Logo

    private var logo: some View {
        VStack(spacing: 8) {
            Image("LaunchLogo")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 200, height: 200)
                .clipShape(RoundedRectangle(cornerRadius: 28))
            Text("INFLUENCER DÚO")
                .font(.system(size: 22, weight: .bold))
                .foregroundStyle(Brand.neonGradient)
            Text("Pro")
                .font(.system(size: 15, weight: .semibold))
                .foregroundColor(.white.opacity(0.7))
        }
    }

    // MARK: - Already Pro

    private var proState: some View {
        VStack(spacing: 14) {
            Image(systemName: "checkmark.seal.fill")
                .font(.system(size: 48))
                .foregroundStyle(Brand.neonGradient)
            Text("You're Pro")
                .font(.system(size: 22, weight: .bold))
                .foregroundColor(.white)
            Text(subscription.statusText)
                .font(.system(size: 15))
                .foregroundColor(.white.opacity(0.75))
            Button("Manage subscription") {
                subscription.manageSubscription()
            }
            .font(.system(size: 15, weight: .bold))
            .foregroundColor(.white)
            .padding(.horizontal, 20)
            .padding(.vertical, 12)
            .background(Color.white.opacity(0.16))
            .clipShape(Capsule())
            Button("Restore purchases") {
                Task { await subscription.restore() }
            }
            .font(.system(size: 14, weight: .semibold))
            .foregroundColor(.white.opacity(0.8))
            .disabled(subscription.isBusy)
            if let error = subscription.errorMessage {
                Text(error)
                    .font(.system(size: 13))
                    .foregroundColor(.red.opacity(0.9))
                    .multilineTextAlignment(.center)
            }
        }
    }

    // MARK: - The offer

    private var offer: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Pro unlocks")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(.white)
            unlockRow(icon: "paperplane.fill", title: "Auto-post everywhere",
                      detail: "Finished videos post themselves to your Facebook Page, Instagram and TikTok — even when you filmed offline.")
            unlockRow(icon: "textformat", title: "Live edit while recording",
                      detail: "Lower thirds, captions, links and pictures, fired mid-take by your operator and burned into the video.")
            unlockRow(icon: "person.crop.rectangle", title: "Flip talent monitor",
                      detail: "Turn the phone around — the influencer watches themselves live, with a huge Stop button and volume-button control.")
            unlockRow(icon: "moon.stars", title: "Always yours",
                      detail: "The camera, recording and photos stay free. Your recorded videos are never locked away, Pro or not.")
            HStack(alignment: .firstTextBaseline, spacing: 6) {
                Text(subscription.priceDisplay)
                    .font(.system(size: 30, weight: .bold))
                    .foregroundColor(.white)
                Text("/ month")
                    .font(.system(size: 15))
                    .foregroundColor(.white.opacity(0.7))
            }
            Text("Start with a \(subscription.trialDisplay), then \(subscription.priceDisplay)/month. Cancel anytime from Settings — your videos stay yours.")
                .font(.system(size: 14))
                .foregroundColor(.white.opacity(0.75))
        }
        .padding(16)
        .background(Brand.navyLight)
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    private func unlockRow(icon: String, title: String, detail: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(Brand.neonGradient)
                .frame(width: 26)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 15, weight: .bold))
                    .foregroundColor(.white)
                Text(detail)
                    .font(.system(size: 13))
                    .foregroundColor(.white.opacity(0.75))
            }
        }
    }

    // MARK: - Subscribe / restore / redeem

    private var subscribeButton: some View {
        VStack(spacing: 10) {
            Button {
                Task {
                    if await subscription.purchase() {
                        dismiss()
                    }
                }
            } label: {
                HStack {
                    if subscription.isBusy {
                        ProgressView()
                            .tint(.white)
                    }
                    Text("Start \(subscription.trialDisplay) — free")
                        .font(.system(size: 18, weight: .bold))
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .frame(height: 58)
                .background(Brand.neonGradient)
                .clipShape(RoundedRectangle(cornerRadius: 14))
            }
            .buttonStyle(.plain)
            .disabled(subscription.isBusy)
            if let error = subscription.errorMessage {
                Text(error)
                    .font(.system(size: 13))
                    .foregroundColor(.red.opacity(0.9))
                    .multilineTextAlignment(.center)
            }
            Text("Payment goes through Apple. The trial is free — you are only charged after it ends, and only if you keep Pro.")
                .font(.system(size: 12))
                .foregroundColor(.white.opacity(0.6))
                .multilineTextAlignment(.center)
        }
    }

    private var restoreAndRedeem: some View {
        HStack(spacing: 12) {
            Button("Restore purchases") {
                Task { await subscription.restore() }
            }
            .font(.system(size: 14, weight: .bold))
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 46)
            .background(Color.white.opacity(0.16))
            .clipShape(RoundedRectangle(cornerRadius: 12))
            .buttonStyle(.plain)
            .disabled(subscription.isBusy)
            Button("Redeem offer code") {
                subscription.presentOfferCodeRedeemSheet()
            }
            .font(.system(size: 14, weight: .bold))
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 46)
            .background(Color.white.opacity(0.16))
            .clipShape(RoundedRectangle(cornerRadius: 12))
            .buttonStyle(.plain)
        }
    }

    // MARK: - Request free Pro access

    private var requestFreeAccess: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Famous influencer? Get Pro free.")
                .font(.system(size: 16, weight: .bold))
                .foregroundColor(.white)
            Text("If you are a well-known creator, ask for free Pro access. Jeremy reviews every request himself — nothing is granted automatically.")
                .font(.system(size: 13))
                .foregroundColor(.white.opacity(0.75))
            if let request = submittedRequest {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Request received — thank you, \(request.name).")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(.white)
                    Text("Jeremy will look up \(request.handle) and get back to you. Nothing is free until he approves it — if he does, he'll send you an offer code to redeem here.")
                        .font(.system(size: 13))
                        .foregroundColor(.white.opacity(0.75))
                    Button("Send the request to Jeremy") {
                        showShareRequest = true
                    }
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                    .background(Brand.neonGradient)
                    .clipShape(Capsule())
                }
            } else if showRequestForm {
                TextField("Your name", text: $requestName)
                    .textFieldStyle(.roundedBorder)
                    .textInputAutocapitalization(.words)
                TextField("Your handle — @name", text: $requestHandle)
                    .textFieldStyle(.roundedBorder)
                    .autocorrectionDisabled(true)
                    .textInputAutocapitalization(.never)
                Picker("Biggest platform", selection: $requestPlatform) {
                    ForEach(requestPlatforms, id: \.self) { platform in
                        Text(platform).tag(platform)
                    }
                }
                .pickerStyle(.segmented)
                Button("Send request") {
                    if let saved = proRequests.submit(name: requestName, handle: requestHandle, platform: requestPlatform) {
                        submittedRequest = saved
                        requestName = ""
                        requestHandle = ""
                    }
                }
                .font(.system(size: 15, weight: .bold))
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .frame(height: 50)
                .background(Brand.neonGradient)
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .buttonStyle(.plain)
            } else {
                Button("Request free Pro access") {
                    showRequestForm = true
                }
                .font(.system(size: 14, weight: .bold))
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .frame(height: 46)
                .background(Color.white.opacity(0.16))
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .buttonStyle(.plain)
            }
        }
        .padding(16)
        .background(Brand.navyLight)
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}
