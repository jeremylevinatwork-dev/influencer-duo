import SwiftUI
import UIKit

/// The iOS share sheet: AirDrop, Messages, Mail, TikTok, and any app
/// the user has installed. This is the fallback for everything the
/// auto-post APIs cannot do — personal Facebook profiles, Instagram
/// photos, TikTok photos — and the plain way to send a finished video
/// anywhere.
struct ShareSheet: UIViewControllerRepresentable {
    var items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
