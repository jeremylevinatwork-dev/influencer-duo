import SwiftUI

/// What the influencer sees on the phone's outer display while the
/// operator works the inner screen: themselves, live, from the back
/// camera full-screen, with the front camera riding small in the
/// corner — the same dual view the operator sees, minus the
/// controls. A LIVE pill shows while a take is recording, so the
/// influencer always knows when they are on.
struct OuterDisplayView: View {
    @ObservedObject var camera: CameraService

    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.ignoresSafeArea()
                // The influencer, full-screen, from the back camera.
                CameraPreviewView(role: .outerBack, camera: camera)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                // The operator, small in the corner, from the front
                // camera — the dual view, mirrored for the talent.
                if camera.frontCameraOn {
                    CameraPreviewView(role: .outerFront, camera: camera)
                        .frame(width: geo.size.width * 0.32, height: geo.size.width * 0.32 * 4 / 3)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.white.opacity(0.7), lineWidth: 1.5))
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
                        .padding(.top, 16)
                        .padding(.trailing, 16)
                }
                if camera.isRecording {
                    HStack(spacing: 6) {
                        Circle().fill(Color.red).frame(width: 10, height: 10)
                        Text("LIVE")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundColor(.white)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(Color.black.opacity(0.55))
                    .clipShape(Capsule())
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                    .padding(.top, 16)
                    .padding(.leading, 16)
                }
            }
        }
        .background(Color.black)
        .ignoresSafeArea()
    }
}
