import SwiftUI

/// The Library tab: a grid of everything the app has filmed or
/// photographed, stored on the device. Each tile shows its thumbnail,
/// its queue status (waiting / uploading / failed — never silent),
/// and taps through to the detail sheet.
struct LibraryView: View {
    @ObservedObject var viewModel: LibraryViewModel
    @ObservedObject var subscription: SubscriptionService
    var proRequests: ProRequestStore

    private let columns = [
        GridItem(.flexible(), spacing: 8),
        GridItem(.flexible(), spacing: 8),
        GridItem(.flexible(), spacing: 8)
    ]

    var body: some View {
        NavigationStack {
            ZStack {
                Brand.background.ignoresSafeArea()
                if viewModel.library.items.isEmpty {
                    emptyState
                } else {
                    ScrollView {
                        if let summary = viewModel.queueSummary {
                            HStack {
                                Image(systemName: "tray.and.arrow.up")
                                Text(summary)
                                    .font(.system(size: 13, weight: .semibold))
                            }
                            .foregroundColor(.white.opacity(0.85))
                            .padding(.horizontal, 16)
                            .padding(.vertical, 10)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Brand.navyLight)
                        }
                        LazyVGrid(columns: columns, spacing: 8) {
                            ForEach(viewModel.library.items) { item in
                                LibraryTile(item: item, viewModel: viewModel)
                            }
                        }
                        .padding(12)
                    }
                }
            }
            .navigationTitle("Library")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(Brand.navy, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .sheet(item: $viewModel.selectedItem) { item in
                MediaDetailView(item: item, viewModel: viewModel, subscription: subscription, proRequests: proRequests)
            }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 16) {
            Image("LaunchLogo")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 180, height: 180)
                .clipShape(RoundedRectangle(cornerRadius: 24))
            Text("Nothing filmed yet")
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(.white)
            Text("Go to the Camera tab, hit the big red button, and your videos and photos will live here — on the device, even with no signal.")
                .font(.system(size: 15))
                .foregroundColor(.white.opacity(0.7))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
        }
    }
}

private struct LibraryTile: View {
    var item: MediaItem
    @ObservedObject var viewModel: LibraryViewModel

    var body: some View {
        Button {
            viewModel.selectedItem = item
        } label: {
            ZStack(alignment: .bottomLeading) {
                Rectangle()
                    .fill(Brand.navyLight)
                    .aspectRatio(1, contentMode: .fit)
                if let image = viewModel.thumbnail(for: item) {
                    Image(uiImage: image)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .clipped()
                } else {
                    Image(systemName: item.kind == .video ? "film" : "photo")
                        .font(.system(size: 28))
                        .foregroundColor(.white.opacity(0.5))
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
                VStack(alignment: .leading, spacing: 2) {
                    if item.kind == .video, let duration = item.duration {
                        Text(formattedDuration(duration))
                            .font(.system(size: 11, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(Color.black.opacity(0.6))
                            .clipShape(Capsule())
                    }
                    if let place = item.location {
                        HStack(spacing: 3) {
                            Image(systemName: "mappin.circle.fill")
                            Text(place.name)
                        }
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color.black.opacity(0.6))
                        .clipShape(Capsule())
                        .lineLimit(1)
                    }
                    jobBadge
                }
                .padding(6)
            }
        }
        .buttonStyle(.plain)
        .clipShape(RoundedRectangle(cornerRadius: 10))
        .onAppear { viewModel.loadThumbnail(for: item) }
    }

    @ViewBuilder
    private var jobBadge: some View {
        let jobs = viewModel.jobs(for: item)
        if jobs.contains(where: { $0.state == .failed }) {
            Text("⚠ Post failed — tap to retry")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.white)
                .padding(.horizontal, 6)
                .padding(.vertical, 2)
                .background(Color.red)
                .clipShape(Capsule())
        } else if jobs.contains(where: { $0.state == .uploading }) {
            Text("Uploading…")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.black)
                .padding(.horizontal, 6)
                .padding(.vertical, 2)
                .background(Brand.cyan)
                .clipShape(Capsule())
        } else if jobs.contains(where: { $0.state == .queued }) {
            Text("Queued — will post when online")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.black)
                .padding(.horizontal, 6)
                .padding(.vertical, 2)
                .background(Brand.gold)
                .clipShape(Capsule())
        } else if !item.postedPlatforms.isEmpty {
            Text("Posted: \(item.postedPlatforms.joined(separator: ", "))")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.white)
                .padding(.horizontal, 6)
                .padding(.vertical, 2)
                .background(Color.black.opacity(0.6))
                .clipShape(Capsule())
        }
    }

    private func formattedDuration(_ seconds: TimeInterval) -> String {
        let total = Int(seconds)
        return String(format: "%d:%02d", total / 60, total % 60)
    }
}
