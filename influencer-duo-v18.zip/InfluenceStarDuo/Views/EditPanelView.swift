import SwiftUI

/// The operator's live-edit tools. One row of big thumb buttons that
/// never leaves the screen while recording, and one compact editor
/// that opens under the tool that was tapped. The editor is a short
/// strip docked at the bottom — it never reaches up over the person
/// being filmed.
enum EditTool: String, CaseIterable {
    case lowerThird = "LOWER 3RD"
    case caption = "CAPTION"
    case picture = "PICTURE"
    case link = "LINK"
    case location = "LOCATION"
}

struct EditPanelView: View {
    @ObservedObject var viewModel: CameraViewModel
    @Binding var selectedTool: EditTool?
    var onPickPicture: () -> Void

    var body: some View {
        VStack(spacing: 8) {
            if let tool = selectedTool {
                editor(for: tool)
            }
            toolStrip
        }
    }

    // MARK: - Tool strip

    private var toolStrip: some View {
        HStack(spacing: 8) {
            ForEach(EditTool.allCases, id: \.self) { tool in
                Button {
                    withAnimation(.easeInOut(duration: 0.15)) {
                        selectedTool = (selectedTool == tool) ? nil : tool
                    }
                    if tool == .location, selectedTool == .location {
                        viewModel.locationToolOpened()
                    }
                } label: {
                    HStack(spacing: 5) {
                        if isOnAir(tool) {
                            Circle().fill(Color.red).frame(width: 8, height: 8)
                        }
                        Text(tool.rawValue)
                            .font(.system(size: 12, weight: .bold))
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 44)
                    .foregroundColor(.white)
                    .background(
                        Group {
                            if isOnAir(tool) {
                                Brand.neonGradient
                            } else {
                                Color.white.opacity(0.16)
                            }
                        }
                    )
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                }
                .buttonStyle(.plain)
            }
        }
    }

    private func isOnAir(_ tool: EditTool) -> Bool {
        switch tool {
        case .lowerThird: return viewModel.lowerThirdOnAir
        case .caption: return viewModel.captionOnAir
        case .picture: return viewModel.pictureOnAir
        case .link: return viewModel.linkOnAir
        case .location: return viewModel.locationOnAir
        }
    }

    // MARK: - Editors

    @ViewBuilder
    private func editor(for tool: EditTool) -> some View {
        VStack(spacing: 8) {
            switch tool {
            case .lowerThird:
                TextField("Name", text: $viewModel.lowerThird.name)
                    .textFieldStyle(.roundedBorder)
                    .autocorrectionDisabled(true)
                    .textInputAutocapitalization(.words)
                TextField("Title", text: $viewModel.lowerThird.title)
                    .textFieldStyle(.roundedBorder)
                    .autocorrectionDisabled(true)
                    .textInputAutocapitalization(.words)
                fireButton(title: viewModel.lowerThirdOnAir ? "HIDE LOWER THIRD" : "FIRE LOWER THIRD",
                           isOnAir: viewModel.lowerThirdOnAir) {
                    viewModel.lowerThirdOnAir ? viewModel.hideLowerThird() : viewModel.fireLowerThird()
                }
            case .caption:
                TextField("Caption text", text: $viewModel.captionText)
                    .textFieldStyle(.roundedBorder)
                    .autocorrectionDisabled(false)
                fireButton(title: viewModel.captionOnAir ? "HIDE CAPTION" : "FIRE CAPTION",
                           isOnAir: viewModel.captionOnAir) {
                    viewModel.captionOnAir ? viewModel.hideCaption() : viewModel.fireCaption()
                }
            case .picture:
                Button(action: onPickPicture) {
                    Label("CHOOSE A PICTURE", systemImage: "photo.on.rectangle")
                        .font(.system(size: 14, weight: .bold))
                        .frame(maxWidth: .infinity)
                        .frame(height: 52)
                        .foregroundColor(.white)
                        .background(Brand.neonGradient)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                .buttonStyle(.plain)
                if viewModel.pictureOnAir {
                    fireButton(title: "HIDE PICTURE", isOnAir: true) {
                        viewModel.hidePicture()
                    }
                    Text("Drag the picture to move it · pinch to resize")
                        .font(.system(size: 12))
                        .foregroundColor(.white.opacity(0.7))
                }
            case .link:
                TextField("Link — example.com", text: $viewModel.linkText)
                    .textFieldStyle(.roundedBorder)
                    .keyboardType(.URL)
                    .autocorrectionDisabled(true)
                    .textInputAutocapitalization(.never)
                fireButton(title: viewModel.linkOnAir ? "HIDE LINK" : "FIRE LINK",
                           isOnAir: viewModel.linkOnAir) {
                    viewModel.linkOnAir ? viewModel.hideLink() : viewModel.fireLink()
                }
                Text("The link is burned into the video and added to the post text.")
                    .font(.system(size: 12))
                    .foregroundColor(.white.opacity(0.7))
            case .location:
                locationEditor
            }
        }
        .padding(10)
        .background(Brand.panel)
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    // MARK: - Location editor (check-in + quick review)

    /// The place card: what the phone found, Google's rating when there
    /// is one, and the influencer's quick take — 5 tappable stars and a
    /// one-line verdict — then Attach. When a place is already attached
    /// the same card edits the review live, or removes the place.
    @ViewBuilder
    private var locationEditor: some View {
        if viewModel.locationFinding {
            HStack(spacing: 10) {
                ProgressView()
                    .tint(.white)
                Text("Finding where you are…")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.white)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.vertical, 8)
        } else if let error = viewModel.locationError {
            Text(error)
                .font(.system(size: 14))
                .foregroundColor(.white.opacity(0.85))
                .frame(maxWidth: .infinity, alignment: .leading)
            fireButton(title: "TRY AGAIN", isOnAir: false) {
                viewModel.findLocation()
            }
        } else if let place = viewModel.locationCardPlace {
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 6) {
                    Image(systemName: "mappin.circle.fill")
                        .foregroundColor(Brand.cyan)
                    Text(place.name)
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(.white)
                        .lineLimit(1)
                }
                if !place.address.isEmpty {
                    Text(place.address)
                        .font(.system(size: 13))
                        .foregroundColor(.white.opacity(0.7))
                        .lineLimit(1)
                }
                if let google = place.googleLine {
                    Text(google)
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(Brand.gold)
                }
                Text("YOUR TAKE")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundColor(.white.opacity(0.6))
                    .padding(.top, 2)
                HStack(spacing: 8) {
                    ForEach(1...5, id: \.self) { star in
                        Button {
                            viewModel.setReviewStars(star)
                        } label: {
                            Image(systemName: star <= viewModel.reviewStars ? "star.fill" : "star")
                                .font(.system(size: 28))
                                .foregroundColor(star <= viewModel.reviewStars ? Brand.gold : .white.opacity(0.4))
                        }
                        .buttonStyle(.plain)
                    }
                }
                TextField("One-line take — optional", text: $viewModel.reviewVerdict)
                    .textFieldStyle(.roundedBorder)
                    .autocorrectionDisabled(false)
                    .submitLabel(.done)
                    .onChange(of: viewModel.reviewVerdict) { _, _ in
                        viewModel.reviewVerdictChanged()
                    }
                if viewModel.locationOnAir {
                    fireButton(title: "REMOVE LOCATION", isOnAir: true) {
                        viewModel.removeLocation()
                    }
                    Text("Attached — it shows on screen, burns into the video, and goes in the post caption.")
                        .font(.system(size: 12))
                        .foregroundColor(.white.opacity(0.7))
                } else {
                    fireButton(title: "ATTACH LOCATION", isOnAir: false) {
                        viewModel.attachLocation()
                    }
                    Text("Checks you in here. Your stars and one-liner ride along with it.")
                        .font(.system(size: 12))
                        .foregroundColor(.white.opacity(0.7))
                }
            }
        } else {
            Text("Add the place you're filming at — like checking in, with your quick take on it.")
                .font(.system(size: 14))
                .foregroundColor(.white.opacity(0.85))
                .frame(maxWidth: .infinity, alignment: .leading)
            fireButton(title: "FIND MY PLACE", isOnAir: false) {
                viewModel.findLocation()
            }
        }
    }

    private func fireButton(title: String, isOnAir: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 15, weight: .bold))
                .frame(maxWidth: .infinity)
                .frame(height: 52)
                .foregroundColor(.white)
                .background(
                    Group {
                        if isOnAir {
                            Color.red
                        } else {
                            Brand.neonGradient
                        }
                    }
                )
                .clipShape(RoundedRectangle(cornerRadius: 12))
        }
        .buttonStyle(.plain)
    }
}
