import SwiftUI

/// The Accounts tab: the subscription, and the three platforms an
/// influencer can connect for auto-post — Facebook Page, Instagram
/// Business, TikTok. Each account has its own auto-post switch, and
/// those switches decide everything about posting: the app posts
/// ONLY to accounts that are connected AND switched on, never to a
/// platform the user did not choose, never to a switched-off account.
///
/// The honest limits are on screen, not hidden: personal Facebook
/// profiles cannot be auto-posted (Meta removed that), and Instagram
/// and TikTok photos go through Share — their APIs take video only.
struct AccountsView: View {
    @ObservedObject var viewModel: AccountsViewModel
    @ObservedObject var subscription: SubscriptionService
    var proRequests: ProRequestStore

    @State private var tiktokSecret = ""
    @State private var showPaywall = false

    var body: some View {
        NavigationStack {
            ZStack {
                Brand.background.ignoresSafeArea()
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        subscriptionSection
                        metaSection
                        tiktokSection
                        connectedSection
                        limitsSection
                    }
                    .padding(16)
                }
            }
            .navigationTitle("Accounts")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(Brand.navy, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .sheet(isPresented: $showPaywall) {
                PaywallView(subscription: subscription, proRequests: proRequests)
            }
            .onAppear {
                tiktokSecret = viewModel.savedTikTokClientSecret
            }
        }
    }

    // MARK: - Subscription

    private var subscriptionSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            sectionTitle("SUBSCRIPTION")
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(subscription.isPro ? "Pro" : "Free")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.white)
                    Text(subscription.statusText)
                        .font(.system(size: 13))
                        .foregroundColor(.white.opacity(0.7))
                }
                Spacer()
                Button(subscription.isPro ? "Manage" : "Go Pro") {
                    showPaywall = true
                }
                .font(.system(size: 14, weight: .bold))
                .foregroundColor(subscription.isPro ? .black : .white)
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .background(
                    Group {
                        if subscription.isPro {
                            Brand.neonGradient
                        } else {
                            Color.white.opacity(0.16)
                        }
                    }
                )
                .clipShape(Capsule())
                .buttonStyle(.plain)
            }
            Text("Pro unlocks auto-post, live-edit overlays and the flip talent monitor. The camera, recording and photos are free either way.")
                .font(.system(size: 13))
                .foregroundColor(.white.opacity(0.7))
        }
        .padding(14)
        .background(Brand.navyLight)
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    // MARK: - Meta (Facebook + Instagram)

    private var metaSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            sectionTitle("FACEBOOK & INSTAGRAM")
            Text("Connect with Facebook Login. Your Pages come across, and any Instagram Business or Creator account linked to a Page comes with them.")
                .font(.system(size: 13))
                .foregroundColor(.white.opacity(0.75))
            TextField("Meta App ID", text: $viewModel.metaAppID)
                .textFieldStyle(.roundedBorder)
                .autocorrectionDisabled(true)
                .textInputAutocapitalization(.never)
                .onChange(of: viewModel.metaAppID) { _, _ in viewModel.saveMetaAppID() }
            Button {
                viewModel.connectMeta()
            } label: {
                Label("Connect Facebook", systemImage: "person.crop.circle.badge.plus")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                    .background(Brand.neonGradient)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            .buttonStyle(.plain)
            .disabled(viewModel.isConnecting)
            Text("Your Meta App ID comes from your app at developers.facebook.com — add Facebook Login and the Instagram Graph API products, and allow the redirect influencestar://oauth. Until it is set, the button explains instead of failing.")
                .font(.system(size: 12))
                .foregroundColor(.white.opacity(0.6))
            if let message = viewModel.connectMessage {
                Text(message)
                    .font(.system(size: 13))
                    .foregroundColor(.white)
                    .padding(10)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Brand.navyLight)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
            }
        }
        .padding(14)
        .background(Brand.navyLight)
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    // MARK: - TikTok

    private var tiktokSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            sectionTitle("TIKTOK")
            Text("Connect with TikTok Login Kit. Videos auto-post through TikTok's Content Posting API; photos go through Share — TikTok's API can't post photos.")
                .font(.system(size: 13))
                .foregroundColor(.white.opacity(0.75))
            TextField("TikTok Client Key", text: $viewModel.tiktokClientKey)
                .textFieldStyle(.roundedBorder)
                .autocorrectionDisabled(true)
                .textInputAutocapitalization(.never)
                .onChange(of: viewModel.tiktokClientKey) { _, _ in viewModel.saveTikTokClientKey() }
            SecureField("TikTok Client Secret", text: $tiktokSecret)
                .textFieldStyle(.roundedBorder)
                .autocorrectionDisabled(true)
                .textInputAutocapitalization(.never)
            Button {
                viewModel.connectTikTok(clientSecret: tiktokSecret)
            } label: {
                Label("Connect TikTok", systemImage: "music.note")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                    .background(Brand.neonGradient)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            .buttonStyle(.plain)
            .disabled(viewModel.isConnecting)
            Text("The Client Key and Secret come from your app at developers.tiktok.com — add Login Kit and the Content Posting API, and allow the redirect influencestar://tiktok-auth. The secret is kept in your device Keychain, never in code; its proper home is a small server, and the README says so.")
                .font(.system(size: 12))
                .foregroundColor(.white.opacity(0.6))
        }
        .padding(14)
        .background(Brand.navyLight)
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    // MARK: - Connected accounts

    private var connectedSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            sectionTitle("CONNECTED")
            if viewModel.connectedAccounts.isEmpty {
                Text("No accounts connected yet. Connect one above to auto-post.")
                    .font(.system(size: 14))
                    .foregroundColor(.white.opacity(0.75))
            } else {
                ForEach(viewModel.connectedAccounts) { account in
                    accountRow(account)
                }
            }
        }
        .padding(14)
        .background(Brand.navyLight)
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private func accountRow(_ account: SocialAccount) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(account.displayName)
                        .font(.system(size: 15, weight: .bold))
                        .foregroundColor(.white)
                    Text(account.platformLabel)
                        .font(.system(size: 12))
                        .foregroundColor(.white.opacity(0.7))
                }
                Spacer()
                Toggle("Auto-post", isOn: Binding(
                    get: { account.autoPost },
                    set: { viewModel.setAutoPost(account, on: $0) }
                ))
                .labelsHidden()
                .tint(Brand.cyan)
            }
            Text(account.platformNote)
                .font(.system(size: 12))
                .foregroundColor(.white.opacity(0.6))
            HStack(spacing: 12) {
                if account.needsReconnect {
                    Text("Sign-in expired — tap Connect again to reconnect.")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(.red.opacity(0.9))
                }
                Spacer()
                Button("Disconnect") {
                    viewModel.disconnect(account)
                }
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(.red.opacity(0.9))
            }
        }
        .padding(12)
        .background(Color.white.opacity(0.06))
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }

    // MARK: - Honest limits

    private var limitsSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            sectionTitle("WHAT AUTO-POST CAN AND CAN'T DO")
            Text("• Facebook: posts to your Page. Personal Facebook profiles can't be auto-posted — Meta removed that years ago. Use Share for those.")
                .font(.system(size: 13))
                .foregroundColor(.white.opacity(0.75))
            Text("• Instagram: posts Reels to a Business or Creator account. Photos go through Share.")
                .font(.system(size: 13))
                .foregroundColor(.white.opacity(0.75))
            Text("• TikTok: posts videos. Photos go through Share.")
                .font(.system(size: 13))
                .foregroundColor(.white.opacity(0.75))
            Text("• Your videos are stored on this phone and post from here. If you're offline, they queue and go out when you're back online — never lost, never silently dropped.")
                .font(.system(size: 13))
                .foregroundColor(.white.opacity(0.75))
            Text("• Sign-in tokens live in the Keychain, never in the app's files. Auto-post needs the app's approval from Meta and TikTok before it works for other people's accounts — that review is a separate step.")
                .font(.system(size: 13))
                .foregroundColor(.white.opacity(0.75))
        }
        .padding(14)
        .background(Brand.navyLight)
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private func sectionTitle(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 12, weight: .bold))
            .foregroundColor(.white.opacity(0.6))
    }
}
