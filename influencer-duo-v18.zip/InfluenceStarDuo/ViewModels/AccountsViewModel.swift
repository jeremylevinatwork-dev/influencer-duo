import AuthenticationServices
import Foundation
import UIKit

/// The Accounts tab's brain: connecting Facebook Pages, Instagram
/// Business accounts and TikTok accounts, and the per-account
/// auto-post switches that decide everything about posting.
///
/// Tokens live in the Keychain, never in UserDefaults and never in
/// code. The only secrets the user types are the Meta App ID and the
/// TikTok Client Key (public client identifiers, stored in
/// UserDefaults) — and, for TikTok only, the Client Secret, which v1
/// keeps in the Keychain on the user's own device. That last one is a
/// known v1 trade-off, stated in the README: TikTok's code exchange
/// needs the secret, and its proper home is a small server. v1 does
/// not pretend otherwise.
final class AccountsViewModel: NSObject, ObservableObject {
    private let accounts: AccountStore

    /// The accounts the Accounts tab lists, with their toggles.
    var connectedAccounts: [SocialAccount] { accounts.accounts }

    @Published var isConnecting = false
    @Published var connectingPlatform: SocialAccount.Platform?
    @Published var connectMessage: String?

    @Published var metaAppID = MetaConfig.appID
    @Published var tiktokClientKey = TikTokConfig.clientKey

    private var authSession: ASWebAuthenticationSession?

    init(accounts: AccountStore) {
        self.accounts = accounts
    }

    // MARK: - Setup values (typed by the user, never hardcoded)

    func saveMetaAppID() {
        MetaConfig.appID = metaAppID.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    func saveTikTokClientKey() {
        TikTokConfig.clientKey = tiktokClientKey.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    // MARK: - Toggles and removal

    /// The switch that decides whether this account gets auto-posts.
    /// Posting checks this flag itself — nothing can post to an
    /// account that is off.
    func setAutoPost(_ account: SocialAccount, on: Bool) {
        var copy = account
        copy.autoPost = on
        accounts.update(copy)
    }

    func disconnect(_ account: SocialAccount) {
        accounts.remove(account)
    }

    // MARK: - Meta (Facebook Pages + Instagram)

    /// Starts Facebook Login in the system browser sheet. The dialog
    /// returns an access token in the URL fragment — no secret is
    /// involved. Pages are then listed from /me/accounts, and any
    /// Instagram Business account hanging off a Page is added too.
    func connectMeta() {
        saveMetaAppID()
        guard let url = MetaConfig.authURL() else {
            connectMessage = "Paste your Meta App ID above first — it comes from your app at developers.facebook.com. See the setup steps in the README."
            return
        }
        isConnecting = true
        connectingPlatform = .facebookPage
        connectMessage = nil
        let session = ASWebAuthenticationSession(url: url, callbackURLScheme: MetaConfig.callbackScheme) { [weak self] callbackURL, error in
            Task { @MainActor in
                guard let self else { return }
                self.isConnecting = false
                self.connectingPlatform = nil
                if let error {
                    self.connectMessage = "Facebook sign-in didn't finish: \(error.localizedDescription)"
                    return
                }
                guard let callbackURL,
                      let fragment = callbackURL.fragment,
                      let token = Self.fragmentValue(fragment, key: "access_token") else {
                    self.connectMessage = "Facebook didn't hand back a sign-in. Try again."
                    return
                }
                self.accounts.userToken = token
                await self.fetchMetaPages(userToken: token)
            }
        }
        session.presentationContextProvider = self
        session.prefersEphemeralWebBrowserSession = true
        authSession = session
        session.start()
    }

    private func fetchMetaPages(userToken: String) async {
        guard let base = MetaConfig.graphURL(path: "me/accounts") else { return }
        var components = URLComponents(url: base, resolvingAgainstBaseURL: false)
        components?.queryItems = [
            URLQueryItem(name: "fields", value: "id,name,instagram_business_account"),
            URLQueryItem(name: "access_token", value: userToken)
        ]
        guard let url = components?.url else { return }
        do {
            let (data, response) = try await URLSession.shared.data(from: url)
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            guard status == 200,
                  let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let pages = json["data"] as? [[String: Any]], !pages.isEmpty else {
                await MainActor.run {
                    self.connectMessage = "Signed in, but no Facebook Pages were found on this account. Auto-post needs a Page — personal profiles can't be auto-posted."
                }
                return
            }
            var added: [String] = []
            for page in pages {
                guard let pageID = page["id"] as? String,
                      let name = page["name"] as? String,
                      let pageToken = page["access_token"] as? String else { continue }
                let pageAccount = SocialAccount(platform: .facebookPage, displayName: name, remoteID: pageID)
                accounts.add(pageAccount)
                accounts.setToken(pageToken, for: pageAccount)
                added.append(name)
                if let ig = page["instagram_business_account"] as? [String: Any],
                   let igID = ig["id"] as? String {
                    let igName = await fetchInstagramName(igUserID: igID, token: pageToken) ?? name
                    let igAccount = SocialAccount(platform: .instagram, displayName: igName, remoteID: igID, pageID: pageID)
                    accounts.add(igAccount)
                    accounts.setToken(pageToken, for: igAccount)
                    added.append(igName + " (Instagram)")
                }
            }
            // `added` is a var the loop mutates, and Swift 6 forbids
            // capturing a var in a concurrently-executing closure,
            // so hand the message a frozen copy instead.
            let addedNames = added
            await MainActor.run {
                self.connectMessage = addedNames.isEmpty
                    ? "Signed in, but nothing could be added. Check the Page permissions and try again."
                    : "Connected: \(addedNames.joined(separator: ", "))."
            }
        } catch {
            await MainActor.run {
                self.connectMessage = "Signed in, but the Page list couldn't load. Check your connection and try again."
            }
        }
    }

    private func fetchInstagramName(igUserID: String, token: String) async -> String? {
        guard let base = MetaConfig.graphURL(path: igUserID) else { return nil }
        var components = URLComponents(url: base, resolvingAgainstBaseURL: false)
        components?.queryItems = [
            URLQueryItem(name: "fields", value: "username"),
            URLQueryItem(name: "access_token", value: token)
        ]
        guard let url = components?.url,
              let (data, _) = try? await URLSession.shared.data(from: url),
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let username = json["username"] as? String else { return nil }
        return "@" + username
    }

    // MARK: - TikTok (Login Kit)

    /// Starts TikTok Login Kit in the system browser sheet. The
    /// dialog returns an authorization code; v1 exchanges it for a
    /// token using the Client Secret the user typed (kept in the
    /// Keychain, never in code — see the note at the top of this file
    /// and in the README for why a server is the proper home).
    func connectTikTok(clientSecret: String) {
        saveTikTokClientKey()
        let secret = clientSecret.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = TikTokConfig.authURL() else {
            connectMessage = "Paste your TikTok Client Key above first — it comes from your app at developers.tiktok.com."
            return
        }
        guard !secret.isEmpty else {
            connectMessage = "TikTok needs your app's Client Secret to finish sign-in. Paste it in the TikTok section — it stays in your device Keychain."
            return
        }
        isConnecting = true
        connectingPlatform = .tiktok
        connectMessage = nil
        let session = ASWebAuthenticationSession(url: url, callbackURLScheme: TikTokConfig.callbackScheme) { [weak self] callbackURL, error in
            Task { @MainActor in
                guard let self else { return }
                self.isConnecting = false
                self.connectingPlatform = nil
                if let error {
                    self.connectMessage = "TikTok sign-in didn't finish: \(error.localizedDescription)"
                    return
                }
                guard let callbackURL,
                      let components = URLComponents(url: callbackURL, resolvingAgainstBaseURL: false),
                      let code = components.queryItems?.first(where: { $0.name == "code" })?.value else {
                    self.connectMessage = "TikTok didn't hand back a sign-in. Try again."
                    return
                }
                await self.exchangeTikTokCode(code, clientSecret: secret)
            }
        }
        session.presentationContextProvider = self
        session.prefersEphemeralWebBrowserSession = true
        authSession = session
        session.start()
    }

    private func exchangeTikTokCode(_ code: String, clientSecret: String) async {
        guard let url = URL(string: "https://open.tiktokapis.com/v2/oauth/token/") else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        let body = "client_key=\(TikTokConfig.clientKey.urlFormEncoded)"
            + "&client_secret=\(clientSecret.urlFormEncoded)"
            + "&code=\(code.urlFormEncoded)"
            + "&grant_type=authorization_code"
            + "&redirect_uri=\(TikTokConfig.redirectURI.urlFormEncoded)"
        request.httpBody = body.data(using: .utf8)
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            guard status == 200,
                  let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let accessToken = json["access_token"] as? String,
                  let openID = json["open_id"] as? String else {
                await MainActor.run {
                    self.connectMessage = "TikTok wouldn't exchange the sign-in. Check the Client Key and Secret, then try again."
                }
                return
            }
            let displayName = await fetchTikTokName(token: accessToken) ?? "TikTok account"
            let account = SocialAccount(platform: .tiktok, displayName: displayName, remoteID: openID)
            accounts.add(account)
            accounts.setToken(accessToken, for: account)
            // The secret is only needed again at the next sign-in.
            // Keeping it in the Keychain means reconnecting is one tap.
            KeychainHelper.save(clientSecret, forKey: "isd.tiktok.clientSecret")
            await MainActor.run {
                self.connectMessage = "Connected TikTok: \(displayName)."
            }
        } catch {
            await MainActor.run {
                self.connectMessage = "Couldn't reach TikTok to finish sign-in. Check your connection and try again."
            }
        }
    }

    private func fetchTikTokName(token: String) async -> String? {
        guard let base = TikTokConfig.apiURL(path: "user/info/") else { return nil }
        var components = URLComponents(url: base, resolvingAgainstBaseURL: false)
        components?.queryItems = [URLQueryItem(name: "fields", value: "open_id,display_name")]
        guard let url = components?.url else { return nil }
        var request = URLRequest(url: url)
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        guard let (data, _) = try? await URLSession.shared.data(for: request),
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let dataDict = json["data"] as? [String: Any],
              let user = dataDict["user"] as? [String: Any],
              let name = user["display_name"] as? String else { return nil }
        return name
    }

    /// The saved TikTok Client Secret, for the reconnect field. It is
    /// read from the Keychain only to pre-fill the field.
    var savedTikTokClientSecret: String {
        KeychainHelper.read(forKey: "isd.tiktok.clientSecret") ?? ""
    }

    // MARK: - Helpers

    private static func fragmentValue(_ fragment: String, key: String) -> String? {
        fragment.split(separator: "&").compactMap { pair -> String? in
            let parts = pair.split(separator: "=", maxSplits: 1)
            guard parts.count == 2, parts[0] == key else { return nil }
            return String(parts[1]).removingPercentEncoding
        }.first
    }
}

extension AccountsViewModel: ASWebAuthenticationPresentationContextProviding {
    func presentationAnchor(for session: ASWebAuthenticationSession) -> ASPresentationAnchor {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
            .first { $0.isKeyWindow } ?? ASPresentationAnchor()
    }
}
