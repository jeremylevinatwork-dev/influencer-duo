import Foundation
import UIKit

/// The Library tab's brain: the grid, thumbnails, queue status, and
/// the actions on one item (view, post now, share, delete, retry).
final class LibraryViewModel: ObservableObject {
    let library: LibraryStore
    let outbox: OutboxStore
    let accounts: AccountStore
    let posting: PostingService
    private let subscription: SubscriptionService

    @Published var thumbnails: [UUID: UIImage] = [:]
    @Published var selectedItem: MediaItem?
    @Published var shareItem: MediaItem?
    /// True when a Pro feature was tapped without Pro: the detail
    /// sheet shows the paywall.
    @Published var showPaywall = false

    init(library: LibraryStore, outbox: OutboxStore, accounts: AccountStore, posting: PostingService, subscription: SubscriptionService) {
        self.library = library
        self.outbox = outbox
        self.accounts = accounts
        self.posting = posting
        self.subscription = subscription
    }

    // MARK: - Thumbnails

    func thumbnail(for item: MediaItem) -> UIImage? {
        thumbnails[item.id]
    }

    func loadThumbnail(for item: MediaItem) {
        guard thumbnails[item.id] == nil else { return }
        Task {
            if let image = await library.thumbnail(for: item) {
                await MainActor.run { thumbnails[item.id] = image }
            }
        }
    }

    // MARK: - Queue status

    /// The jobs waiting on one item, for the "Queued / Uploading /
    /// Failed" row under it in the grid.
    func jobs(for item: MediaItem) -> [PostJob] {
        outbox.jobs(for: item.id)
    }

    /// A one-line summary for the Library header: how many posts are
    /// waiting for a connection, and how many failed and need a look.
    var queueSummary: String? {
        let queued = outbox.jobs.filter { $0.state == .queued }.count
        let uploading = outbox.jobs.filter { $0.state == .uploading }.count
        let failed = outbox.jobs.filter { $0.state == .failed }.count
        var parts: [String] = []
        if uploading > 0 { parts.append("\(uploading) uploading") }
        if queued > 0 { parts.append("\(queued) waiting for connection") }
        if failed > 0 { parts.append("\(failed) failed") }
        return parts.isEmpty ? nil : parts.joined(separator: " · ")
    }

    func retry(job: PostJob) {
        outbox.retry(job)
        posting.processOutbox()
    }

    func remove(job: PostJob) {
        outbox.remove(job)
    }

    // MARK: - Item actions

    /// The accounts this item can post to right now: connected and
    /// switched on, and able to take this kind of media (photos cannot
    /// auto-post to Instagram or TikTok — their APIs are video only).
    func postableAccounts(for item: MediaItem) -> [SocialAccount] {
        accounts.accounts.filter { account in
            guard account.autoPost, !account.needsReconnect else { return false }
            switch account.platform {
            case .facebookPage:
                return true
            case .instagram, .tiktok:
                return item.kind == .video
            }
        }
    }

    /// The plain-words reason an item cannot auto-post somewhere, for
    /// the detail sheet. Empty when posting is available.
    func postLimits(for item: MediaItem) -> String? {
        if item.kind == .photo {
            let videoOnly = accounts.accounts.contains { $0.platform == .instagram || $0.platform == .tiktok }
            if videoOnly {
                return "Photos can't auto-post to Instagram or TikTok — their posting APIs take video only. Use Share to send this photo there."
            }
        }
        if accounts.accounts.isEmpty {
            return "No accounts connected yet. Connect one in Accounts to auto-post."
        }
        if postableAccounts(for: item).isEmpty {
            return "Your connected accounts are switched off for auto-post. Turn one on in Accounts."
        }
        return nil
    }

    func postNow(item: MediaItem, to account: SocialAccount) {
        // Auto-post is a Pro feature. Without Pro the paywall opens;
        // the video itself is never touched.
        guard subscription.isPro else {
            showPaywall = true
            return
        }
        guard posting.enqueuePostNow(item: item, to: account) != nil else { return }
        posting.processOutbox()
    }

    func updateCaption(item: MediaItem, caption: String, link: String?) {
        var copy = item
        copy.caption = caption
        let trimmedLink = link?.trimmingCharacters(in: .whitespacesAndNewlines)
        copy.link = (trimmedLink?.isEmpty == true) ? nil : trimmedLink
        library.update(copy)
    }

    func delete(item: MediaItem) {
        for job in outbox.jobs(for: item.id) {
            outbox.remove(job)
        }
        library.remove(item)
        thumbnails.removeValue(forKey: item.id)
        selectedItem = nil
    }
}
