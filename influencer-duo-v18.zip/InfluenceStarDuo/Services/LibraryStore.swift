import AVFoundation
import Foundation
import UIKit

/// The on-device Library: finished videos and photos stored in
/// Documents/Media, indexed by library.json. Nothing here needs the
/// network — the Library is the offline home of everything the app
/// films, and the outbox uploads from these same files later.
final class LibraryStore: ObservableObject {
    @Published private(set) var items: [MediaItem] = []

    private let fileManager = FileManager.default
    private let fileName = "library.json"
    private let mediaFolderName = "Media"
    private let thumbnailFolderName = "Thumbnails"

    init() {
        load()
    }

    // MARK: - Paths

    static func documentsDirectory() -> URL {
        let urls = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        if let first = urls.first { return first }
        return FileManager.default.temporaryDirectory
    }

    private var indexURL: URL {
        Self.documentsDirectory().appendingPathComponent(fileName)
    }

    private var mediaDirectory: URL {
        Self.documentsDirectory().appendingPathComponent(mediaFolderName)
    }

    private var thumbnailDirectory: URL {
        Self.documentsDirectory().appendingPathComponent(thumbnailFolderName)
    }

    func mediaURL(for item: MediaItem) -> URL {
        mediaDirectory.appendingPathComponent(item.fileName)
    }

    func thumbnailURL(for item: MediaItem) -> URL {
        thumbnailDirectory.appendingPathComponent(item.id.uuidString + ".jpg")
    }

    // MARK: - Persistence

    private func load() {
        guard let data = try? Data(contentsOf: indexURL),
              let decoded = try? JSONDecoder().decode([MediaItem].self, from: data) else {
            items = []
            return
        }
        // Drop index entries whose file is gone (for example a user
        // clearing storage by hand) instead of showing dead rows.
        items = decoded.filter { fileManager.fileExists(atPath: mediaURL(for: $0).path) }
            .sorted { $0.createdAt > $1.createdAt }
    }

    private func save() {
        do {
            try fileManager.createDirectory(at: mediaDirectory, withIntermediateDirectories: true)
            let data = try JSONEncoder().encode(items)
            try data.write(to: indexURL, options: .atomic)
        } catch {
            // The in-memory list is still correct; the next launch
            // re-reads whatever made it to disk.
        }
    }

    // MARK: - Adding media

    /// Copies a finished video file into the Library and indexes it.
    /// Returns the new record, or nil when the copy failed.
    @discardableResult
    func addVideoFile(_ sourceURL: URL, duration: TimeInterval?, caption: String, location: Place? = nil) -> MediaItem? {
        let name = UUID().uuidString + ".mp4"
        let destination = mediaDirectory.appendingPathComponent(name)
        do {
            try fileManager.createDirectory(at: mediaDirectory, withIntermediateDirectories: true)
            if fileManager.fileExists(atPath: destination.path) {
                try fileManager.removeItem(at: destination)
            }
            try fileManager.copyItem(at: sourceURL, to: destination)
        } catch {
            return nil
        }
        let item = MediaItem(kind: .video, fileName: name, duration: duration, caption: caption, location: location)
        items.insert(item, at: 0)
        save()
        return item
    }

    /// Writes a finished photo into the Library and indexes it.
    @discardableResult
    func addPhotoImage(_ image: UIImage, caption: String, location: Place? = nil) -> MediaItem? {
        guard let data = image.jpegData(compressionQuality: 0.92) else { return nil }
        let name = UUID().uuidString + ".jpg"
        let destination = mediaDirectory.appendingPathComponent(name)
        do {
            try fileManager.createDirectory(at: mediaDirectory, withIntermediateDirectories: true)
            try data.write(to: destination, options: .atomic)
        } catch {
            return nil
        }
        let item = MediaItem(kind: .photo, fileName: name, caption: caption, location: location)
        items.insert(item, at: 0)
        save()
        return item
    }

    // MARK: - Updating / removing

    func item(id: UUID) -> MediaItem? {
        items.first { $0.id == id }
    }

    func update(_ item: MediaItem) {
        guard let index = items.firstIndex(where: { $0.id == item.id }) else { return }
        items[index] = item
        save()
    }

    /// Marks a platform as posted for an item (never posted twice).
    func markPosted(_ id: UUID, platform: String) {
        guard var item = item(id: id), !item.postedPlatforms.contains(platform) else { return }
        item.postedPlatforms.append(platform)
        update(item)
    }

    func remove(_ item: MediaItem) {
        items.removeAll { $0.id == item.id }
        save()
        try? fileManager.removeItem(at: mediaURL(for: item))
        try? fileManager.removeItem(at: thumbnailURL(for: item))
    }

    // MARK: - Thumbnails

    /// A small still for the Library grid, generated once and cached on
    /// disk. Returns nil when the source cannot be read.
    func thumbnail(for item: MediaItem) async -> UIImage? {
        let cachedURL = thumbnailURL(for: item)
        if let data = try? Data(contentsOf: cachedURL), let image = UIImage(data: data) {
            return image
        }
        let sourceURL = mediaURL(for: item)
        let image: UIImage?
        switch item.kind {
        case .photo:
            image = UIImage(contentsOfFile: sourceURL.path)
        case .video:
            image = await Self.videoStill(url: sourceURL)
        }
        guard let image else { return nil }
        do {
            try fileManager.createDirectory(at: thumbnailDirectory, withIntermediateDirectories: true)
            if let data = image.jpegData(compressionQuality: 0.8) {
                try data.write(to: cachedURL, options: .atomic)
            }
        } catch {
            // A missing cached thumbnail is harmless; it regenerates.
        }
        return image
    }

    private static func videoStill(url: URL) async -> UIImage? {
        let asset = AVURLAsset(url: url)
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        generator.maximumSize = CGSize(width: 480, height: 480)
        do {
            let duration = try await asset.load(.duration)
            let at = CMTime(seconds: min(0.5, max(0, duration.seconds - 0.1)), preferredTimescale: 600)
            let cgImage = try generator.copyCGImage(at: at, actualTime: nil)
            return UIImage(cgImage: cgImage)
        } catch {
            return nil
        }
    }
}
