import SwiftUI
import UIKit

/// The talent monitor on the phone's OUTER display.
///
/// The whole point of this app is dual camera WITHOUT flipping the
/// phone: the operator works the inner screen, and the influencer
/// watches themselves on the screen facing them — the outer display.
/// That only works if the phone exposes the outer display to apps
/// as a second screen. Apple's own Camera app uses it (Duo
/// Preview); whether a third-party app can is something the phone
/// itself decides, and this controller finds out live:
///
/// - If the phone exposes a second window scene, a window is
///   opened on it showing the influencer's live view (back camera
///   full-screen, front camera as PiP) — no flipping needed.
/// - If there is no second screen, nothing happens and
///   `outerDisplayLive` stays false: the phone keeps the outer
///   display for itself, and the app says so plainly instead of
///   pretending.
///
/// Owned by the CameraService (one per app), fed by its outer
/// preview layers — separate layers, because one CALayer can only
/// live in one view at a time.
final class OuterDisplayController: ObservableObject {
    /// True while the influencer's live view is up on the outer
    /// display. The operator screen shows an OUTER pill from this.
    @Published private(set) var outerDisplayLive = false

    private weak var camera: CameraService?
    private var window: UIWindow?

    /// The outer display's window scene, if the phone exposes one
    /// to apps: any connected window scene whose screen isn't the
    /// main one. (`UIScreen.screens` is deprecated in iOS 16; the
    /// scene list is the current way to find a second display.)
    private var outerWindowScene: UIWindowScene? {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first { $0.screen !== UIScreen.main }
    }

    init(camera: CameraService) {
        self.camera = camera
        // `UIScreen.didConnectNotification` /
        // `didDisconnectNotification` are deprecated in iOS 16;
        // scene connect/disconnect is the current signal for a
        // display appearing or going away.
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(screensChanged),
            name: UIScene.willConnectNotification,
            object: nil)
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(screensChanged),
            name: UIScene.didDisconnectNotification,
            object: nil)
        updateWindow()
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    @objc private func screensChanged(_ note: Notification) {
        updateWindow()
    }

    /// Opens the talent window on the outer display when there is
    /// one, closes it when there isn't. Safe to call any time.
    private func updateWindow() {
        guard let windowScene = outerWindowScene, let camera else {
            window?.isHidden = true
            window = nil
            DispatchQueue.main.async { self.outerDisplayLive = false }
            return
        }
        if window?.windowScene !== windowScene {
            // Build the window on its scene directly; setting a
            // window's `screen` is deprecated (iOS 13).
            let talentWindow = UIWindow(windowScene: windowScene)
            talentWindow.rootViewController = UIHostingController(rootView: OuterDisplayView(camera: camera))
            talentWindow.isHidden = false
            window = talentWindow
        }
        DispatchQueue.main.async { self.outerDisplayLive = true }
    }
}
