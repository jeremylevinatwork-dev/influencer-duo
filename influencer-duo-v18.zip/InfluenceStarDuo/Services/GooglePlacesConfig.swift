import Foundation

/// The optional Google Places key. There is NO key in this file and
/// there never will be one baked into the build: the key slot is empty
/// until Jeremy fills it in, and the app works fully without it — the
/// place name and address come from Apple's free reverse-geocode, and
/// only the Google star rating is missing.
///
/// Setup Jeremy does once, if he wants Google ratings on the place cards:
///   1. console.cloud.google.com → pick (or make) a project → enable
///      the "Places API".
///   2. Credentials → Create credentials → API key.
///   3. Paste the key into `apiKey` below. In the Cloud console, restrict
///      the key to iOS apps (and to the Places API) so it can't be reused
///      anywhere else.
/// Until the key is set, the place card simply shows the name and address
/// with no Google rating — never a made-up one.
enum GooglePlacesConfig {
    /// Jeremy's Google Places API key. Leave empty for no Google ratings.
    static let apiKey = ""

    static var isConfigured: Bool {
        !apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
}
