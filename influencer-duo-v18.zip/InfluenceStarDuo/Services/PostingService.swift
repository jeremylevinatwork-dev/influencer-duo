import Foundation
import UIKit

/// Sends finished media to the accounts the user chose. One service
/// for all three platforms — Facebook Page, Instagram Business,
/// TikTok — because they share the same shape: an upload, a publish
/// step, a plain-words failure, and a job that stays queued until it
/// succeeds.
///
/// THE POSTING RULE (Jeremy's rule, enforced here and nowhere else):
/// the app posts ONLY to accounts the user connected AND switched on.
/// `enqueueAutoPosts` is the single entry point for automatic posting
/// and it checks `account.autoPost` itself — no caller can post to a
/// toggled-off account by accident, and no platform is ever posted to
/// unless the user picked it.
///
/// Photos: Facebook can take them; Instagram Reels and TikTok's API
/// cannot (video only), so photos for those two go through the iOS
/// share sheet instead — the UI offers that, never a fake auto-post.
///
/// Failures are never silent: a job that gives up after 5 tries stays
/// in the outbox as `.failed` with `lastError` in plain words, and the
/// Library shows it with a Retry button.
final class PostingService: ObservableObject {
    static let maxAttempts = 5

    private let accounts: AccountStore
    private let outbox: OutboxStore
    private let library: LibraryStore
    private let subscription: SubscriptionService
    private var processing = false

    init(accounts: AccountStore, outbox: OutboxStore, library: LibraryStore, subscription: SubscriptionService) {
        self.accounts = accounts
        self.outbox = outbox
        self.library = library
        self.subscription = subscription
    }

    // MARK: - The posting rule

    /// The accounts a finished item may auto-post to: connected, and
    /// switched ON in Accounts. Nothing else is ever posted to.
    var autoPostAccounts: [SocialAccount] {
        accounts.accounts.filter { $0.autoPost && !$0.needsReconnect }
    }

    /// Queues a finished item for auto-post to every account the user
    /// switched on. Photos are skipped for Instagram and TikTok — those
    /// two can only take video through their APIs, and the app will not
    /// pretend otherwise; the Library offers Share for those instead.
    /// Returns the jobs that were queued.
    @discardableResult
    func enqueueAutoPosts(for item: MediaItem) -> [PostJob] {
        // Auto-post is a Pro feature. Without Pro nothing is queued;
        // the video itself is already safe in the Library.
        guard subscription.isPro else { return [] }
        var queued: [PostJob] = []
        for account in autoPostAccounts {
            let platform: PostJob.Platform
            switch account.platform {
            case .facebookPage:
                platform = .facebook
            case .instagram:
                guard item.kind == .video else { continue }
                platform = .instagram
            case .tiktok:
                guard item.kind == .video else { continue }
                platform = .tiktok
            }
            queued.append(outbox.enqueue(mediaItemID: item.id, accountID: account.id, platform: platform))
        }
        return queued
    }

    /// Queues one item to one chosen account, only if that account is
    /// switched on. Used by "Post now" in the Library detail view: the
    /// user picked this account, in this moment. Returns nil when the
    /// account is off, needs reconnecting, or cannot take this media.
    @discardableResult
    func enqueuePostNow(item: MediaItem, to account: SocialAccount) -> PostJob? {
        guard subscription.isPro else { return nil }
        guard account.autoPost, !account.needsReconnect else { return nil }
        let platform: PostJob.Platform
        switch account.platform {
        case .facebookPage:
            platform = .facebook
        case .instagram:
            guard item.kind == .video else { return nil }
            platform = .instagram
        case .tiktok:
            guard item.kind == .video else { return nil }
            platform = .tiktok
        }
        return outbox.enqueue(mediaItemID: item.id, accountID: account.id, platform: platform)
    }

    /// The display name of an account, for toasts and the Library.
    func accountName(for accountID: UUID) -> String? {
        accounts.account(id: accountID)?.displayName
    }

    /// The post text for an item: its caption, with the link the
    /// operator added while filming appended on its own line, then the
    /// checked-in place ("📍 <place> …" — Google's rating and the
    /// influencer's own stars + one-liner kept apart, see
    /// Place.captionLine). The same text goes to Facebook, Instagram
    /// and TikTok.
    static func postText(for item: MediaItem) -> String {
        var parts: [String] = []
        let caption = item.caption.trimmingCharacters(in: .whitespacesAndNewlines)
        if !caption.isEmpty {
            parts.append(caption)
        }
        if let link = item.link?.trimmingCharacters(in: .whitespacesAndNewlines), !link.isEmpty {
            parts.append(link)
        }
        if let location = item.location {
            parts.append(location.captionLine)
        }
        return parts.joined(separator: "\n")
    }

    // MARK: - Outbox processing

    /// Drains the queue, one job at a time, oldest first. Called when
    /// the network comes back and after new jobs are queued. A job that
    /// fails with a retryable problem stays queued and its attempt
    /// count rises; after `maxAttempts` it becomes `.failed` with the
    /// reason in plain words, and waits for the user to Retry it.
    /// Each drain works from a snapshot: a job that cannot proceed
    /// right now (account switched off, subscription expired) is
    /// simply skipped this time and stays queued for a later drain.
    func processOutbox() {
        guard !processing else { return }
        processing = true
        Task {
            defer { processing = false }
            for job in outbox.pendingJobs() {
                await process(job)
            }
        }
    }

    private func process(_ job: PostJob) async {
        // Pro lapsed since this job was queued: leave it queued. The
        // snapshot drain skips it this time; it goes out when Pro is
        // back. It is never deleted for that reason.
        guard subscription.isPro else { return }
        guard let item = library.item(id: job.mediaItemID),
              let account = accounts.account(id: job.accountID) else {
            // Media or account gone: nothing left to post to.
            var copy = job
            copy.state = .failed
            copy.lastError = "The video or the account is gone, so there is nothing to post."
            copy.updatedAt = Date()
            outbox.update(copy)
            return
        }
        // The user switched this account off since the job was queued:
        // respect that now. The job waits until they switch it back on.
        guard account.autoPost, !account.needsReconnect else { return }
        var working = job
        working.state = .uploading
        working.updatedAt = Date()
        outbox.update(working)

        let result = await upload(item: item, account: account, platform: job.platform)
        switch result {
        case .success:
            var done = job
            done.state = .posted
            done.lastError = nil
            done.updatedAt = Date()
            outbox.update(done)
            library.markPosted(item.id, platform: job.platform.rawValue)
        case .failure(let message, let retryable):
            var failed = job
            failed.attempts += 1
            failed.lastError = message
            failed.updatedAt = Date()
            if retryable && failed.attempts < Self.maxAttempts {
                failed.state = .queued
            } else {
                failed.state = .failed
            }
            outbox.update(failed)
        }
    }

    private enum UploadResult {
        case success
        case failure(message: String, retryable: Bool)
    }

    private func upload(item: MediaItem, account: SocialAccount, platform: PostJob.Platform) async -> UploadResult {
        guard let token = accounts.token(for: account) else {
            return .failure(message: "Not signed in to \(account.displayName) any more. Reconnect it in Accounts.", retryable: false)
        }
        let fileURL = library.mediaURL(for: item)
        let text = Self.postText(for: item)
        switch platform {
        case .facebook:
            return await uploadFacebook(item: item, fileURL: fileURL, text: text, pageID: account.remoteID, token: token, account: account)
        case .instagram:
            return await uploadInstagram(item: item, fileURL: fileURL, text: text, igUserID: account.remoteID, token: token, account: account)
        case .tiktok:
            return await uploadTikTok(item: item, fileURL: fileURL, text: text, token: token, account: account)
        }
    }

    // MARK: - Facebook Page

    private func uploadFacebook(item: MediaItem, fileURL: URL, text: String, pageID: String, token: String, account: SocialAccount) async -> UploadResult {
        if item.kind == .photo {
            guard let data = try? Data(contentsOf: fileURL) else {
                return .failure(message: "Couldn't read the photo to send it.", retryable: true)
            }
            let boundary = "isd-\(UUID().uuidString)"
            var request = multipartRequest(url: MetaConfig.graphURL(path: "\(pageID)/photos"), token: token, boundary: boundary)
            var body = Data()
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"message\"\r\n\r\n".data(using: .utf8)!)
            body.append("\(text)\r\n".data(using: .utf8)!)
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"source\"; filename=\"photo.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
            body.append(data)
            body.append("\r\n--\(boundary)--\r\n".data(using: .utf8)!)
            request.httpBody = body
            return await runGraph(request, account: account, successMessage: "Posted to \(account.displayName).")
        }
        guard let data = try? Data(contentsOf: fileURL) else {
            return .failure(message: "Couldn't read the video to send it.", retryable: true)
        }
        let boundary = "isd-\(UUID().uuidString)"
        var request = multipartRequest(url: MetaConfig.graphURL(path: "\(pageID)/videos"), token: token, boundary: boundary)
        var body = Data()
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"description\"\r\n\r\n".data(using: .utf8)!)
        body.append("\(text)\r\n".data(using: .utf8)!)
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"source\"; filename=\"video.mp4\"\r\nContent-Type: video/mp4\r\n\r\n".data(using: .utf8)!)
        body.append(data)
        body.append("\r\n--\(boundary)--\r\n".data(using: .utf8)!)
        request.httpBody = body
        return await runGraph(request, account: account, successMessage: "Posted to \(account.displayName).")
    }

    /// A multipart POST with the token in the Authorization header.
    private func multipartRequest(url: URL?, token: String, boundary: String) -> URLRequest {
        var request = URLRequest(url: url ?? URL(string: "https://graph.facebook.com")!)
        request.httpMethod = "POST"
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = 300
        return request
    }

    /// Runs a Graph call and turns the result into a plain-words
    /// outcome. Code 190 means the token expired: the account is
    /// flagged for reconnect and the job stops retrying.
    private func runGraph(_ request: URLRequest, account: SocialAccount, successMessage: String) async -> UploadResult {
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            if status == 200 || status == 201 {
                return .success
            }
            let message = graphErrorMessage(data: data, status: status)
            if graphErrorCode(data: data) == 190 {
                accounts.markNeedsReconnect(account)
                return .failure(message: "Your Facebook sign-in expired. Reconnect \(account.displayName) in Accounts, then retry.", retryable: false)
            }
            return .failure(message: message, retryable: status >= 500 || status == 429)
        } catch {
            return .failure(message: "Couldn't reach Facebook. It will try again when you're back online.", retryable: true)
        }
    }

    private func graphErrorCode(data: Data) -> Int? {
        guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let error = json["error"] as? [String: Any],
              let code = error["code"] as? Int else { return nil }
        return code
    }

    private func graphErrorMessage(data: Data, status: Int) -> String {
        if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let error = json["error"] as? [String: Any],
           let message = error["message"] as? String {
            return "Facebook said: \(message)"
        }
        return "Facebook didn't accept the post (error \(status)). It will try again."
    }

    /// Instagram Reels, video only, via Meta's Resumable Upload API:
    /// start an upload session, PUT the video to Meta in chunks, then
    /// create the Reels container from that upload, poll until it is
    /// ready, and publish. The video never needs a public URL — it
    /// goes straight to Meta, which is what makes this work offline-
    /// first from the device.
    ///
    /// NOTE: the resumable-upload endpoints follow Meta's published
    /// Resumable Upload API for Instagram media. Verify the exact
    /// rupload host and header names against Meta's current docs
    /// during the TestFlight pass — Meta renames these from time to
    /// time, and a wrong host shows up here as a plain-words failure
    /// in the Library, never a silent drop.
    private func uploadInstagram(item: MediaItem, fileURL: URL, text: String, igUserID: String, token: String, account: SocialAccount) async -> UploadResult {
        guard let videoData = try? Data(contentsOf: fileURL), !videoData.isEmpty else {
            return .failure(message: "Couldn't read the video to send it.", retryable: true)
        }
        // Step 1: start a resumable upload session.
        guard let mediaBase = MetaConfig.graphURL(path: "\(igUserID)/media") else {
            return .failure(message: "Couldn't reach Instagram.", retryable: true)
        }
        var sessionComponents = URLComponents(url: mediaBase, resolvingAgainstBaseURL: false)
        sessionComponents?.queryItems = [
            URLQueryItem(name: "media_type", value: "REELS"),
            URLQueryItem(name: "upload_type", value: "resumable"),
            URLQueryItem(name: "access_token", value: token)
        ]
        guard let sessionURL = sessionComponents?.url else {
            return .failure(message: "Couldn't reach Instagram.", retryable: true)
        }
        var sessionRequest = URLRequest(url: sessionURL)
        sessionRequest.httpMethod = "POST"
        sessionRequest.timeoutInterval = 120
        let sessionID: String
        do {
            let (sessionData, sessionResponse) = try await URLSession.shared.data(for: sessionRequest)
            let sessionStatus = (sessionResponse as? HTTPURLResponse)?.statusCode ?? 0
            guard sessionStatus == 200 || sessionStatus == 201,
                  let sessionJSON = try? JSONSerialization.jsonObject(with: sessionData) as? [String: Any],
                  let id = sessionJSON["id"] as? String else {
                if graphErrorCode(data: sessionData) == 190 {
                    accounts.markNeedsReconnect(account)
                    return .failure(message: "Your Instagram sign-in expired. Reconnect in Accounts, then retry.", retryable: false)
                }
                return .failure(message: graphErrorMessage(data: sessionData, status: sessionStatus), retryable: sessionStatus >= 500 || sessionStatus == 429)
            }
            sessionID = id
        } catch {
            return .failure(message: "Couldn't reach Instagram. It will try again when you're back online.", retryable: true)
        }
        // Step 2: PUT the video to Meta in chunks.
        let chunkSize = 10 * 1024 * 1024
        let uploadURLString = "https://rupload.facebook.com/ig-api-upload/\(MetaConfig.graphVersion)/\(sessionID)"
        guard let uploadURL = URL(string: uploadURLString) else {
            return .failure(message: "Couldn't reach Instagram.", retryable: true)
        }
        var offset = 0
        while offset < videoData.count {
            let end = min(offset + chunkSize, videoData.count)
            let chunk = videoData.subdata(in: offset..<end)
            var chunkRequest = URLRequest(url: uploadURL)
            chunkRequest.httpMethod = "PUT"
            chunkRequest.setValue("OAuth \(token)", forHTTPHeaderField: "Authorization")
            chunkRequest.setValue("application/octet-stream", forHTTPHeaderField: "Content-Type")
            chunkRequest.setValue("\(offset)", forHTTPHeaderField: "Offset")
            chunkRequest.setValue("\(videoData.count)", forHTTPHeaderField: "file_size")
            chunkRequest.httpBody = chunk
            chunkRequest.timeoutInterval = 300
            do {
                let (_, chunkResponse) = try await URLSession.shared.data(for: chunkRequest)
                let chunkStatus = (chunkResponse as? HTTPURLResponse)?.statusCode ?? 0
                guard chunkStatus == 200 || chunkStatus == 201 || chunkStatus == 204 else {
                    return .failure(message: "Instagram stopped taking the video halfway (error \(chunkStatus)). It will try again.", retryable: chunkStatus >= 500 || chunkStatus == 429)
                }
            } catch {
                return .failure(message: "Couldn't reach Instagram. It will try again when you're back online.", retryable: true)
            }
            offset = end
        }
        // Step 3: create the Reels container from the finished upload.
        var createComponents = URLComponents(url: mediaBase, resolvingAgainstBaseURL: false)
        createComponents?.queryItems = [
            URLQueryItem(name: "media_type", value: "REELS"),
            URLQueryItem(name: "video_url", value: uploadURLString),
            URLQueryItem(name: "caption", value: text),
            URLQueryItem(name: "access_token", value: token)
        ]
        guard let createURL = createComponents?.url else {
            return .failure(message: "Couldn't reach Instagram.", retryable: true)
        }
        var createRequest = URLRequest(url: createURL)
        createRequest.httpMethod = "POST"
        createRequest.timeoutInterval = 120
        do {
            let (data, response) = try await URLSession.shared.data(for: createRequest)
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            guard status == 200 || status == 201,
                  let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let containerID = json["id"] as? String else {
                if graphErrorCode(data: data) == 190 {
                    accounts.markNeedsReconnect(account)
                    return .failure(message: "Your Instagram sign-in expired. Reconnect in Accounts, then retry.", retryable: false)
                }
                return .failure(message: graphErrorMessage(data: data, status: status), retryable: status >= 500 || status == 429)
            }
            // Step 4: wait until Instagram has the video ready.
            guard await instagramContainerReady(containerID: containerID, token: token) else {
                return .failure(message: "Instagram is still preparing the video. It will try again.", retryable: true)
            }
            // Step 5: publish.
            guard let publishBase = MetaConfig.graphURL(path: "\(igUserID)/media_publish") else {
                return .failure(message: "Couldn't reach Instagram.", retryable: true)
            }
            var publishComponents = URLComponents(url: publishBase, resolvingAgainstBaseURL: false)
            publishComponents?.queryItems = [
                URLQueryItem(name: "creation_id", value: containerID),
                URLQueryItem(name: "access_token", value: token)
            ]
            guard let publishURL = publishComponents?.url else {
                return .failure(message: "Couldn't reach Instagram.", retryable: true)
            }
            var publishRequest = URLRequest(url: publishURL)
            publishRequest.httpMethod = "POST"
            publishRequest.timeoutInterval = 120
            let (publishData, publishResponse) = try await URLSession.shared.data(for: publishRequest)
            let publishStatus = (publishResponse as? HTTPURLResponse)?.statusCode ?? 0
            if publishStatus == 200 || publishStatus == 201 {
                return .success
            }
            return .failure(message: graphErrorMessage(data: publishData, status: publishStatus), retryable: publishStatus >= 500 || publishStatus == 429)
        } catch {
            return .failure(message: "Couldn't reach Instagram. It will try again when you're back online.", retryable: true)
        }
    }

    /// Polls a container until Instagram reports it FINISHED (or an
    /// error). Gives up after ~2 minutes; the job retries later.
    private func instagramContainerReady(containerID: String, token: String) async -> Bool {
        guard let base = MetaConfig.graphURL(path: containerID) else { return false }
        for _ in 0..<12 {
            var components = URLComponents(url: base, resolvingAgainstBaseURL: false)
            components?.queryItems = [
                URLQueryItem(name: "fields", value: "status_code"),
                URLQueryItem(name: "access_token", value: token)
            ]
            guard let url = components?.url else { return false }
            do {
                let (data, response) = try await URLSession.shared.data(from: url)
                let status = (response as? HTTPURLResponse)?.statusCode ?? 0
                guard status == 200,
                      let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                      let code = json["status_code"] as? String else { return false }
                if code == "FINISHED" { return true }
                if code == "ERROR" { return false }
            } catch {
                return false
            }
            try? await Task.sleep(nanoseconds: 10_000_000_000)
        }
        return false
    }

    // MARK: - TikTok (Content Posting API, video only)

    private func uploadTikTok(item: MediaItem, fileURL: URL, text: String, token: String, account: SocialAccount) async -> UploadResult {
        guard item.kind == .video else {
            return .failure(message: "TikTok can't take photos through its posting API — use Share to post this photo to TikTok.", retryable: false)
        }
        guard let videoData = try? Data(contentsOf: fileURL), !videoData.isEmpty else {
            return .failure(message: "Couldn't read the video to send it.", retryable: true)
        }
        // Step 1: initiate the upload (FILE_UPLOAD, chunked).
        let chunkSize = 10 * 1024 * 1024
        let totalChunks = max(1, (videoData.count + chunkSize - 1) / chunkSize)
        guard let initURL = TikTokConfig.apiURL(path: "post/publish/video/init/") else {
            return .failure(message: "Couldn't reach TikTok.", retryable: true)
        }
        var initRequest = URLRequest(url: initURL)
        initRequest.httpMethod = "POST"
        initRequest.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        initRequest.setValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        initRequest.timeoutInterval = 120
        let initBody: [String: Any] = [
            "post_info": [
                "title": text,
                "privacy_level": "SELF_ONLY",
                "disable_duet": false,
                "disable_comment": false,
                "disable_stitch": false,
                "video_cover_timestamp_ms": 1000
            ],
            "source_info": [
                "source": "FILE_UPLOAD",
                "video_size": videoData.count,
                "chunk_size": chunkSize,
                "total_chunk_count": totalChunks
            ]
        ]
        initRequest.httpBody = try? JSONSerialization.data(withJSONObject: initBody)
        do {
            let (initData, initResponse) = try await URLSession.shared.data(for: initRequest)
            let initStatus = (initResponse as? HTTPURLResponse)?.statusCode ?? 0
            guard initStatus == 200,
                  let initJSON = try? JSONSerialization.jsonObject(with: initData) as? [String: Any],
                  let initDataDict = initJSON["data"] as? [String: Any],
                  let publishID = initDataDict["publish_id"] as? String,
                  let uploadURLString = initDataDict["upload_url"] as? String,
                  let uploadURL = URL(string: uploadURLString) else {
                return .failure(message: tiktokErrorMessage(data: initData, status: initStatus), retryable: initStatus >= 500 || initStatus == 429)
            }
            // Step 2: upload the chunks in order.
            for chunkIndex in 0..<totalChunks {
                let start = chunkIndex * chunkSize
                let end = min(start + chunkSize, videoData.count)
                let chunk = videoData.subdata(in: start..<end)
                var chunkRequest = URLRequest(url: uploadURL)
                chunkRequest.httpMethod = "PUT"
                chunkRequest.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
                chunkRequest.setValue("video/mp4", forHTTPHeaderField: "Content-Type")
                chunkRequest.setValue("bytes \(start)-\(end - 1)/\(videoData.count)", forHTTPHeaderField: "Content-Range")
                chunkRequest.httpBody = chunk
                chunkRequest.timeoutInterval = 300
                let (_, chunkResponse) = try await URLSession.shared.data(for: chunkRequest)
                let chunkStatus = (chunkResponse as? HTTPURLResponse)?.statusCode ?? 0
                guard chunkStatus == 200 || chunkStatus == 201 || chunkStatus == 204 else {
                    return .failure(message: "TikTok stopped taking the video halfway (error \(chunkStatus)). It will try again.", retryable: chunkStatus >= 500 || chunkStatus == 429)
                }
            }
            // Step 3: wait for TikTok to publish it.
            return await tiktokPublishStatus(publishID: publishID, token: token, account: account)
        } catch {
            return .failure(message: "Couldn't reach TikTok. It will try again when you're back online.", retryable: true)
        }
    }

    /// Polls TikTok's publish status until the video is published or
    /// fails. Gives up after ~2 minutes; the job retries later.
    private func tiktokPublishStatus(publishID: String, token: String, account: SocialAccount) async -> UploadResult {
        guard let statusURL = TikTokConfig.apiURL(path: "post/publish/status/fetch/") else {
            return .failure(message: "Couldn't reach TikTok.", retryable: true)
        }
        for _ in 0..<12 {
            var request = URLRequest(url: statusURL)
            request.httpMethod = "POST"
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            request.setValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
            request.timeoutInterval = 60
            request.httpBody = try? JSONSerialization.data(withJSONObject: ["publish_id": publishID])
            do {
                let (data, response) = try await URLSession.shared.data(for: request)
                let status = (response as? HTTPURLResponse)?.statusCode ?? 0
                guard status == 200,
                      let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                      let dataDict = json["data"] as? [String: Any],
                      let publishStatus = dataDict["status"] as? String else {
                    return .failure(message: tiktokErrorMessage(data: data, status: status), retryable: status >= 500 || status == 429)
                }
                switch publishStatus {
                case "PUBLISHED":
                    return .success
                case "FAILED":
                    let reason = (dataDict["fail_reason"] as? String) ?? "TikTok couldn't publish the video."
                    return .failure(message: "TikTok said: \(reason)", retryable: false)
                default:
                    break // PROCESSING or similar: keep waiting.
                }
            } catch {
                return .failure(message: "Couldn't reach TikTok. It will try again when you're back online.", retryable: true)
            }
            try? await Task.sleep(nanoseconds: 10_000_000_000)
        }
        return .failure(message: "TikTok is still working on the video. It will try again.", retryable: true)
    }

    private func tiktokErrorMessage(data: Data, status: Int) -> String {
        if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let error = json["error"] as? [String: Any],
           let message = error["message"] as? String {
            return "TikTok said: \(message)"
        }
        return "TikTok didn't accept the video (error \(status)). It will try again."
    }
}
