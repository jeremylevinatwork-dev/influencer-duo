import Foundation

/// Connected social accounts. The account list is persisted as
/// accounts.json; every access token lives in the Keychain under
/// `isd.token.<account-id>` (and the Facebook user token under
/// `isd.token.user`). Nothing in this store can leak a token.
final class AccountStore: ObservableObject {
    @Published private(set) var accounts: [SocialAccount] = []

    private let fileName = "accounts.json"

    init() {
        load()
    }

    private var indexURL: URL {
        LibraryStore.documentsDirectory().appendingPathComponent(fileName)
    }

    private func load() {
        guard let data = try? Data(contentsOf: indexURL),
              let decoded = try? JSONDecoder().decode([SocialAccount].self, from: data) else {
            accounts = []
            return
        }
        accounts = decoded.sorted { $0.connectedAt < $1.connectedAt }
    }

    private func save() {
        do {
            let data = try JSONEncoder().encode(accounts)
            try data.write(to: indexURL, options: .atomic)
        } catch {
            // In-memory state is still right; it retries on next launch.
        }
    }

    // MARK: - Accounts

    func add(_ account: SocialAccount) {
        // One record per remote id + platform: reconnecting replaces the
        // old record instead of stacking duplicates.
        accounts.removeAll { $0.remoteID == account.remoteID && $0.platform == account.platform }
        accounts.append(account)
        accounts.sort { $0.connectedAt < $1.connectedAt }
        save()
    }

    func remove(_ account: SocialAccount) {
        accounts.removeAll { $0.id == account.id }
        save()
        KeychainHelper.delete(forKey: tokenKey(for: account))
    }

    func update(_ account: SocialAccount) {
        guard let index = accounts.firstIndex(where: { $0.id == account.id }) else { return }
        accounts[index] = account
        save()
    }

    func account(id: UUID) -> SocialAccount? {
        accounts.first { $0.id == id }
    }

    func markNeedsReconnect(_ account: SocialAccount) {
        var copy = account
        copy.needsReconnect = true
        update(copy)
    }

    // MARK: - Tokens (Keychain only)

    private func tokenKey(for account: SocialAccount) -> String {
        "isd.token.\(account.id.uuidString)"
    }

    func setToken(_ token: String, for account: SocialAccount) {
        KeychainHelper.save(token, forKey: tokenKey(for: account))
    }

    func token(for account: SocialAccount) -> String? {
        KeychainHelper.read(forKey: tokenKey(for: account))
    }

    /// The Facebook user token from sign-in (used to list Pages).
    var userToken: String? {
        get { KeychainHelper.read(forKey: "isd.token.user") }
        set {
            if let newValue {
                KeychainHelper.save(newValue, forKey: "isd.token.user")
            } else {
                KeychainHelper.delete(forKey: "isd.token.user")
            }
        }
    }
}
