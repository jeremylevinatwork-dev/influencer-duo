import Foundation
import Network

/// Watches the network so the outbox knows when it can upload. The app
/// never assumes a connection: recording and photos work fully offline,
/// and this is only the trigger that drains the queue once the phone is
/// back online.
final class NetworkMonitor: ObservableObject {
    @Published private(set) var isOnline = true

    /// Called on the main queue whenever connectivity changes.
    var onChange: ((Bool) -> Void)?

    private let monitor = NWPathMonitor()
    private let queue = DispatchQueue(label: "com.jhnlsecuritytech.influencestar.network")

    func start() {
        monitor.pathUpdateHandler = { [weak self] path in
            let online = path.status == .satisfied
            DispatchQueue.main.async {
                guard let self else { return }
                self.isOnline = online
                self.onChange?(online)
            }
        }
        monitor.start(queue: queue)
    }

    func stop() {
        monitor.cancel()
    }
}
