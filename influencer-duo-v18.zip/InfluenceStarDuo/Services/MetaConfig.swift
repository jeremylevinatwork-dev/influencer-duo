import Foundation

/// Meta (Facebook / Instagram) connection facts. There are no secrets
/// in this file: the App ID is a public client identifier, and the user
/// types it into the Accounts screen — it is stored in UserDefaults,
/// never baked into the build. Tokens are handled by AccountStore and
/// live in the Keychain.
///
/// Setup the user does once, in Meta's developer dashboard:
///   1. Create an app at developers.facebook.com.
///   2. Add "Facebook Login" and "Instagram Graph API" products.
///   3. Add `influencestar://oauth` as an allowed OAuth redirect URI.
///   4. Paste the App ID into Accounts in this app.
/// Until the App ID is set, the Connect buttons explain this instead
/// of failing.
enum MetaConfig {
    /// Graph API version pinned for every call in the app.
    static let graphVersion = "v19.0"
    /// Custom URL scheme the OAuth dialog returns to (see Info.plist).
    static let callbackScheme = "influencestar"
    /// Everything auto-post needs: list Pages, read them, post to them,
    /// and publish Instagram media through them.
    static let scopes = [
        "pages_show_list",
        "pages_read_engagement",
        "pages_manage_posts",
        "instagram_basic",
        "instagram_content_publish"
    ].joined(separator: ",")

    private static let appIDKey = "isd.meta.appID"

    /// The Meta App ID the user entered. Empty until set up.
    static var appID: String {
        get { UserDefaults.standard.string(forKey: appIDKey) ?? "" }
        set { UserDefaults.standard.set(newValue, forKey: appIDKey) }
    }

    static var isConfigured: Bool {
        !appID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    /// The Facebook Login dialog URL, or nil when no App ID is set.
    static func authURL() -> URL? {
        guard isConfigured else { return nil }
        var components = URLComponents(string: "https://www.facebook.com/\(graphVersion)/dialog/oauth")
        components?.queryItems = [
            URLQueryItem(name: "client_id", value: appID),
            URLQueryItem(name: "redirect_uri", value: "\(callbackScheme)://oauth"),
            URLQueryItem(name: "scope", value: scopes),
            URLQueryItem(name: "response_type", value: "token")
        ]
        return components?.url
    }

    static func graphURL(path: String) -> URL? {
        URL(string: "https://graph.facebook.com/\(graphVersion)/\(path)")
    }
}

extension String {
    /// Percent-encoding for a single form value in a POST body.
    var urlFormEncoded: String {
        addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
    }
}
