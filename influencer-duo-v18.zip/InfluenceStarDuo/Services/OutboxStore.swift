import Foundation

/// The persistent outbox: every auto-post that has not gone out yet,
/// kept in outbox.json. A job survives the app closing, the phone
/// restarting, and long offline stretches — it is only ever removed by
/// succeeding, or by the user deleting it.
final class OutboxStore: ObservableObject {
    @Published private(set) var jobs: [PostJob] = []

    private let fileName = "outbox.json"

    init() {
        load()
    }

    private var indexURL: URL {
        LibraryStore.documentsDirectory().appendingPathComponent(fileName)
    }

    private func load() {
        guard let data = try? Data(contentsOf: indexURL),
              let decoded = try? JSONDecoder().decode([PostJob].self, from: data) else {
            jobs = []
            return
        }
        jobs = decoded.sorted { $0.createdAt < $1.createdAt }
    }

    private func save() {
        do {
            let data = try JSONEncoder().encode(jobs)
            try data.write(to: indexURL, options: .atomic)
        } catch {
            // In-memory state is still right; it retries on next launch.
        }
    }

    /// Queues a post, unless the same media + account + platform is
    /// already waiting (a finished video must never post twice).
    @discardableResult
    func enqueue(mediaItemID: UUID, accountID: UUID, platform: PostJob.Platform) -> PostJob {
        if let existing = jobs.first(where: {
            $0.mediaItemID == mediaItemID && $0.accountID == accountID && $0.platform == platform
                && ($0.state == .queued || $0.state == .uploading)
        }) {
            return existing
        }
        let job = PostJob(mediaItemID: mediaItemID, accountID: accountID, platform: platform)
        jobs.append(job)
        save()
        return job
    }

    func update(_ job: PostJob) {
        guard let index = jobs.firstIndex(where: { $0.id == job.id }) else { return }
        jobs[index] = job
        save()
    }

    func remove(_ job: PostJob) {
        jobs.removeAll { $0.id == job.id }
        save()
    }

    /// Puts a failed job back in line for another try.
    func retry(_ job: PostJob) {
        var copy = job
        copy.state = .queued
        copy.attempts = 0
        copy.lastError = nil
        copy.updatedAt = Date()
        update(copy)
    }

    func jobs(for mediaItemID: UUID) -> [PostJob] {
        jobs.filter { $0.mediaItemID == mediaItemID }
    }

    func pendingJobs() -> [PostJob] {
        jobs.filter { $0.state == .queued }.sorted { $0.createdAt < $1.createdAt }
    }
}
