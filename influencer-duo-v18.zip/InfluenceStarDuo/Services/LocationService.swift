import CoreLocation
import Foundation

/// Finds where the phone is and names the place — the "Add location"
/// check-in. The name and address come from Apple's CLGeocoder, which
/// is free and needs no key. When Jeremy has set a Google Places API
/// key (see GooglePlacesConfig), the service also asks Google for the
/// place's star rating; without a key, or when Google has no rating
/// for the place, the rating is simply absent — never invented.
///
/// Location is off by default: nothing here runs until the operator
/// taps Add location. The first tap triggers the system permission
/// prompt; a denial is a plain-words message, and filming carries on
/// normally without a place.
final class LocationService: NSObject, CLLocationManagerDelegate {

    enum LocationError: Error {
        /// Location permission denied (or restricted). The fix lives in Settings.
        case denied
        /// The phone couldn't get a fix (indoors, no signal, services off).
        case unavailable
        /// A fix came back but Apple couldn't name the spot.
        case noPlaceFound
        /// The reverse-geocode lookup itself failed (usually no network).
        case network

        var plainMessage: String {
            switch self {
            case .denied:
                return "Location is off for Influencer Dúo — turn it on in Settings to add a place."
            case .unavailable:
                return "Couldn't find where you are right now. Try again outside or near a window."
            case .noPlaceFound:
                return "Couldn't name this spot. Try again in a moment."
            case .network:
                return "Couldn't look up this place — check your connection and try again."
            }
        }
    }

    private var manager: CLLocationManager?
    private let geocoder = CLGeocoder()
    private var locationContinuation: CheckedContinuation<CLLocation, Error>?
    private var authContinuation: CheckedContinuation<Void, Never>?

    /// The location manager, created on the main thread the first time
    /// it is needed so its delegate callbacks arrive on the main thread.
    @MainActor
    private func mainManager() -> CLLocationManager {
        if let manager { return manager }
        let manager = CLLocationManager()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        self.manager = manager
        return manager
    }

    /// One shot: the phone's current place, or the plain-words reason
    /// it couldn't be found. Runs on the main actor (CoreLocation
    /// wants the main thread); safe to await from anywhere.
    @MainActor
    func findCurrentPlace() async -> Result<Place, LocationError> {
        do {
            let coordinate = try await currentCoordinate()
            let place = try await place(for: coordinate)
            return .success(place)
        } catch let error as LocationError {
            return .failure(error)
        } catch {
            return .failure(.network)
        }
    }

    /// The phone's current coordinate. Asks for when-in-use permission
    /// the first time (the system prompt), then takes a single fix.
    @MainActor
    private func currentCoordinate() async throws -> CLLocationCoordinate2D {
        let manager = mainManager()
        switch manager.authorizationStatus {
        case .notDetermined:
            // Wait for the operator to answer the system prompt, then
            // look again — the answer lands in the delegate callback.
            await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
                authContinuation = continuation
                manager.requestWhenInUseAuthorization()
            }
            return try await currentCoordinate()
        case .denied, .restricted:
            throw LocationError.denied
        default:
            break
        }
        let location: CLLocation = try await withCheckedThrowingContinuation { continuation in
            locationContinuation = continuation
            manager.requestLocation()
        }
        return location.coordinate
    }

    /// Turns a coordinate into a named place. The name is the
    /// business/landmark name when Apple knows one, otherwise the
    /// neighbourhood or town — never a guess.
    private func place(for coordinate: CLLocationCoordinate2D) async throws -> Place {
        let location = CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude)
        let placemarks: [CLPlacemark]
        do {
            placemarks = try await geocoder.reverseGeocodeLocation(location)
        } catch {
            throw LocationError.network
        }
        guard let mark = placemarks.first else { throw LocationError.noPlaceFound }
        let name = mark.name ?? mark.areasOfInterest?.first ?? mark.locality ?? "Unknown place"
        var addressParts: [String] = []
        let street = [mark.subThoroughfare, mark.thoroughfare].compactMap { $0 }.joined(separator: " ")
        if !street.isEmpty { addressParts.append(street) }
        if let locality = mark.locality { addressParts.append(locality) }
        if let region = mark.administrativeArea { addressParts.append(region) }
        if let postal = mark.postalCode { addressParts.append(postal) }
        let address = addressParts.isEmpty ? (mark.country ?? "") : addressParts.joined(separator: ", ")
        var place = Place(name: name, address: address,
                          latitude: coordinate.latitude, longitude: coordinate.longitude)
        if GooglePlacesConfig.isConfigured {
            if let rating = await fetchGoogleRating(near: coordinate, named: name) {
                place.googleRating = rating.rating
                place.googleRatingCount = rating.count
            }
        }
        return place
    }

    // MARK: - Google Places rating (optional, key required)

    /// Google Places Nearby Search for the star rating of the place we
    /// are standing at. Only a result that is clearly THIS place counts:
    /// its name has to line up with the place name, or it has to be
    /// within 75 metres. Anything else is a different place's rating
    /// and is never used. Any failure — no key, no network, no match —
    /// just means no Google rating; the caller never sees an error.
    private func fetchGoogleRating(near coordinate: CLLocationCoordinate2D, named name: String) async -> (rating: Double, count: Int)? {
        var components = URLComponents(string: "https://maps.googleapis.com/maps/api/place/nearbysearch/json")
        components?.queryItems = [
            URLQueryItem(name: "location", value: "\(coordinate.latitude),\(coordinate.longitude)"),
            URLQueryItem(name: "radius", value: "150"),
            URLQueryItem(name: "key", value: GooglePlacesConfig.apiKey)
        ]
        guard let url = components?.url else { return nil }
        do {
            let (data, response) = try await URLSession.shared.data(from: url)
            guard (response as? HTTPURLResponse)?.statusCode == 200,
                  let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let results = json["results"] as? [[String: Any]] else { return nil }
            let here = CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude)
            let candidates: [(name: String, rating: Double, count: Int, distance: Double)] = results.compactMap { result in
                guard let resultName = result["name"] as? String,
                      let rating = result["rating"] as? Double,
                      let geometry = result["geometry"] as? [String: Any],
                      let loc = geometry["location"] as? [String: Any],
                      let lat = loc["lat"] as? Double,
                      let lng = loc["lng"] as? Double else { return nil }
                let distance = CLLocation(latitude: lat, longitude: lng).distance(from: here)
                return (resultName, rating, result["user_ratings_total"] as? Int ?? 0, distance)
            }
            let lower = name.lowercased()
            let named = candidates
                .filter { $0.name.lowercased().contains(lower) || lower.contains($0.name.lowercased()) }
                .sorted { $0.distance < $1.distance }
                .first
            if let match = named { return (match.rating, match.count) }
            if let closest = candidates.sorted(by: { $0.distance < $1.distance }).first,
               closest.distance <= 75 {
                return (closest.rating, closest.count)
            }
            return nil
        } catch {
            return nil
        }
    }

    // MARK: - CLLocationManagerDelegate

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        guard let continuation = authContinuation else { return }
        switch manager.authorizationStatus {
        case .notDetermined:
            // Still deciding — keep waiting; the next callback resumes us.
            break
        default:
            authContinuation = nil
            continuation.resume()
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let continuation = locationContinuation, let last = locations.last else { return }
        locationContinuation = nil
        continuation.resume(returning: last)
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        guard let continuation = locationContinuation else { return }
        locationContinuation = nil
        if let clError = error as? CLError, clError.code == .denied {
            continuation.resume(throwing: LocationError.denied)
        } else {
            continuation.resume(throwing: LocationError.unavailable)
        }
    }
}
