import Foundation

/// TikTok connection facts (Login Kit + Content Posting API). There
/// are no secrets in this file: the Client Key is a public client
/// identifier, and the user types it into the Accounts screen — it is
/// stored in UserDefaults, never baked into the build. Tokens live in
/// the Keychain (see AccountStore).
///
/// Setup the user does once, in TikTok's developer portal:
///   1. Create an app at developers.tiktok.com.
///   2. Add the "Login Kit" and "Content Posting API" products.
///   3. Add `influencestar://tiktok-auth` as an allowed redirect URI.
///   4. Paste the Client Key into Accounts in this app.
/// Until the Client Key is set, the Connect button explains this
/// instead of failing.
///
/// Honest limits, baked into the design:
///   - Videos only. TikTok's API has no photo direct-post, so photos
///     go through the iOS share sheet into the TikTok app.
///   - Access tokens last about a day. Refreshing one needs the app
///     secret, which cannot live in a client app, so the app prompts
///     the user to reconnect when a token expires instead of
///     pretending it can refresh silently.
enum TikTokConfig {
    /// Login Kit scopes: read the basic profile, upload videos.
    static let scopes = "user.info.basic,video.upload"
    /// Custom URL scheme the OAuth dialog returns to (see Info.plist).
    static let callbackScheme = "influencestar"
    static let redirectURI = "influencestar://tiktok-auth"

    private static let clientKeyKey = "isd.tiktok.clientKey"

    /// The TikTok Client Key the user entered. Empty until set up.
    static var clientKey: String {
        get { UserDefaults.standard.string(forKey: clientKeyKey) ?? "" }
        set { UserDefaults.standard.set(newValue, forKey: clientKeyKey) }
    }

    static var isConfigured: Bool {
        !clientKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    /// The Login Kit authorization URL, or nil when no Client Key is set.
    static func authURL() -> URL? {
        guard isConfigured else { return nil }
        var components = URLComponents(string: "https://www.tiktok.com/v2/auth/authorize/")
        components?.queryItems = [
            URLQueryItem(name: "client_key", value: clientKey),
            URLQueryItem(name: "scope", value: scopes),
            URLQueryItem(name: "response_type", value: "code"),
            URLQueryItem(name: "redirect_uri", value: redirectURI),
            URLQueryItem(name: "state", value: UUID().uuidString)
        ]
        return components?.url
    }

    static func apiURL(path: String) -> URL? {
        URL(string: "https://open.tiktokapis.com/v2/\(path)")
    }
}
