import Foundation

/// One influencer's ask for free Pro access: their name and their
/// social handle, so Jeremy can look them up and decide.
///
/// There is no server in v1, so requests live on the device
/// (pro-requests.json) until the influencer sends one to Jeremy —
/// the paywall offers a Share button that hands the request text to
/// Messages, Mail or any app. Jeremy approves by issuing an App Store
/// offer code for the subscription; the influencer redeems it in the
/// app and the state machine treats it as comped Pro. Nothing here
/// grants access by itself — an unapproved request stays a request,
/// and the app says exactly that.
struct ProRequest: Identifiable, Codable, Equatable {
    var id: UUID
    var name: String
    var handle: String
    var platform: String
    var createdAt: Date

    init(id: UUID = UUID(), name: String, handle: String, platform: String, createdAt: Date = Date()) {
        self.id = id
        self.name = name
        self.handle = handle
        self.platform = platform
        self.createdAt = createdAt
    }

    /// The text the influencer shares to Jeremy, so he can look the
    /// account up and decide.
    var shareText: String {
        "Hi — I'd like free Pro access to Influencer Dúo.\nName: \(name)\nHandle: \(handle) (\(platform))\nRequested in the app on \(Self.shortDate(createdAt))."
    }

    private static func shortDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        return formatter.string(from: date)
    }
}

final class ProRequestStore: ObservableObject {
    @Published private(set) var requests: [ProRequest] = []

    private let fileName = "pro-requests.json"

    init() {
        load()
    }

    private var indexURL: URL {
        LibraryStore.documentsDirectory().appendingPathComponent(fileName)
    }

    private func load() {
        guard let data = try? Data(contentsOf: indexURL),
              let decoded = try? JSONDecoder().decode([ProRequest].self, from: data) else {
            requests = []
            return
        }
        requests = decoded.sorted { $0.createdAt > $1.createdAt }
    }

    private func save() {
        do {
            let data = try JSONEncoder().encode(requests)
            try data.write(to: indexURL, options: .atomic)
        } catch {
            // In-memory state is still right; it retries on next launch.
        }
    }

    /// Saves a request. Returns the saved record, or nil when the
    /// name or handle is empty.
    @discardableResult
    func submit(name: String, handle: String, platform: String) -> ProRequest? {
        let cleanName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanHandle = handle.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanName.isEmpty, !cleanHandle.isEmpty else { return nil }
        // One pending request per handle: re-asking replaces the old one.
        requests.removeAll { $0.handle.lowercased() == cleanHandle.lowercased() }
        let request = ProRequest(name: cleanName, handle: cleanHandle, platform: platform)
        requests.insert(request, at: 0)
        save()
        return request
    }
}
