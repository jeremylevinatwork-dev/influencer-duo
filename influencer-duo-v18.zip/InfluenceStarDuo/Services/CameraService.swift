import AVFoundation
import Foundation
import os

/// Camera-service log: v10 failed silently (both previews black,
/// nothing in the console), so every refused preview connection is
/// logged here from v11 on.
private let cameraLog = Logger(subsystem: "com.jhnlsecuritytech.influencestar", category: "camera")

/// Owns the capture hardware and nothing else. It runs the back and
/// front cameras at the same time (AVCaptureMultiCamSession) — the
/// whole point of this app. Built for iPhone 15 Pro and up (iOS 17+),
/// every one of which runs multi-cam. If multi-cam is ever unavailable
/// on a device, there is no fallback: `configure()` sets a plain-words
/// status message instead, and the Camera screen shows it.
/// The UI never touches AVFoundation directly — it reads @Published
/// state and calls the plain methods below.
///
/// Design notes, learned from the platform:
/// - The front camera's preview is mirrored so the talent monitor
///   reads like a mirror; the recorded front file is true-to-life.
/// - Rotation comes from AVCaptureDevice.RotationCoordinator (iOS 17+),
///   which keeps preview and captures horizon-level; the manual
///   ROTATE offset sits on top of it and is remembered between launches.
final class CameraService: NSObject, ObservableObject {
    // MARK: - Published state (always set on the main queue)

    @Published private(set) var isRunning = false
    @Published private(set) var isRecording = false
    @Published private(set) var multiCamActive = false
    /// Which camera the UI treats as main. SWAP flips it; the other
    /// camera rides picture-in-picture.
    @Published private(set) var mainIsFront = false
    /// Counts session builds. The preview views key off it, so a
    /// rebuilt session (RESTART, or the 0.5x lens change) gets fresh
    /// layers: a layer can only ever belong to the one session it
    /// was first bound to, so reusing a pre-restart layer would
    /// leave it black forever (the bind-once rule that stopped the
    /// v11 crash also forbids rebinding to a new session).
    @Published private(set) var sessionGeneration = 0
    /// Each camera can be turned off by the operator, mid-take —
    /// at least one always stays on. Persisted between launches.
    /// The value is the operator's switch, not the hardware state:
    /// a camera is "on" here when its connections are enabled.
    @Published private(set) var backCameraOn: Bool = UserDefaults.standard.object(forKey: "isd.camera.backOn") as? Bool ?? true
    @Published private(set) var frontCameraOn: Bool = UserDefaults.standard.object(forKey: "isd.camera.frontOn") as? Bool ?? true
    /// Zoom is stored PER CAMERA (v18): each camera keeps its own
    /// lens factor, so swapping which camera is main restores that
    /// camera's framing instead of dragging the other camera's zoom
    /// along — and a session rebuild (RESTART, lens change)
    /// re-applies each camera's own factor instead of slamming both
    /// back to 1x. These two are the UI-facing mirrors; the session
    /// queue keeps the working copies (`storedBackZoomFactor` /
    /// `storedFrontZoomFactor`). Session-only, not persisted.
    @Published private(set) var backZoomFactor: CGFloat = 1.0
    @Published private(set) var frontZoomFactor: CGFloat = 1.0
    /// The main camera's own lens factor.
    var zoomFactor: CGFloat { mainIsFront ? frontZoomFactor : backZoomFactor }
    /// Whether the back camera is on its ultra-wide lens (0.5x). The
    /// wide lens cannot go below 1x, so a wider view means switching
    /// lenses. Persisted; the zoom pill cycles 0.5x -> 1x -> 2x -> 3x.
    /// A fresh install has no saved preference and opens on the
    /// ultra-wide lens (v18): the app opens with the widest framing,
    /// not the tight 1x wide-lens view Jeremy called too close.
    @Published private(set) var backIsUltraWide: Bool = {
        let defaults = UserDefaults.standard
        guard defaults.object(forKey: "isd.camera.backUltraWide") != nil else { return true }
        return defaults.bool(forKey: "isd.camera.backUltraWide")
    }()
    /// The zoom the pill shows, in display terms: for the front
    /// camera its factor as-is (one lens, digital zoom only); for
    /// the back camera, 0.5x-based on the ultra-wide lens and the
    /// plain factor on the wide lens.
    var displayZoomFactor: CGFloat {
        if mainIsFront { return frontZoomFactor }
        return backIsUltraWide ? backZoomFactor * 0.5 : backZoomFactor
    }

    /// The talent monitor on the outer display (see
    /// OuterDisplayController). Lazy so the service can hand itself
    /// to the controller once it exists.
    lazy var outerDisplay = OuterDisplayController(camera: self)
    /// Plain-words status for the screen (permission problems, no
    /// camera, and so on). Nil when everything is fine.
    @Published private(set) var statusMessage: String?

    /// Preview layers are owned by the VIEWS now (the Apple Way
    /// — see CameraPreviewView): each view's backing layer IS its
    /// preview layer, and the view registers it here under its role
    /// so the service can connect it to a camera port. The service
    /// never creates a preview layer. `back` is the scene and
    /// `front` is the influencer; which one is main is
    /// `mainIsFront`.

    /// Manual rotation correction in degrees (0/90/180/270), added on
    /// top of the coordinator's horizon-level angle and remembered.
    @Published var rotationOffset: CGFloat = CGFloat(UserDefaults.standard.double(forKey: "isd.camera.rotationOffset")) {
        didSet {
            UserDefaults.standard.set(rotationOffset, forKey: "isd.camera.rotationOffset")
            applyCurrentAngles()
        }
    }

    var multiCamSupported: Bool { AVCaptureMultiCamSession.isMultiCamSupported }

    // MARK: - Private state

    private let sessionQueue = DispatchQueue(label: "com.jhnlsecuritytech.influencestar.camera")

    private var duoSession: AVCaptureMultiCamSession?
    private var started = false

    private var backDevice: AVCaptureDevice?
    private var frontDevice: AVCaptureDevice?

    /// The working copies of the per-camera zoom factors, touched
    /// only on the session queue: zoom changes land here first, the
    /// @Published mirrors follow on main for the UI, and a rebuilt
    /// session reads these to restore each camera's framing.
    private var storedBackZoomFactor: CGFloat = 1.0
    private var storedFrontZoomFactor: CGFloat = 1.0

    private var duoBackPhotoOutput: AVCapturePhotoOutput?
    private var duoFrontPhotoOutput: AVCapturePhotoOutput?
    private var duoBackMovieOutput: AVCaptureMovieFileOutput?
    private var duoFrontMovieOutput: AVCaptureMovieFileOutput?

    private var backCoordinator: AVCaptureDevice.RotationCoordinator?
    private var frontCoordinator: AVCaptureDevice.RotationCoordinator?
    private var backPreviewObservation: NSKeyValueObservation?
    private var frontPreviewObservation: NSKeyValueObservation?

    /// Connections that need the rotation angle re-applied.
    private var backPreviewConnection: AVCaptureConnection?
    private var frontPreviewConnection: AVCaptureConnection?
    private var backMovieConnection: AVCaptureConnection?
    private var frontMovieConnection: AVCaptureConnection?
    private var backPhotoConnection: AVCaptureConnection?
    private var frontPhotoConnection: AVCaptureConnection?
    /// Connections feeding the outer display's layers.
    private var outerBackConnection: AVCaptureConnection?
    private var outerFrontConnection: AVCaptureConnection?

    /// Layers registered by the preview views (the Apple Way):
    /// each view's backing layer, keyed by the layer's identity,
    /// with the role it currently shows. The service never creates
    /// preview layers — it only connects the views' layers to
    /// camera ports.
    private var registeredPreviewLayers: [ObjectIdentifier: AVCaptureVideoPreviewLayer] = [:]
    private var registeredPreviewRoles: [ObjectIdentifier: CameraPreviewView.Role] = [:]
    /// The camera ports, once the dual session is configured, so a
    /// layer that registers late (the outer display) can be
    /// connected at once.
    private var duoBackPort: AVCaptureInput.Port?
    private var duoFrontPort: AVCaptureInput.Port?
    /// Which layer each rotation coordinator was built with, so a
    /// re-created view gets a fresh coordinator for its new layer.
    private var backCoordinatorLayer: AVCaptureVideoPreviewLayer?
    private var frontCoordinatorLayer: AVCaptureVideoPreviewLayer?

    private var photoCompletion: ((Data?) -> Void)?
    private var duoStopCompletion: ((URL?, URL?) -> Void)?
    private var duoBackURL: URL?
    private var duoFrontURL: URL?
    private var duoBackDone = false
    private var duoFrontDone = false
    /// Whether each camera is actually recording this take. An
    /// off camera never starts, and stop never waits for it — so
    /// turning a camera off mid-take can never hang the stop.
    private var duoBackRecording = false
    private var duoFrontRecording = false
    /// The exact temp files handed to the movie outputs at record
    /// start (v17). If a delegate callback misfires, stop checks
    /// these paths on disk before giving up on the take.
    private var duoBackFileURL: URL?
    private var duoFrontFileURL: URL?
    /// Whether each output's didStart callback fired this take —
    /// the difference between "the cameras never started" and
    /// "they started but wrote nothing".
    private var duoBackDidStart = false
    private var duoFrontDidStart = false
    /// The last recording error the delegate reported, as
    /// "domain code" (v17) — kept so a failed take can say why
    /// instead of the error being thrown away unread.
    private var duoRecordingErrorCode: String?
    /// A file that finishes AFTER the take already closed (the stop
    /// safety fired first): the view model saves it straight to the
    /// Library and Photos, so a slow finalize can never silently eat
    /// a take. Nil until the view model sets it.
    var onLateRecordingFile: ((URL) -> Void)?
    /// Plain-words reason the last stopped take produced no file
    /// (v17): the delegate's error, or that the cameras never
    /// started. Set on the main queue in finishDuoStop just before
    /// the stop completion runs, so the view model can read it the
    /// moment the completion lands. Nil when a file was delivered.
    @Published private(set) var lastRecordingError: String?

    override init() {
        super.init()
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(sessionInterruptedEnded),
            name: .AVCaptureSessionInterruptionEnded,
            object: nil)
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(sessionRuntimeError),
            name: .AVCaptureSessionRuntimeError,
            object: nil)
    }

    // MARK: - Startup

    func start() {
        guard !started else { return }
        started = true
        AVCaptureDevice.requestAccess(for: .video) { [weak self] videoOK in
            guard let self else { return }
            AVCaptureDevice.requestAccess(for: .audio) { _ in
                guard videoOK else {
                    DispatchQueue.main.async {
                        self.statusMessage = "Camera access is off — turn it on in Settings to film."
                    }
                    return
                }
                self.sessionQueue.async { self.configure() }
            }
        }
    }

    /// Another app can take the camera and stop a session; when it lets
    /// go, start again instead of staying black.
    func resumeIfNeeded() {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if self.multiCamActive, let session = self.duoSession, !session.isRunning {
                session.startRunning()
            }
        }
    }

    @objc private func sessionInterruptedEnded(_ note: Notification) {
        resumeIfNeeded()
    }

    @objc private func sessionRuntimeError(_ note: Notification) {
        resumeIfNeeded()
    }

    private func configure() {
        if multiCamSupported {
            startDual { }
        } else {
            // No fallback: this app is built for iPhone 15 Pro and up,
            // and every one of those runs multi-cam. Say so plainly.
            DispatchQueue.main.async {
                self.statusMessage = "This iPhone can't run both cameras at once, so dual recording isn't available. Influencer Dúo needs an iPhone 15 Pro or newer."
            }
        }
    }

    // MARK: - Dual camera

    private struct DuoWiring {
        var backPhotoOutput: AVCapturePhotoOutput?
        var frontPhotoOutput: AVCapturePhotoOutput?
        var backMovieOutput: AVCaptureMovieFileOutput?
        var frontMovieOutput: AVCaptureMovieFileOutput?
        var backPhotoConnection: AVCaptureConnection?
        var frontPhotoConnection: AVCaptureConnection?
        var backMovieConnection: AVCaptureConnection?
        var frontMovieConnection: AVCaptureConnection?
    }

    /// Starts the dual session: back and front cameras at the same time.
    /// The preview views own their layers (the Apple Way) and register
    /// them here; once the ports exist, every registered layer is
    /// connected to its camera. The completion just reports the
    /// session is up (or refused, with the plain-words status set).
    func startDual(completion: @escaping () -> Void) {
        guard multiCamSupported else {
            DispatchQueue.main.async {
                self.statusMessage = "This iPhone can't run both cameras at once, so dual recording isn't available. Influencer Dúo needs an iPhone 15 Pro or newer."
            }
            completion()
            return
        }
        sessionQueue.async { [weak self] in
            guard let self else { return }
            // duoSession is set on this queue, so it closes the race
            // multiCamActive leaves open: multiCamActive flips on main
            // after startRunning, so a second startDual (onAppear firing
            // twice) could build a second session while the layers still
            // belong to the first — and rebinding them would abort the
            // app inside AVCaptureVideoPreviewLayer (the v11 crash).
            if self.multiCamActive || self.duoSession != nil {
                DispatchQueue.main.async { completion() }
                return
            }
            let session = AVCaptureMultiCamSession()
            session.beginConfiguration()
            let backDeviceType: AVCaptureDevice.DeviceType = self.backIsUltraWide ? .builtInUltraWideCamera : .builtInWideAngleCamera
            guard let backDevice = AVCaptureDevice.default(backDeviceType, for: .video, position: .back) ?? AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
                  let backInput = try? AVCaptureDeviceInput(device: backDevice),
                  session.canAddInput(backInput),
                  let frontDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front),
                  let frontInput = try? AVCaptureDeviceInput(device: frontDevice),
                  session.canAddInput(frontInput) else {
                session.commitConfiguration()
                DispatchQueue.main.async {
                    self.statusMessage = "This iPhone can't run both cameras at once, so dual recording isn't available. Influencer Dúo needs an iPhone 15 Pro or newer."
                    completion()
                }
                return
            }
            session.addInputWithNoConnections(backInput)
            session.addInputWithNoConnections(frontInput)

            guard let backPort = backInput.ports(for: .video, sourceDeviceType: backDevice.deviceType, sourceDevicePosition: backDevice.position).first,
                  let frontPort = frontInput.ports(for: .video, sourceDeviceType: frontDevice.deviceType, sourceDevicePosition: frontDevice.position).first else {
                session.commitConfiguration()
                DispatchQueue.main.async { completion() }
                return
            }
            // The preview views own their layers (the Apple Way) —
            // no layer is created here. The ports are remembered so
            // every registered layer can be connected now, and any
            // layer that registers later (the outer display) can be
            // connected the moment it arrives.
            self.duoBackPort = backPort
            self.duoFrontPort = frontPort

            let wiring = self.wireDuoOutputs(session: session, backPort: backPort, frontPort: frontPort)
            session.commitConfiguration()

            self.duoSession = session
            self.backDevice = backDevice
            self.frontDevice = frontDevice
            self.backMovieConnection = wiring.backMovieConnection
            self.frontMovieConnection = wiring.frontMovieConnection
            self.backPhotoConnection = wiring.backPhotoConnection
            self.frontPhotoConnection = wiring.frontPhotoConnection
            self.duoBackPhotoOutput = wiring.backPhotoOutput
            self.duoFrontPhotoOutput = wiring.frontPhotoOutput
            self.duoBackMovieOutput = wiring.backMovieOutput
            self.duoFrontMovieOutput = wiring.frontMovieOutput
            // Connect every preview view that already registered its
            // layer, and set up rotation for the ones on screen.
            self.connectRegisteredPreviewLayers()
            self.maybeCreateCoordinators()
            session.startRunning()
            // Each camera comes up with its OWN zoom factor (v18) —
            // a rebuilt session restores the operator's framing
            // instead of resetting to a tight 1x.
            self.applyStoredZoomFactors()
            DispatchQueue.main.async {
                self.sessionGeneration += 1
                self.multiCamActive = true
                self.isRunning = true
                self.statusMessage = nil
                completion()
            }
        }
    }

    /// Stops the dual session.
    func stopDual(completion: (() -> Void)? = nil) {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if self.multiCamActive {
                self.duoSession?.stopRunning()
                self.duoSession = nil
                self.backDevice = nil
                self.frontDevice = nil
                self.backCoordinator = nil
                self.frontCoordinator = nil
                self.backCoordinatorLayer = nil
                self.frontCoordinatorLayer = nil
                self.duoBackPort = nil
                self.duoFrontPort = nil
                self.backPreviewObservation = nil
                self.frontPreviewObservation = nil
                self.backPreviewConnection = nil
                self.frontPreviewConnection = nil
                self.outerBackConnection = nil
                self.outerFrontConnection = nil
                self.backMovieConnection = nil
                self.frontMovieConnection = nil
                self.backPhotoConnection = nil
                self.frontPhotoConnection = nil
                self.duoBackPhotoOutput = nil
                self.duoFrontPhotoOutput = nil
                self.duoBackMovieOutput = nil
                self.duoFrontMovieOutput = nil
                self.duoStopCompletion = nil
                DispatchQueue.main.async {
                    self.multiCamActive = false
                    self.mainIsFront = false
                }
            }
            if let completion { DispatchQueue.main.async(execute: completion) }
        }
    }

    /// The capture outputs on the dual session: a photo output on each
    /// camera (so a still always comes from whichever camera is main)
    /// and a movie output on each camera. Sound rides in the back
    /// camera's file, when the device allows a mic alongside two
    /// cameras.
    private func wireDuoOutputs(session: AVCaptureMultiCamSession,
                                backPort: AVCaptureInput.Port,
                                frontPort: AVCaptureInput.Port) -> DuoWiring {
        var wiring = DuoWiring()
        let backPhoto = AVCapturePhotoOutput()
        if session.canAddOutput(backPhoto) {
            session.addOutputWithNoConnections(backPhoto)
            let connection = AVCaptureConnection(inputPorts: [backPort], output: backPhoto)
            if session.canAddConnection(connection) {
                session.addConnection(connection)
                wiring.backPhotoOutput = backPhoto
                wiring.backPhotoConnection = connection
            }
        }
        let frontPhoto = AVCapturePhotoOutput()
        if session.canAddOutput(frontPhoto) {
            session.addOutputWithNoConnections(frontPhoto)
            let connection = AVCaptureConnection(inputPorts: [frontPort], output: frontPhoto)
            // The saved still is true-to-life, not mirrored: only the
            // on-screen preview is mirrored, so the talent monitor
            // reads like a mirror while the file stays honest.
            connection.automaticallyAdjustsVideoMirroring = false
            connection.isVideoMirrored = false
            if session.canAddConnection(connection) {
                session.addConnection(connection)
                wiring.frontPhotoOutput = frontPhoto
                wiring.frontPhotoConnection = connection
            }
        }
        let backMovie = AVCaptureMovieFileOutput()
        if session.canAddOutput(backMovie) {
            session.addOutputWithNoConnections(backMovie)
            let connection = AVCaptureConnection(inputPorts: [backPort], output: backMovie)
            if session.canAddConnection(connection) {
                session.addConnection(connection)
                wiring.backMovieOutput = backMovie
                wiring.backMovieConnection = connection
            }
        }
        let frontMovie = AVCaptureMovieFileOutput()
        if session.canAddOutput(frontMovie) {
            session.addOutputWithNoConnections(frontMovie)
            let connection = AVCaptureConnection(inputPorts: [frontPort], output: frontMovie)
            // Recorded file is true-to-life, not mirrored — only the
            // preview is mirrored, so the talent monitor reads like a
            // mirror while the finished video stays honest.
            connection.automaticallyAdjustsVideoMirroring = false
            connection.isVideoMirrored = false
            if session.canAddConnection(connection) {
                session.addConnection(connection)
                wiring.frontMovieOutput = frontMovie
                wiring.frontMovieConnection = connection
            }
        }
        if let backMovie = wiring.backMovieOutput,
           let mic = AVCaptureDevice.default(for: .audio),
           let micInput = try? AVCaptureDeviceInput(device: mic),
           session.canAddInput(micInput) {
            session.addInputWithNoConnections(micInput)
            if let micPort = micInput.ports(for: .audio, sourceDeviceType: mic.deviceType, sourceDevicePosition: .unspecified).first {
                let audioConnection = AVCaptureConnection(inputPorts: [micPort], output: backMovie)
                if session.canAddConnection(audioConnection) {
                    session.addConnection(audioConnection)
                }
            }
        }
        return wiring
    }

    // MARK: - Preview layers (the Apple Way)

    /// A preview view registers its backing layer under the role it
    /// shows. If the session is already configured, the layer is
    /// connected to its camera's port at once; otherwise startDual
    /// connects every registered layer once the ports exist.
    func registerPreviewLayer(_ layer: AVCaptureVideoPreviewLayer, role: CameraPreviewView.Role) {
        let id = ObjectIdentifier(layer)
        sessionQueue.async { [weak self] in
            guard let self else { return }
            // A role belongs to one view at a time: if another layer
            // already shows this role (a view was re-created), drop
            // the old one first. Keys are collected before removing
            // — a dictionary cannot be mutated while it is iterated.
            let stale = self.registeredPreviewRoles.filter { $0.value == role && $0.key != id }.map { $0.key }
            for otherID in stale {
                if let other = self.registeredPreviewLayers[otherID] {
                    self.removePreviewConnection(for: other)
                }
                self.registeredPreviewLayers.removeValue(forKey: otherID)
                self.registeredPreviewRoles.removeValue(forKey: otherID)
            }
            self.registeredPreviewLayers[id] = layer
            self.registeredPreviewRoles[id] = role
            self.connectPreviewLayer(layer, role: role)
            self.maybeCreateCoordinators()
        }
    }

    /// A preview view going away takes its layer (and connection)
    /// with it.
    func unregisterPreviewLayer(_ layer: AVCaptureVideoPreviewLayer) {
        let id = ObjectIdentifier(layer)
        sessionQueue.async { [weak self] in
            guard let self else { return }
            self.removePreviewConnection(for: layer)
            self.registeredPreviewLayers.removeValue(forKey: id)
            self.registeredPreviewRoles.removeValue(forKey: id)
        }
    }

    /// Connects every registered layer — the step startDual takes
    /// once the ports exist.
    private func connectRegisteredPreviewLayers() {
        for (id, layer) in Array(registeredPreviewLayers) {
            guard let role = registeredPreviewRoles[id] else { continue }
            connectPreviewLayer(layer, role: role)
        }
    }

    /// Connects one registered layer to its role's camera port, if
    /// the session is configured. The connection is stored on the
    /// port's property so rotation and the on/off toggles keep
    /// working on it.
    private func connectPreviewLayer(_ layer: AVCaptureVideoPreviewLayer, role: CameraPreviewView.Role) {
        guard let session = duoSession else {
            // Normal during startup: the view registers before the
            // session exists, and startDual connects it once the
            // ports are ready.
            cameraLog.debug("Preview connect: no session yet for role \(String(describing: role))")
            return
        }
        let port = (role == .back || role == .outerBack) ? duoBackPort : duoFrontPort
        guard let port else {
            cameraLog.error("Preview connect: no camera port yet for role \(String(describing: role))")
            DispatchQueue.main.async {
                self.statusMessage = "The cameras started but the preview couldn't connect. Close the app and open it again — if it stays black, tell me and I'll fix it."
            }
            return
        }
        // Already feeding this exact layer? Nothing to do — this runs
        // from register and from startDual, and a second bind of one
        // layer aborts the app (the v11 crash). (Roles are fixed now:
        // SWAP never rebinds a layer, it only re-lays-out the views.)
        let existingConnection: AVCaptureConnection?
        switch role {
        case .back: existingConnection = backPreviewConnection
        case .front: existingConnection = frontPreviewConnection
        case .outerBack: existingConnection = outerBackConnection
        case .outerFront: existingConnection = outerFrontConnection
        }
        if let existingConnection, existingConnection.videoPreviewLayer === layer {
            return
        }
        // The layer belongs to its view (the Apple Way), so it starts
        // with no session at all — until this call, the session
        // refuses every preview connection and both pictures stay
        // black, with nothing in the log. That was the v10 bug: zero
        // calls to setSessionWithNoConnection anywhere in the app.
        // But the call is one-shot per layer: a layer that already
        // has a session (a SWAP rebind, or a second connect) must
        // never get it again — that is the assertion that killed v11
        // at launch. A layer bound to a DIFFERENT session is left
        // alone rather than crashed on.
        // And the call belongs on the MAIN thread. Apple's own
        // multi-cam sample binds the layer in viewDidLoad (main),
        // before the session is configured — never from the session
        // queue. v11 and v13 bound it from the session queue (a
        // background thread) and the app died at launch both times
        // (Thread 19, Thread 22 — the same preview-layer
        // assertion). The session config stays on the session queue;
        // only the layer bind moves to main, synchronously so the
        // connection below is created after the bind.
        func bindLayerIfNeeded() -> Bool {
            if layer.session == nil {
                layer.setSessionWithNoConnection(session)
                return true
            }
            return layer.session === session
        }
        let bindOK: Bool
        if Thread.isMainThread {
            bindOK = bindLayerIfNeeded()
        } else {
            bindOK = DispatchQueue.main.sync(execute: bindLayerIfNeeded)
        }
        guard bindOK else {
            cameraLog.error("Preview connect: layer already belongs to another session for role \(String(describing: role))")
            return
        }
        let connection = AVCaptureConnection(inputPort: port, videoPreviewLayer: layer)
        if role == .front || role == .outerFront {
            connection.automaticallyAdjustsVideoMirroring = false
            connection.isVideoMirrored = true
        }
        guard session.canAddConnection(connection) else {
            cameraLog.error("Preview connect: session refused the \(String(describing: role)) preview connection")
            DispatchQueue.main.async {
                self.statusMessage = "The cameras started but the preview couldn't connect. Close the app and open it again — if it stays black, tell me and I'll fix it."
            }
            return
        }
        // A layer can register late (the outer display), while the
        // session is already running, so the add goes through a
        // configuration block.
        session.beginConfiguration()
        session.addConnection(connection)
        session.commitConfiguration()
        cameraLog.info("Preview connected for role \(String(describing: role))")
        switch role {
        case .back: backPreviewConnection = connection
        case .front: frontPreviewConnection = connection
        case .outerBack: outerBackConnection = connection
        case .outerFront: outerFrontConnection = connection
        }
        // The camera's on/off switch and the current rotation angle
        // apply to the new connection at once.
        let on = (role == .back || role == .outerBack) ? backCameraOn : frontCameraOn
        connection.isEnabled = on
        applyCurrentAngles()
    }

    /// Drops the preview connection feeding one layer, if any.
    private func removePreviewConnection(for layer: AVCaptureVideoPreviewLayer) {
        guard let session = duoSession else { return }
        for connection in [backPreviewConnection, frontPreviewConnection, outerBackConnection, outerFrontConnection] {
            guard let connection, connection.videoPreviewLayer === layer else { continue }
            session.removeConnection(connection)
            if connection === backPreviewConnection { backPreviewConnection = nil }
            if connection === frontPreviewConnection { frontPreviewConnection = nil }
            if connection === outerBackConnection { outerBackConnection = nil }
            if connection === outerFrontConnection { outerFrontConnection = nil }
        }
    }

    /// The layer currently showing one role, if any.
    private func layer(for role: CameraPreviewView.Role) -> AVCaptureVideoPreviewLayer? {
        registeredPreviewRoles.first(where: { $0.value == role }).flatMap { registeredPreviewLayers[$0.key] }
    }

    /// Creates the rotation coordinators once the session is
    /// configured AND the operator screen's back and front layers
    /// are registered — a coordinator measures its layer's place in
    /// the view hierarchy, so it needs a real, on-screen layer.
    /// Called from startDual and from every registration; safe to
    /// call any time, and re-creates a side's coordinator when its
    /// layer is replaced.
    private func maybeCreateCoordinators() {
        guard duoSession != nil else { return }
        if let device = backDevice, let layer = layer(for: .back), backCoordinatorLayer !== layer {
            let coordinator = AVCaptureDevice.RotationCoordinator(device: device, previewLayer: layer)
            backCoordinator = coordinator
            backCoordinatorLayer = layer
            backPreviewObservation = coordinator.observe(
                \.videoRotationAngleForHorizonLevelPreview,
                options: [.initial, .new]) { [weak self] coordinator, change in
                    guard let self, let rawAngle = change.newValue else { return }
                    self.applyAngle(rawAngle, to: self.backPreviewConnection)
                    self.applyAngle(rawAngle, to: self.outerBackConnection)
                    let captureAngle = coordinator.videoRotationAngleForHorizonLevelCapture
                    self.applyAngle(captureAngle, to: self.backMovieConnection)
                    self.applyAngle(captureAngle, to: self.backPhotoConnection)
                }
        }
        if let device = frontDevice, let layer = layer(for: .front), frontCoordinatorLayer !== layer {
            let coordinator = AVCaptureDevice.RotationCoordinator(device: device, previewLayer: layer)
            frontCoordinator = coordinator
            frontCoordinatorLayer = layer
            frontPreviewObservation = coordinator.observe(
                \.videoRotationAngleForHorizonLevelPreview,
                options: [.initial, .new]) { [weak self] coordinator, change in
                    guard let self, let rawAngle = change.newValue else { return }
                    self.applyAngle(rawAngle, to: self.frontPreviewConnection)
                    self.applyAngle(rawAngle, to: self.outerFrontConnection)
                    let captureAngle = coordinator.videoRotationAngleForHorizonLevelCapture
                    self.applyAngle(captureAngle, to: self.frontMovieConnection)
                    self.applyAngle(captureAngle, to: self.frontPhotoConnection)
                }
        }
        // Apply the current angles right away — do not wait for the
        // phone to move before the pictures sit the right way up.
        applyCurrentAngles()
    }

    // MARK: - Rotation

    private func effectiveAngle(_ angle: CGFloat) -> CGFloat {
        var result = (angle + rotationOffset).truncatingRemainder(dividingBy: 360)
        if result < 0 { result += 360 }
        return result
    }

    private func applyAngle(_ angle: CGFloat, to connection: AVCaptureConnection?) {
        guard let connection else { return }
        let effective = effectiveAngle(angle)
        guard connection.isVideoRotationAngleSupported(effective) else { return }
        connection.videoRotationAngle = effective
    }

    private func applyCurrentAngles() {
        if let coordinator = backCoordinator {
            applyAngle(coordinator.videoRotationAngleForHorizonLevelPreview, to: backPreviewConnection)
            applyAngle(coordinator.videoRotationAngleForHorizonLevelPreview, to: outerBackConnection)
            applyAngle(coordinator.videoRotationAngleForHorizonLevelCapture, to: backMovieConnection)
            applyAngle(coordinator.videoRotationAngleForHorizonLevelCapture, to: backPhotoConnection)
        }
        if let coordinator = frontCoordinator {
            applyAngle(coordinator.videoRotationAngleForHorizonLevelPreview, to: frontPreviewConnection)
            applyAngle(coordinator.videoRotationAngleForHorizonLevelPreview, to: outerFrontConnection)
            applyAngle(coordinator.videoRotationAngleForHorizonLevelCapture, to: frontMovieConnection)
            applyAngle(coordinator.videoRotationAngleForHorizonLevelCapture, to: frontPhotoConnection)
        }
    }

    /// One tap = 90 degrees more correction, everywhere at once. The
    /// new offset is remembered for the next launch.
    func rotateBy90() {
        var next = rotationOffset + 90
        next = next.truncatingRemainder(dividingBy: 360)
        if next < 0 { next += 360 }
        rotationOffset = next
    }

    // MARK: - Main / PiP swap

    /// Trades which dual camera is main and which rides
    /// picture-in-picture. Pure state — no session reconfiguration.
    /// Zoom belongs to each camera (v18): both devices keep their
    /// own factors through the swap, so there is nothing to
    /// re-apply — the new main camera simply shows its own framing.
    func swapMainCamera() {
        guard multiCamActive else { return }
        // No swap when only one camera is on — the on camera is
        // already main.
        guard backCameraOn && frontCameraOn else { return }
        DispatchQueue.main.async {
            self.mainIsFront.toggle()
        }
    }

    /// One tap pops a camera up big as the main feed — and turns it on
    /// first if it was off. The flags change on main right away, and
    /// the connection enabling rides the session queue, so there is no
    /// async gap where a follow-up swap would still see the camera as
    /// off and silently do nothing (the old tap-FRONT-then-drag dance).
    func popCameraToMain(back: Bool) {
        guard multiCamActive else { return }
        sessionQueue.async { [weak self] in
            guard let self else { return }
            let preview = back ? self.backPreviewConnection : self.frontPreviewConnection
            let movie = back ? self.backMovieConnection : self.frontMovieConnection
            let photo = back ? self.backPhotoConnection : self.frontPhotoConnection
            let outer = back ? self.outerBackConnection : self.outerFrontConnection
            preview?.isEnabled = true
            movie?.isEnabled = true
            photo?.isEnabled = true
            outer?.isEnabled = true
        }
        if back { backCameraOn = true } else { frontCameraOn = true }
        UserDefaults.standard.set(true, forKey: back ? "isd.camera.backOn" : "isd.camera.frontOn")
        mainIsFront = !back
        // No zoom work here (v18): the popped-up camera's device
        // still holds its own factor, so it comes up big already
        // framed the way the operator left it.
    }

    /// Switches the back camera between its wide lens (1x) and its
    /// ultra-wide lens (0.5x). A lens change rebuilds the session, so
    /// this restarts the cameras; never call it mid-take.
    func setBackUltraWide(_ ultraWide: Bool) {
        guard !isRecording else { return }
        guard ultraWide != backIsUltraWide else { return }
        backIsUltraWide = ultraWide
        UserDefaults.standard.set(ultraWide, forKey: "isd.camera.backUltraWide")
        // No zoom reset (v18): setDisplayZoom stores the NEW lens's
        // factor before switching, and the rebuilt session applies
        // it — the old reset to 1.0 was what slammed the framing
        // tight after every lens change.
        if multiCamActive {
            restartDual()
        }
    }

    // MARK: - Per-camera on/off

    /// Turns one camera's preview, movie and photo connections off
    /// or on, live, mid-take. If the main camera goes off, the other
    /// one becomes main at once. The caller guards the last camera
    /// (see CameraViewModel.toggleCamera) — this only applies.
    func setCameraOn(back: Bool, on: Bool) {
        guard multiCamActive else { return }
        sessionQueue.async { [weak self] in
            guard let self else { return }
            let preview = back ? self.backPreviewConnection : self.frontPreviewConnection
            let movie = back ? self.backMovieConnection : self.frontMovieConnection
            let photo = back ? self.backPhotoConnection : self.frontPhotoConnection
            let outer = back ? self.outerBackConnection : self.outerFrontConnection
            preview?.isEnabled = on
            movie?.isEnabled = on
            photo?.isEnabled = on
            outer?.isEnabled = on
            DispatchQueue.main.async {
                if back { self.backCameraOn = on } else { self.frontCameraOn = on }
                UserDefaults.standard.set(on, forKey: back ? "isd.camera.backOn" : "isd.camera.frontOn")
                let mainTurnedOff = !on && ((back && !self.mainIsFront) || (!back && self.mainIsFront))
                if mainTurnedOff { self.mainIsFront.toggle() }
            }
        }
    }

    /// Rebuilds the dual session from scratch — the recovery when a
    /// camera comes up black or a connection stalls. Safe to call
    /// while not recording; the caller guards that.
    func restartDual() {
        stopDual { [weak self] in
            guard let self else { return }
            // No zoom reset (v18): each camera's factor is stored
            // per camera and startDual re-applies it, so a restart
            // keeps the framing the operator chose.
            self.startDual { }
        }
    }

    // MARK: - Zoom + torch

    /// The one zoom control (v18): a DISPLAY zoom, 0.5x to 5x,
    /// that pinch and the pill both drive. Display zoom is what the
    /// operator thinks in; the mapping to hardware is: the front
    /// camera has one lens, so display is its digital factor; the
    /// back camera has two lenses — below 1x lives on the
    /// ultra-wide lens (factor = display x 2, so 0.5x is factor 1),
    /// 1x and above on the wide lens (factor = display). Crossing
    /// 1x switches lenses through setBackUltraWide (a session
    /// rebuild), except mid-take: while recording the lens never
    /// changes and the display zoom clamps to what the current lens
    /// can reach. `smoothly` ramps the change (the pill's steps);
    /// pinch passes false and sets the factor directly, which is
    /// smooth because pinch events arrive continuously.
    func setDisplayZoom(_ display: CGFloat, smoothly: Bool = false) {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if self.mainIsFront {
                guard let device = self.frontDevice else { return }
                let maxZoom = min(device.activeFormat.videoMaxZoomFactor, 5.0)
                let clamped = min(max(1.0, display), maxZoom)
                self.storedFrontZoomFactor = clamped
                self.applyZoom(clamped, to: device, smoothly: smoothly)
                DispatchQueue.main.async { self.frontZoomFactor = clamped }
                return
            }
            guard let device = self.backDevice else { return }
            let deviceMax = device.activeFormat.videoMaxZoomFactor
            let wantsUltraWide = display < 1.0
            if wantsUltraWide == self.backIsUltraWide {
                // Already on the right lens: a plain factor change.
                let factor = self.backIsUltraWide ? display * 2 : display
                let cap = self.backIsUltraWide ? min(deviceMax, 10.0) : min(deviceMax, 5.0)
                let clamped = min(max(1.0, factor), cap)
                self.storedBackZoomFactor = clamped
                self.applyZoom(clamped, to: device, smoothly: smoothly)
                DispatchQueue.main.async { self.backZoomFactor = clamped }
                return
            }
            if self.isRecording {
                // No lens change mid-take: clamp the display zoom
                // to this lens's reach and apply it here.
                let reachable = self.backIsUltraWide
                    ? min(max(0.5, display), min(deviceMax * 0.5, 5.0))
                    : min(max(1.0, display), min(deviceMax, 5.0))
                let factor = self.backIsUltraWide ? reachable * 2 : reachable
                let clamped = min(max(1.0, factor), deviceMax)
                self.storedBackZoomFactor = clamped
                self.applyZoom(clamped, to: device, smoothly: smoothly)
                DispatchQueue.main.async { self.backZoomFactor = clamped }
                return
            }
            // Cross to the other lens. The new lens's factor is
            // stored FIRST, so the rebuilt session comes up already
            // framed (startDual applies the stored factors); the
            // switch itself rides the existing rebuild path.
            let factor = wantsUltraWide ? display * 2 : display
            let clamped = min(max(1.0, factor), wantsUltraWide ? 10.0 : 5.0)
            self.storedBackZoomFactor = clamped
            DispatchQueue.main.async {
                self.backZoomFactor = clamped
                self.setBackUltraWide(wantsUltraWide)
            }
        }
    }

    /// Applies one lens factor to one device: a ramp for the pill's
    /// steps, or a direct set for pinch (cancelling any ramp still
    /// in flight so the picture tracks the fingers).
    private func applyZoom(_ factor: CGFloat, to device: AVCaptureDevice, smoothly: Bool) {
        do {
            try device.lockForConfiguration()
            if smoothly {
                device.ramp(toVideoZoomFactor: factor, withRate: 6.0)
            } else {
                device.cancelVideoZoomRamp()
                device.videoZoomFactor = factor
            }
            device.unlockForConfiguration()
        } catch { return }
    }

    /// Re-applies each camera's stored zoom factor to its device —
    /// the step startDual takes once a rebuilt session is running,
    /// so RESTART and lens changes restore the operator's framing
    /// instead of resetting both cameras to 1x.
    private func applyStoredZoomFactors() {
        if let device = backDevice {
            let cap = backIsUltraWide
                ? device.activeFormat.videoMaxZoomFactor
                : min(device.activeFormat.videoMaxZoomFactor, 5.0)
            let clamped = min(max(1.0, storedBackZoomFactor), cap)
            storedBackZoomFactor = clamped
            applyZoom(clamped, to: device, smoothly: false)
            DispatchQueue.main.async { self.backZoomFactor = clamped }
        }
        if let device = frontDevice {
            let cap = min(device.activeFormat.videoMaxZoomFactor, 5.0)
            let clamped = min(max(1.0, storedFrontZoomFactor), cap)
            storedFrontZoomFactor = clamped
            applyZoom(clamped, to: device, smoothly: false)
            DispatchQueue.main.async { self.frontZoomFactor = clamped }
        }
    }

    /// The rear torch, so LIGHT brightens the scene the back camera
    /// sees as well as glowing the screen for the front camera.
    func setTorch(_ on: Bool) {
        sessionQueue.async { [weak self] in
            guard let self, let device = self.backDevice, device.hasTorch else { return }
            do {
                try device.lockForConfiguration()
                device.torchMode = on ? .on : .off
                device.unlockForConfiguration()
            } catch { return }
        }
    }

    // MARK: - Photo

    /// A still from whichever camera is main right now.
    func capturePhoto(completion: @escaping (Data?) -> Void) {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            self.photoCompletion = completion
            // Never fire a capture on a dead or rebuilding session —
            // a photo taken while the cameras are restarting must
            // just do nothing, never crash.
            guard self.multiCamActive, let session = self.duoSession, session.isRunning else {
                self.finishPhoto(nil)
                return
            }
            let settings = AVCapturePhotoSettings()
            settings.photoQualityPrioritization = .quality
            let output: AVCapturePhotoOutput? = self.mainIsFront ? self.duoFrontPhotoOutput : self.duoBackPhotoOutput
            guard let output else {
                self.finishPhoto(nil)
                return
            }
            output.capturePhoto(with: settings, delegate: self)
        }
    }

    private func finishPhoto(_ data: Data?) {
        guard let completion = photoCompletion else { return }
        photoCompletion = nil
        DispatchQueue.main.async { completion(data) }
    }

    // MARK: - Video

    /// Starts recording on both cameras at once. The files land in the
    /// temporary directory; the caller merges them on stop.
    func startRecording() {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if self.multiCamActive {
                // An off camera never starts — and stop never waits
                // for it. At least one camera is always on.
                self.duoBackRecording = self.backCameraOn && self.duoBackMovieOutput != nil
                self.duoFrontRecording = self.frontCameraOn && self.duoFrontMovieOutput != nil
                self.duoBackDone = !self.duoBackRecording
                self.duoFrontDone = !self.duoFrontRecording
                self.duoBackURL = nil
                self.duoFrontURL = nil
                // v17: remember the exact files handed to the
                // outputs, and reset the per-take diagnostics, so a
                // stop that hears nothing back can still rescue a
                // take from disk — and say why when it cannot.
                self.duoBackFileURL = nil
                self.duoFrontFileURL = nil
                self.duoBackDidStart = false
                self.duoFrontDidStart = false
                self.duoRecordingErrorCode = nil
                if self.duoBackRecording, let back = self.duoBackMovieOutput {
                    let url = self.temporaryURL(prefix: "isd-duo-back")
                    self.duoBackFileURL = url
                    back.startRecording(to: url, recordingDelegate: self)
                }
                if self.duoFrontRecording, let front = self.duoFrontMovieOutput {
                    let url = self.temporaryURL(prefix: "isd-duo-front")
                    self.duoFrontFileURL = url
                    front.startRecording(to: url, recordingDelegate: self)
                }
            }
        }
    }

    /// Stops recording. The completion runs on the main queue with the
    /// back camera's file first and the front camera's second.
    func stopRecording(completion: @escaping (URL?, URL?) -> Void) {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if self.multiCamActive {
                self.duoStopCompletion = completion
                self.duoBackDone = !self.duoBackRecording
                self.duoFrontDone = !self.duoFrontRecording
                if self.duoBackRecording { self.duoBackMovieOutput?.stopRecording() }
                if self.duoFrontRecording { self.duoFrontMovieOutput?.stopRecording() }
                if self.duoBackDone && self.duoFrontDone {
                    self.finishDuoStop()
                }
                // Safety: if a file output never calls back (a stalled
                // connection), do not hang the take forever. At 5s,
                // finish with whatever files arrived — but if NOTHING
                // arrived yet, give the outputs until 10s before
                // giving up, so a slow finalize cannot eat a good
                // take. finishDuoStop is a no-op once it has already
                // run, so this cannot fire the completion twice.
                self.sessionQueue.asyncAfter(deadline: .now() + 5.0) { [weak self] in
                    guard let self else { return }
                    if self.duoBackURL != nil || self.duoFrontURL != nil {
                        self.finishDuoStop()
                    } else {
                        self.sessionQueue.asyncAfter(deadline: .now() + 5.0) { [weak self] in
                            self?.finishDuoStop()
                        }
                    }
                }
            } else {
                DispatchQueue.main.async { completion(nil, nil) }
            }
        }
    }

    /// True when a file exists at the URL and holds at least one
    /// byte — the on-disk test that rescues a take whose delegate
    /// callback misfired or reported an error anyway (v17).
    private func fileHasContent(_ url: URL) -> Bool {
        guard let size = try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? NSNumber else {
            return false
        }
        return size.intValue > 0
    }

    private func finishDuoStop() {
        guard let completion = duoStopCompletion else { return }
        duoStopCompletion = nil
        var back = duoBackURL
        var front = duoFrontURL
        // v17 disk rescue: a camera whose delegate never delivered
        // a URL may still have written its file. Check the exact
        // path it was handed at record start before giving up.
        if back == nil, let file = duoBackFileURL, fileHasContent(file) {
            cameraLog.info("Stop rescued the back camera's file from disk")
            back = file
        }
        if front == nil, let file = duoFrontFileURL, fileHasContent(file) {
            cameraLog.info("Stop rescued the front camera's file from disk")
            front = file
        }
        // When nothing was delivered, compose the plain-words
        // reason from what the take actually did, so the toast can
        // say why instead of only that it failed.
        var reason: String? = nil
        if back == nil && front == nil {
            if let code = duoRecordingErrorCode {
                reason = "the camera reported an error (\(code))"
            } else if !duoBackDidStart && !duoFrontDidStart {
                reason = "the cameras never started recording"
            }
        }
        let backFile = back
        let frontFile = front
        DispatchQueue.main.async {
            self.lastRecordingError = reason
            completion(backFile, frontFile)
        }
    }

    private func temporaryURL(prefix: String) -> URL {
        FileManager.default.temporaryDirectory
            .appendingPathComponent("\(prefix)-\(UUID().uuidString).mov")
    }
}

extension CameraService: AVCapturePhotoCaptureDelegate {
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        finishPhoto(error == nil ? photo.fileDataRepresentation() : nil)
    }
}

extension CameraService: AVCaptureFileOutputRecordingDelegate {
    func fileOutput(_ output: AVCaptureFileOutput, didStartRecordingTo fileURL: URL, from connections: [AVCaptureConnection]) {
        // v17: remember that this output really started, so a stop
        // that delivers nothing can tell "never started" apart from
        // "started but wrote nothing".
        if output === duoBackMovieOutput {
            duoBackDidStart = true
        } else if output === duoFrontMovieOutput {
            duoFrontDidStart = true
        }
        DispatchQueue.main.async { self.isRecording = true }
    }

    func fileOutput(_ output: AVCaptureFileOutput, didFinishRecordingTo outputFileURL: URL, from connections: [AVCaptureConnection], error: Error?) {
        guard output === duoBackMovieOutput || output === duoFrontMovieOutput else { return }
        // Whether the take already closed before this file arrived
        // (the stop safety fired first). Read before setting the
        // URL, so a file that lands after the close is recognised
        // as late instead of being silently dropped.
        let wasAlreadyClosed = duoStopCompletion == nil
        // v17: never throw the error away unread, and never let an
        // error discard a file that is actually on disk — several
        // AVFoundation errors still leave a complete, usable movie.
        var deliveredURL: URL? = outputFileURL
        if let error {
            let nsError = error as NSError
            cameraLog.error("Recording finished with error \(nsError.domain) (\(nsError.code)): \(nsError.localizedDescription)")
            duoRecordingErrorCode = "\(nsError.domain) \(nsError.code)"
            if !fileHasContent(outputFileURL) {
                deliveredURL = nil
            }
        }
        if output === duoBackMovieOutput {
            duoBackURL = deliveredURL
            duoBackDone = true
        } else {
            duoFrontURL = deliveredURL
            duoFrontDone = true
        }
        if duoBackDone && duoFrontDone {
            DispatchQueue.main.async { self.isRecording = false }
            finishDuoStop()
        }
        // The take already closed before this file arrived: save it
        // straight away instead of dropping it. A take is never
        // silently lost.
        if let deliveredURL, wasAlreadyClosed, let save = onLateRecordingFile {
            save(deliveredURL)
        }
    }
}
