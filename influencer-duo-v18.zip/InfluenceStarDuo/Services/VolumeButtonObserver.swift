import AVFoundation
import Foundation
import MediaPlayer
import UIKit

/// Turns the hardware volume buttons into a record start/stop switch.
/// This is the only way the operator can start or stop a take while
/// the phone is flipped around facing the talent — they are behind the
/// phone and cannot reach the screen.
///
/// How it works: a hidden MPVolumeView keeps the system volume slider
/// in the view hierarchy, and this object watches
/// AVAudioSession.outputVolume with KVO. A volume-button press moves
/// the volume; the observer sees the move, puts the volume straight
/// back where it was, and calls the handler instead. The phone's
/// volume never actually changes.
///
/// Only active while the Camera screen is on screen (the view model
/// starts and stops it with the view's lifecycle). iOS gives apps no
/// direct volume-button event, so this is the documented workaround;
/// it works while the capture session has the audio session active.
final class VolumeButtonObserver: NSObject {
    /// Called on the main queue for every volume-button press.
    var onPress: (() -> Void)?

    private var volumeView: MPVolumeView?
    private var observedVolume: Float = 0.5
    private var observing = false
    private var resetting = false

    func start() {
        guard !observing else { return }
        observing = true
        // The volume view must be in a window to receive the hardware
        // buttons; it is invisible and takes no space.
        let view = MPVolumeView(frame: CGRect(x: -100, y: -100, width: 1, height: 1))
        view.alpha = 0.01
        view.isUserInteractionEnabled = false
        if let window = UIApplication.shared.connectedScenes
            .compactMap({ $0 as? UIWindowScene })
            .flatMap({ $0.windows })
            .first(where: { $0.isKeyWindow }) {
            window.addSubview(view)
        }
        volumeView = view
        observedVolume = AVAudioSession.sharedInstance().outputVolume
        AVAudioSession.sharedInstance().addObserver(
            self, forKeyPath: "outputVolume", options: [.new], context: nil)
    }

    func stop() {
        guard observing else { return }
        observing = false
        AVAudioSession.sharedInstance().removeObserver(self, forKeyPath: "outputVolume")
        volumeView?.removeFromSuperview()
        volumeView = nil
    }

    override func observeValue(forKeyPath keyPath: String?,
                               of object: Any?,
                               change: [NSKeyValueChangeKey: Any]?,
                               context: UnsafeMutableRawPointer?) {
        guard keyPath == "outputVolume", !resetting else { return }
        let newVolume = AVAudioSession.sharedInstance().outputVolume
        // A press moved the volume: put it back, then fire the handler.
        resetting = true
        setVolume(observedVolume)
        resetting = false
        DispatchQueue.main.async { [weak self] in
            self?.onPress?()
        }
        _ = newVolume
    }

    /// Moves the system volume slider back without flashing the HUD.
    private func setVolume(_ value: Float) {
        guard let slider = volumeView?.subviews
            .compactMap({ $0 as? UISlider }).first else { return }
        slider.setValue(value, animated: false)
    }
}
