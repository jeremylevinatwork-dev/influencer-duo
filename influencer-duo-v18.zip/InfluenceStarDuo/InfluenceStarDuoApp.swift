import SwiftUI

/// Influencer Dúo — the app entry. Everything is wired here, once:
/// the camera service, the on-device library and outbox, the account
/// store, the network monitor, the subscription and the Pro-request
/// store, and the view models that sit on them.
///
/// There is no login wall and no setup before first record: the app
/// opens straight onto the Camera tab.
@main
struct InfluenceStarDuoApp: App {
    @StateObject private var camera: CameraService
    @StateObject private var library: LibraryStore
    @StateObject private var outbox: OutboxStore
    @StateObject private var accounts: AccountStore
    @StateObject private var network: NetworkMonitor
    @StateObject private var subscription: SubscriptionService
    @StateObject private var proRequests: ProRequestStore
    @StateObject private var posting: PostingService
    @StateObject private var cameraVM: CameraViewModel
    @StateObject private var libraryVM: LibraryViewModel
    @StateObject private var accountsVM: AccountsViewModel

    init() {
        let camera = CameraService()
        let library = LibraryStore()
        let outbox = OutboxStore()
        let accounts = AccountStore()
        let network = NetworkMonitor()
        let subscription = SubscriptionService()
        let proRequests = ProRequestStore()
        let posting = PostingService(accounts: accounts, outbox: outbox, library: library, subscription: subscription)
        let cameraVM = CameraViewModel(camera: camera, library: library, posting: posting, network: network, subscription: subscription, accounts: accounts)
        let libraryVM = LibraryViewModel(library: library, outbox: outbox, accounts: accounts, posting: posting, subscription: subscription)
        let accountsVM = AccountsViewModel(accounts: accounts)

        _camera = StateObject(wrappedValue: camera)
        _library = StateObject(wrappedValue: library)
        _outbox = StateObject(wrappedValue: outbox)
        _accounts = StateObject(wrappedValue: accounts)
        _network = StateObject(wrappedValue: network)
        _subscription = StateObject(wrappedValue: subscription)
        _proRequests = StateObject(wrappedValue: proRequests)
        _posting = StateObject(wrappedValue: posting)
        _cameraVM = StateObject(wrappedValue: cameraVM)
        _libraryVM = StateObject(wrappedValue: libraryVM)
        _accountsVM = StateObject(wrappedValue: accountsVM)
    }

    var body: some Scene {
        WindowGroup {
            RootView(
                camera: camera,
                cameraVM: cameraVM,
                libraryVM: libraryVM,
                accountsVM: accountsVM,
                subscription: subscription,
                proRequests: proRequests,
                network: network,
                posting: posting
            )
        }
    }
}
