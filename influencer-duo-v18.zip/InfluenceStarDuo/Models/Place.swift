import Foundation

/// A place the app checked into: where the phone was when the take was
/// filmed. The name and address come from Apple's free reverse-geocode
/// (no key, no account); the Google rating only exists when Jeremy has
/// set a Google Places API key (see GooglePlacesConfig) and Google
/// actually returned a rating for this place. A rating is never
/// invented — when Google has nothing, `googleRating` stays nil.
///
/// The influencer's own quick take is a separate thing from Google's
/// rating: `userStars` (1–5) and `userVerdict` (one line, their words)
/// are what the influencer thought of the place. The card, the chip,
/// the burn-in and the post caption all show Google's rating and the
/// influencer's take side by side, never mixed up.
struct Place: Codable, Equatable {
    var name: String
    var address: String
    var latitude: Double
    var longitude: Double
    /// Google's star rating for this place (1.0–5.0). Nil when no key
    /// is set or Google had no rating for it.
    var googleRating: Double?
    /// How many Google reviews that rating is based on.
    var googleRatingCount: Int?
    /// The influencer's quick take: 1–5 stars. Nil = they didn't rate it.
    var userStars: Int?
    /// The influencer's one-line verdict, their words. Nil/empty = none.
    var userVerdict: String?

    init(name: String,
         address: String,
         latitude: Double,
         longitude: Double,
         googleRating: Double? = nil,
         googleRatingCount: Int? = nil,
         userStars: Int? = nil,
         userVerdict: String? = nil) {
        self.name = name
        self.address = address
        self.latitude = latitude
        self.longitude = longitude
        self.googleRating = googleRating
        self.googleRatingCount = googleRatingCount
        self.userStars = userStars
        self.userVerdict = userVerdict
    }

    /// The influencer's stars as filled + empty stars, e.g. "★★★★☆".
    /// Nil when they didn't rate the place.
    var userStarString: String? {
        guard let stars = userStars, (1...5).contains(stars) else { return nil }
        return String(repeating: "★", count: stars) + String(repeating: "☆", count: 5 - stars)
    }

    /// Google's rating as one line, e.g. "★ 4.6 · 12,345 reviews on
    /// Google". Nil when there is no Google rating for this place.
    var googleLine: String? {
        guard let rating = googleRating else { return nil }
        let formatted = String(format: "%.1f", rating)
        if let count = googleRatingCount, count > 0 {
            return "★ \(formatted) · \(count.formatted()) reviews on Google"
        }
        return "★ \(formatted) on Google"
    }

    /// The line that goes into the auto-post caption. Google's rating
    /// and the influencer's take are kept apart: Google's first, then
    /// the influencer's stars and one-liner, e.g.
    /// "📍 Universal Orlando · ★ 4.6 on Google — ★★★★★ "Best rides in Florida""
    /// With no Google rating and a full quick review it reads exactly
    /// "📍 Universal Orlando — ★★★★★ "Best rides in Florida"".
    var captionLine: String {
        var line = "📍 \(name)"
        if let google = googleLine {
            line += " · \(google)"
        }
        if let stars = userStarString {
            line += " — \(stars)"
        }
        if let verdict = userVerdict?.trimmingCharacters(in: .whitespacesAndNewlines), !verdict.isEmpty {
            line += " \"\(verdict)\""
        }
        return line
    }
}

/// One stretch of a recording during which a place was checked in —
/// from the moment the operator attached it to the moment they removed
/// it (or the take ended). The place is snapshotted at finish time, so
/// a review edited mid-take is what the finished video shows for the
/// whole stretch it was on screen.
struct LocationEvent: Codable, Equatable {
    var start: TimeInterval
    var end: TimeInterval
    var place: Place
}
