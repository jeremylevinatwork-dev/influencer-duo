import Foundation

/// A social account the user connected for auto-posting. Access tokens
/// are NEVER stored here — they live in the Keychain, keyed by the
/// account id (see AccountStore). This record is only the display facts.
struct SocialAccount: Identifiable, Codable, Equatable {
    enum Platform: String, Codable {
        /// A Facebook Page (auto-post works). A personal Facebook
        /// profile is deliberately not a case here: Meta removed
        /// profile auto-posting, and the app must never pretend it works.
        case facebookPage
        /// An Instagram Business/Creator account, reached through its
        /// linked Facebook Page's token.
        case instagram
        /// A TikTok account, reached through TikTok Login Kit. Videos
        /// auto-post through the Content Posting API; TikTok's API has
        /// no photo direct-post, so photos go via the share sheet.
        case tiktok
    }

    var id: UUID
    var platform: Platform
    /// Page name, or the Instagram @username.
    var displayName: String
    /// The Facebook Page id, or the Instagram user id, on Meta's side.
    var remoteID: String
    /// For Instagram: the Facebook Page id it hangs off. Nil for Pages.
    var pageID: String?
    var autoPost: Bool
    var connectedAt: Date
    /// True when Meta rejected the stored token (code 190): the account
    /// stays listed, but posting pauses until the user reconnects.
    var needsReconnect: Bool

    var platformLabel: String {
        switch platform {
        case .facebookPage: return "Facebook Page"
        case .instagram: return "Instagram"
        case .tiktok: return "TikTok"
        }
    }

    /// The short, honest note the Accounts screen shows under each
    /// platform, so nobody is surprised by what auto-post can do.
    var platformNote: String {
        switch platform {
        case .facebookPage:
            return "Posts to your Facebook Page. Personal Facebook profiles can't be auto-posted — Meta removed that — use Share for those."
        case .instagram:
            return "Posts Reels to your Instagram Business or Creator account. Photos go via Share."
        case .tiktok:
            return "Posts videos to your TikTok account. TikTok's API can't post photos — those go via Share."
        }
    }

    init(id: UUID = UUID(),
         platform: Platform,
         displayName: String,
         remoteID: String,
         pageID: String? = nil,
         autoPost: Bool = true,
         connectedAt: Date = Date(),
         needsReconnect: Bool = false) {
        self.id = id
        self.platform = platform
        self.displayName = displayName
        self.remoteID = remoteID
        self.pageID = pageID
        self.autoPost = autoPost
        self.connectedAt = connectedAt
        self.needsReconnect = needsReconnect
    }
}
