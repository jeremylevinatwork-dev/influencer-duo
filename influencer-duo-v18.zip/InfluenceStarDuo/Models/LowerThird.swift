import Foundation

/// The lower third the creator fires live while filming: a name line
/// and a title line. It shows on screen the moment it is fired, and it
/// is burned into the finished video only for the stretches where it
/// was on air.
struct LowerThird: Codable, Equatable {
    var name: String
    var title: String

    var isEmpty: Bool {
        name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            && title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
}

/// One stretch of a recording during which the lower third was on air,
/// measured in seconds from the start of the recording. The name and
/// title are snapshotted at fire time, so the burned video shows
/// exactly what the operator fired, even if they retype it later.
struct LowerThirdEvent: Codable, Equatable {
    var start: TimeInterval
    var end: TimeInterval
    var name: String
    var title: String

    init(start: TimeInterval, end: TimeInterval, name: String = "", title: String = "") {
        self.start = start
        self.end = end
        self.name = name
        self.title = title
    }
}

/// One stretch during which a free-text caption overlay was on air.
/// The operator types it mid-take and fires it with one tap; it is
/// burned into the video only while it was showing.
struct CaptionEvent: Codable, Equatable {
    var start: TimeInterval
    var end: TimeInterval
    var text: String
}

/// One stretch during which a link chip was on air. The URL is also
/// kept on the finished MediaItem so auto-posts can put it in the
/// post text (see MediaItem.link).
struct LinkEvent: Codable, Equatable {
    var start: TimeInterval
    var end: TimeInterval
    var url: String
}

/// One stretch during which a picked picture was on screen as an
/// overlay (a logo, a product photo, whatever the operator chose).
/// `rect` is normalized to the frame, origin top-left (the way the
/// operator sees it on screen): x/y/width/height as 0...1 fractions.
/// The image itself is held in memory for the take — a finished take
/// is finalized before the app can lose it.
struct ImageOverlayEvent: Codable, Equatable {
    var id: UUID
    var start: TimeInterval
    var end: TimeInterval
    var rect: CGRect

    init(id: UUID = UUID(), start: TimeInterval, end: TimeInterval, rect: CGRect) {
        self.id = id
        self.start = start
        self.end = end
        self.rect = rect
    }
}
