import Foundation

/// One auto-post waiting in the outbox. Jobs are persisted (outbox.json)
/// so a post survives the app being closed, the phone restarting, and
/// long stretches offline — it uploads when the phone is back online,
/// and it is never silently dropped.
struct PostJob: Identifiable, Codable, Equatable {
    enum State: String, Codable {
        /// Waiting for a connection (or for its turn).
        case queued
        /// An upload is in flight right now.
        case uploading
        /// Meta accepted the post.
        case posted
        /// Gave up after 5 tries, or hit a problem that retrying will
        /// not fix (for example a disconnected account). The Library
        /// shows the reason and offers Retry.
        case failed
    }

    enum Platform: String, Codable {
        case facebook
        case instagram
        case tiktok
    }

    var id: UUID
    var mediaItemID: UUID
    var accountID: UUID
    var platform: Platform
    var state: State
    var attempts: Int
    /// The last failure, in plain words, for the Library to show.
    var lastError: String?
    var createdAt: Date
    var updatedAt: Date

    init(id: UUID = UUID(),
         mediaItemID: UUID,
         accountID: UUID,
         platform: Platform,
         state: State = .queued,
         attempts: Int = 0,
         lastError: String? = nil,
         createdAt: Date = Date(),
         updatedAt: Date = Date()) {
        self.id = id
        self.mediaItemID = mediaItemID
        self.accountID = accountID
        self.platform = platform
        self.state = state
        self.attempts = attempts
        self.lastError = lastError
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
}
