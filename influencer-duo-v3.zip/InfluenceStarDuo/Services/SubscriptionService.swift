import Foundation
import StoreKit

/// The one place the subscription is defined. The product itself is
/// created by Jeremy in App Store Connect — the code only knows its
/// id. No App Store Connect credentials exist anywhere in this app.
enum SubscriptionConfig {
    /// Auto-renewable monthly subscription, created in App Store
    /// Connect (with a 5-day free trial as its introductory offer).
    static let productID = "com.jhnlsecuritytech.influencestar.monthly"
    /// The price shown on the paywall before the live product loads
    /// (offline, or before Jeremy creates the product). Jeremy can
    /// change the real price in App Store Connect; this is only the
    /// fallback text. Keep it in this one place.
    static let fallbackPriceDisplay = "$9.99"
    /// The free trial length, in days. The trial itself is the
    /// introductory offer on the product in App Store Connect; this
    /// number is only the fallback text on the paywall.
    static let trialDays = 5
}

/// The subscription state machine (StoreKit 2). One source of truth
/// for whether Pro features are unlocked, and the only place that
/// talks to the App Store.
///
/// Deliberately NOT @MainActor: the posting service checks `isPro`
/// from its background upload tasks. Published state is always
/// mutated on the main queue inside (see `refreshEntitlements`,
/// `loadProduct`, `purchase`, `restore`).
///
/// What Pro unlocks: auto-post to Facebook / Instagram / TikTok,
/// live-edit overlays (lower thirds, captions, links, pictures) and
/// the flip talent-monitor mode. Without Pro, the camera, recording
/// and photos still work — anyone can try the app — and nothing ever
/// locks a user out of videos they already recorded.
///
/// States, all handled here:
/// - subscribed: paid and current.
/// - trial: inside the 5-day introductory offer.
/// - comped: free Pro from an offer code Jeremy issued (or a
///   promotional offer). An offer-code redemption IS a subscription
///   transaction — it shows up in current entitlements exactly like
///   a paid one, so comped users get the full unlock and never see a
///   paywall.
/// - expired / cancelled: the entitlement ended (or was revoked).
///   Pro features lock again, but recorded videos stay in the Library.
/// - restore: `AppStore.sync()` re-reads purchases from Apple.
final class SubscriptionService: ObservableObject {
    enum AccessState: Equatable {
        /// No current entitlement.
        case none
        /// Inside the free trial; `until` is when it ends.
        case trial(until: Date)
        /// Paid and current; `until` is the next renewal date.
        case subscribed(until: Date)
        /// Free Pro from an offer code (or promotional offer).
        case comped(until: Date)
        /// Had access, now ended.
        case expired
    }

    @Published private(set) var state: AccessState = .none
    /// The live product from the App Store, once it loads.
    @Published private(set) var product: Product?
    /// A purchase or restore is in flight.
    @Published private(set) var isBusy = false
    /// The last plain-words problem, for the paywall to show.
    @Published var errorMessage: String?

    /// Full unlock: subscribed, in trial, or comped. Everything
    /// gated on Pro checks this one flag.
    var isPro: Bool {
        switch state {
        case .trial, .subscribed, .comped:
            return true
        case .none, .expired:
            return false
        }
    }

    /// The price on the paywall: the live App Store price when the
    /// product has loaded, the single fallback value otherwise.
    var priceDisplay: String {
        product?.displayPrice ?? SubscriptionConfig.fallbackPriceDisplay
    }

    /// The trial wording on the paywall: from the live product's
    /// introductory offer when there is one, the fallback otherwise.
    var trialDisplay: String {
        if let offer = product?.subscription?.introductoryOffer,
           offer.paymentMode == .freeTrial {
            let period = offer.period.unit
            let count = offer.period.value
            guard count > 0 else { return "\(SubscriptionConfig.trialDays)-day free trial" }
            let unit: String
            switch period {
            case .day: unit = count == 1 ? "day" : "days"
            case .week: unit = count == 1 ? "week" : "weeks"
            case .month: unit = count == 1 ? "month" : "months"
            case .year: unit = count == 1 ? "year" : "years"
            @unknown default: unit = "days"
            }
            return "\(count)-\(unit) free trial"
        }
        return "\(SubscriptionConfig.trialDays)-day free trial"
    }

    /// One line for the paywall and Accounts: what the user has, in
    /// plain words.
    var statusText: String {
        switch state {
        case .none:
            return "Not subscribed"
        case .trial(let until):
            return "Free trial until \(Self.shortDate(until))"
        case .subscribed(let until):
            return "Subscribed — renews \(Self.shortDate(until))"
        case .comped(let until):
            return "Pro — free access until \(Self.shortDate(until))"
        case .expired:
            return "Subscription ended"
        }
    }

    private var transactionListener: Task<Void, Never>?

    init() {
        transactionListener = Task { [weak self] in
            for await result in Transaction.updates {
                guard let self else { return }
                if case .verified(let transaction) = result {
                    await transaction.finish()
                }
                await self.refreshEntitlements()
            }
        }
    }

    deinit {
        transactionListener?.cancel()
    }

    // MARK: - Loading

    /// Fetches the product and the current entitlement. Called on
    /// launch and after every purchase, restore or redeem.
    func refresh() async {
        await loadProduct()
        await refreshEntitlements()
    }

    private func loadProduct() async {
        do {
            let products = try await Product.products(for: [SubscriptionConfig.productID])
            let loaded = products.first
            await MainActor.run { self.product = loaded }
        } catch {
            // Offline, or Jeremy hasn't created the product yet. The
            // paywall still works off the fallback price; buying waits
            // until the product loads.
            await MainActor.run { self.product = nil }
        }
    }

    /// Reads the current entitlements from Apple and sets the state.
    /// An unverified transaction never grants access.
    func refreshEntitlements() async {
        var found: AccessState = .none
        var hadAny = false
        for await result in Transaction.currentEntitlements {
            guard case .verified(let transaction) = result,
                  transaction.productID == SubscriptionConfig.productID,
                  transaction.revocationDate == nil else { continue }
            hadAny = true
            guard let expiry = transaction.expirationDate, expiry > Date() else { continue }
            switch transaction.offerType {
            case .introductory:
                found = .trial(until: expiry)
            case .code, .promotional:
                found = .comped(until: expiry)
            default:
                found = .subscribed(until: expiry)
            }
            break
        }
        if found == .none, hadAny {
            // There was an entitlement, but it has run out.
            await MainActor.run { self.state = .expired }
        } else {
            await MainActor.run { self.state = found }
        }
    }

    // MARK: - Buying, restoring, redeeming

    /// Starts the App Store purchase sheet. The 5-day trial is the
    /// product's introductory offer in App Store Connect, so an
    /// eligible buyer gets it automatically. Returns true when the
    /// purchase (or trial start) completed.
    func purchase() async -> Bool {
        guard let product else {
            await MainActor.run {
                self.errorMessage = "The subscription isn't available right now — check your connection, or ask Jeremy whether the product is set up in App Store Connect yet."
            }
            return false
        }
        await MainActor.run { self.isBusy = true }
        defer { Task { await MainActor.run { self.isBusy = false } } }
        do {
            let result = try await product.purchase()
            switch result {
            case .success(let verification):
                guard case .verified(let transaction) = verification else {
                    await MainActor.run {
                        self.errorMessage = "Apple couldn't verify the purchase. Try again."
                    }
                    return false
                }
                await transaction.finish()
                await refreshEntitlements()
                return isPro
            case .userCancelled:
                return false
            case .pending:
                await MainActor.run {
                    self.errorMessage = "The purchase is waiting for approval (for example, a parent's approval). It will unlock when Apple confirms it."
                }
                return false
            @unknown default:
                return false
            }
        } catch {
            await MainActor.run {
                self.errorMessage = "The purchase didn't go through: \(error.localizedDescription)"
            }
            return false
        }
    }

    /// Re-reads purchases from Apple (for a new phone, or a
    /// subscription bought elsewhere). Never grants anything by
    /// itself — it just refreshes the entitlements above.
    func restore() async -> Bool {
        await MainActor.run { self.isBusy = true }
        defer { Task { await MainActor.run { self.isBusy = false } } }
        do {
            try await AppStore.sync()
        } catch {
            await MainActor.run {
                self.errorMessage = "Couldn't reach the App Store to restore. Check your connection and try again."
            }
            return false
        }
        await refreshEntitlements()
        if !isPro {
            await MainActor.run {
                self.errorMessage = "Nothing to restore — no subscription was found on this Apple ID."
            }
        }
        return isPro
    }

    /// Opens Apple's offer-code sheet, where the influencer types the
    /// code Jeremy gave them. A redeemed code grants the subscription
    /// exactly like a purchase — it lands in current entitlements
    /// with offer type `.code`, and the state machine calls it comped.
    func presentOfferCodeRedeemSheet() {
        Task { @MainActor in
            AppStore.presentOfferCodeRedeemSheet()
            // The sheet returns no result; re-check entitlements
            // when the user comes back to the paywall.
            try? await Task.sleep(nanoseconds: 1_000_000_000)
            await refreshEntitlements()
        }
    }

    /// Opens Apple's subscription management, so the user can change
    /// or cancel from the one place Apple allows.
    func manageSubscription() {
        guard let scene = UIApplication.shared.connectedScenes
            .compactMap({ $0 as? UIWindowScene }).first else { return }
        Task { @MainActor in
            do {
                try await AppStore.showManageSubscriptions(in: scene)
            } catch {
                // The sheet is best-effort; the user can also cancel
                // from Settings. Nothing here needs a retry.
            }
            await refreshEntitlements()
        }
    }

    private static func shortDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        return formatter.string(from: date)
    }
}
