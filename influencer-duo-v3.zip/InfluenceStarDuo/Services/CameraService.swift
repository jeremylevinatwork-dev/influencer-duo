import AVFoundation
import Foundation

/// Owns the capture hardware and nothing else. It runs the back and
/// front cameras at the same time (AVCaptureMultiCamSession) — the
/// whole point of this app. Built for iPhone 15 Pro and up (iOS 17+),
/// every one of which runs multi-cam. If multi-cam is ever unavailable
/// on a device, there is no fallback: `configure()` sets a plain-words
/// status message instead, and the Camera screen shows it.
/// The UI never touches AVFoundation directly — it reads @Published
/// state and calls the plain methods below.
///
/// Design notes, learned from the platform:
/// - The front camera's preview is mirrored so the talent monitor
///   reads like a mirror; the recorded front file is true-to-life.
/// - Rotation comes from AVCaptureDevice.RotationCoordinator (iOS 17+),
///   which keeps preview and captures horizon-level; the manual
///   ROTATE offset sits on top of it and is remembered between launches.
final class CameraService: NSObject, ObservableObject {
    // MARK: - Published state (always set on the main queue)

    @Published private(set) var isRunning = false
    @Published private(set) var isRecording = false
    @Published private(set) var multiCamActive = false
    /// Which camera the UI treats as main. SWAP flips it; the other
    /// camera rides picture-in-picture.
    @Published private(set) var mainIsFront = false
    /// Plain-words status for the screen (permission problems, no
    /// camera, and so on). Nil when everything is fine.
    @Published private(set) var statusMessage: String?

    /// Preview layers the UI embeds. `backLayer` is the scene and
    /// `frontLayer` is the influencer; which one is main is
    /// `mainIsFront`.
    @Published private(set) var backLayer: AVCaptureVideoPreviewLayer?
    @Published private(set) var frontLayer: AVCaptureVideoPreviewLayer?

    /// Manual rotation correction in degrees (0/90/180/270), added on
    /// top of the coordinator's horizon-level angle and remembered.
    @Published var rotationOffset: CGFloat = CGFloat(UserDefaults.standard.double(forKey: "isd.camera.rotationOffset")) {
        didSet {
            UserDefaults.standard.set(rotationOffset, forKey: "isd.camera.rotationOffset")
            applyCurrentAngles()
        }
    }

    var multiCamSupported: Bool { AVCaptureMultiCamSession.isMultiCamSupported }

    // MARK: - Private state

    private let sessionQueue = DispatchQueue(label: "com.jhnlsecuritytech.influencestar.camera")

    private var duoSession: AVCaptureMultiCamSession?
    private var started = false

    private var backDevice: AVCaptureDevice?
    private var frontDevice: AVCaptureDevice?

    private var duoBackPhotoOutput: AVCapturePhotoOutput?
    private var duoFrontPhotoOutput: AVCapturePhotoOutput?
    private var duoBackMovieOutput: AVCaptureMovieFileOutput?
    private var duoFrontMovieOutput: AVCaptureMovieFileOutput?

    private var backCoordinator: AVCaptureDevice.RotationCoordinator?
    private var frontCoordinator: AVCaptureDevice.RotationCoordinator?
    private var backPreviewObservation: NSKeyValueObservation?
    private var frontPreviewObservation: NSKeyValueObservation?

    /// Connections that need the rotation angle re-applied.
    private var backPreviewConnection: AVCaptureConnection?
    private var frontPreviewConnection: AVCaptureConnection?
    private var backMovieConnection: AVCaptureConnection?
    private var frontMovieConnection: AVCaptureConnection?
    private var backPhotoConnection: AVCaptureConnection?
    private var frontPhotoConnection: AVCaptureConnection?

    private var photoCompletion: ((Data?) -> Void)?
    private var duoStopCompletion: ((URL?, URL?) -> Void)?
    private var duoBackURL: URL?
    private var duoFrontURL: URL?
    private var duoBackDone = false
    private var duoFrontDone = false

    override init() {
        super.init()
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(sessionInterruptedEnded),
            name: .AVCaptureSessionInterruptionEnded,
            object: nil)
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(sessionRuntimeError),
            name: .AVCaptureSessionRuntimeError,
            object: nil)
    }

    // MARK: - Startup

    func start() {
        guard !started else { return }
        started = true
        AVCaptureDevice.requestAccess(for: .video) { [weak self] videoOK in
            guard let self else { return }
            AVCaptureDevice.requestAccess(for: .audio) { _ in
                guard videoOK else {
                    DispatchQueue.main.async {
                        self.statusMessage = "Camera access is off — turn it on in Settings to film."
                    }
                    return
                }
                self.sessionQueue.async { self.configure() }
            }
        }
    }

    /// Another app can take the camera and stop a session; when it lets
    /// go, start again instead of staying black.
    func resumeIfNeeded() {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if self.multiCamActive, let session = self.duoSession, !session.isRunning {
                session.startRunning()
            }
        }
    }

    @objc private func sessionInterruptedEnded(_ note: Notification) {
        resumeIfNeeded()
    }

    @objc private func sessionRuntimeError(_ note: Notification) {
        resumeIfNeeded()
    }

    private func configure() {
        if multiCamSupported {
            configureDuo()
        } else {
            // No fallback: this app is built for iPhone 15 Pro and up,
            // and every one of those runs multi-cam. Say so plainly.
            DispatchQueue.main.async {
                self.statusMessage = "This iPhone can't run both cameras at once, so dual recording isn't available. Influencer Dúo needs an iPhone 15 Pro or newer."
            }
        }
    }

    // MARK: - Dual camera

    private struct DuoWiring {
        var backPhotoOutput: AVCapturePhotoOutput?
        var frontPhotoOutput: AVCapturePhotoOutput?
        var backMovieOutput: AVCaptureMovieFileOutput?
        var frontMovieOutput: AVCaptureMovieFileOutput?
        var backPhotoConnection: AVCaptureConnection?
        var frontPhotoConnection: AVCaptureConnection?
        var backMovieConnection: AVCaptureConnection?
        var frontMovieConnection: AVCaptureConnection?
    }

    /// Starts the dual session: back and front cameras at the same time,
    /// each with its own preview layer, and hands both layers back on the
    /// main queue. Nil layers mean the device refused — the caller shows
    /// the plain-words status message.
    func startDual(completion: @escaping (AVCaptureVideoPreviewLayer?, AVCaptureVideoPreviewLayer?) -> Void) {
        guard multiCamSupported else {
            DispatchQueue.main.async {
                self.statusMessage = "This iPhone can't run both cameras at once, so dual recording isn't available. Influencer Dúo needs an iPhone 15 Pro or newer."
            }
            completion(nil, nil)
            return
        }
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if self.multiCamActive {
                let back = self.backLayer
                let front = self.frontLayer
                DispatchQueue.main.async { completion(back, front) }
                return
            }
            let session = AVCaptureMultiCamSession()
            session.beginConfiguration()
            guard let backDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
                  let backInput = try? AVCaptureDeviceInput(device: backDevice),
                  session.canAddInput(backInput),
                  let frontDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front),
                  let frontInput = try? AVCaptureDeviceInput(device: frontDevice),
                  session.canAddInput(frontInput) else {
                session.commitConfiguration()
                DispatchQueue.main.async {
                    self.statusMessage = "This iPhone can't run both cameras at once, so dual recording isn't available. Influencer Dúo needs an iPhone 15 Pro or newer."
                    completion(nil, nil)
                }
                return
            }
            session.addInputWithNoConnections(backInput)
            session.addInputWithNoConnections(frontInput)

            let backLayer = AVCaptureVideoPreviewLayer(sessionWithNoConnection: session)
            backLayer.videoGravity = .resizeAspectFill
            let frontLayer = AVCaptureVideoPreviewLayer(sessionWithNoConnection: session)
            frontLayer.videoGravity = .resizeAspectFill
            guard let backPort = backInput.ports(for: .video, sourceDeviceType: backDevice.deviceType, sourceDevicePosition: backDevice.position).first,
                  let frontPort = frontInput.ports(for: .video, sourceDeviceType: frontDevice.deviceType, sourceDevicePosition: frontDevice.position).first else {
                session.commitConfiguration()
                DispatchQueue.main.async { completion(nil, nil) }
                return
            }
            let backConnection = AVCaptureConnection(inputPort: backPort, videoPreviewLayer: backLayer)
            let frontConnection = AVCaptureConnection(inputPort: frontPort, videoPreviewLayer: frontLayer)
            frontConnection.automaticallyAdjustsVideoMirroring = false
            frontConnection.isVideoMirrored = true
            guard session.canAddConnection(backConnection), session.canAddConnection(frontConnection) else {
                session.commitConfiguration()
                DispatchQueue.main.async { completion(nil, nil) }
                return
            }
            session.addConnection(backConnection)
            session.addConnection(frontConnection)

            let wiring = self.wireDuoOutputs(session: session, backPort: backPort, frontPort: frontPort)
            session.commitConfiguration()

            self.duoSession = session
            self.backDevice = backDevice
            self.frontDevice = frontDevice
            self.backPreviewConnection = backConnection
            self.frontPreviewConnection = frontConnection
            self.backMovieConnection = wiring.backMovieConnection
            self.frontMovieConnection = wiring.frontMovieConnection
            self.backPhotoConnection = wiring.backPhotoConnection
            self.frontPhotoConnection = wiring.frontPhotoConnection
            self.duoBackPhotoOutput = wiring.backPhotoOutput
            self.duoFrontPhotoOutput = wiring.frontPhotoOutput
            self.duoBackMovieOutput = wiring.backMovieOutput
            self.duoFrontMovieOutput = wiring.frontMovieOutput
            self.makeDuoCoordinators(backLayer: backLayer, frontLayer: frontLayer)
            session.startRunning()
            DispatchQueue.main.async {
                self.multiCamActive = true
                self.backLayer = backLayer
                self.frontLayer = frontLayer
                self.isRunning = true
                self.statusMessage = nil
                completion(backLayer, frontLayer)
            }
        }
    }

    /// Stops the dual session.
    func stopDual(completion: (() -> Void)? = nil) {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if self.multiCamActive {
                self.duoSession?.stopRunning()
                self.duoSession = nil
                self.backDevice = nil
                self.frontDevice = nil
                self.backCoordinator = nil
                self.frontCoordinator = nil
                self.backPreviewObservation = nil
                self.frontPreviewObservation = nil
                self.backPreviewConnection = nil
                self.frontPreviewConnection = nil
                self.backMovieConnection = nil
                self.frontMovieConnection = nil
                self.backPhotoConnection = nil
                self.frontPhotoConnection = nil
                self.duoBackPhotoOutput = nil
                self.duoFrontPhotoOutput = nil
                self.duoBackMovieOutput = nil
                self.duoFrontMovieOutput = nil
                self.duoStopCompletion = nil
                DispatchQueue.main.async {
                    self.backLayer = nil
                    self.frontLayer = nil
                    self.multiCamActive = false
                    self.mainIsFront = false
                }
            }
            if let completion { DispatchQueue.main.async(execute: completion) }
        }
    }

    /// The capture outputs on the dual session: a photo output on each
    /// camera (so a still always comes from whichever camera is main)
    /// and a movie output on each camera. Sound rides in the back
    /// camera's file, when the device allows a mic alongside two
    /// cameras.
    private func wireDuoOutputs(session: AVCaptureMultiCamSession,
                                backPort: AVCaptureInput.Port,
                                frontPort: AVCaptureInput.Port) -> DuoWiring {
        var wiring = DuoWiring()
        let backPhoto = AVCapturePhotoOutput()
        if session.canAddOutput(backPhoto) {
            session.addOutputWithNoConnections(backPhoto)
            let connection = AVCaptureConnection(inputPorts: [backPort], output: backPhoto)
            if session.canAddConnection(connection) {
                session.addConnection(connection)
                wiring.backPhotoOutput = backPhoto
                wiring.backPhotoConnection = connection
            }
        }
        let frontPhoto = AVCapturePhotoOutput()
        if session.canAddOutput(frontPhoto) {
            session.addOutputWithNoConnections(frontPhoto)
            let connection = AVCaptureConnection(inputPorts: [frontPort], output: frontPhoto)
            // The saved still is true-to-life, not mirrored: only the
            // on-screen preview is mirrored, so the talent monitor
            // reads like a mirror while the file stays honest.
            connection.automaticallyAdjustsVideoMirroring = false
            connection.isVideoMirrored = false
            if session.canAddConnection(connection) {
                session.addConnection(connection)
                wiring.frontPhotoOutput = frontPhoto
                wiring.frontPhotoConnection = connection
            }
        }
        let backMovie = AVCaptureMovieFileOutput()
        if session.canAddOutput(backMovie) {
            session.addOutputWithNoConnections(backMovie)
            let connection = AVCaptureConnection(inputPorts: [backPort], output: backMovie)
            if session.canAddConnection(connection) {
                session.addConnection(connection)
                wiring.backMovieOutput = backMovie
                wiring.backMovieConnection = connection
            }
        }
        let frontMovie = AVCaptureMovieFileOutput()
        if session.canAddOutput(frontMovie) {
            session.addOutputWithNoConnections(frontMovie)
            let connection = AVCaptureConnection(inputPorts: [frontPort], output: frontMovie)
            // Recorded file is true-to-life, not mirrored — only the
            // preview is mirrored, so the talent monitor reads like a
            // mirror while the finished video stays honest.
            connection.automaticallyAdjustsVideoMirroring = false
            connection.isVideoMirrored = false
            if session.canAddConnection(connection) {
                session.addConnection(connection)
                wiring.frontMovieOutput = frontMovie
                wiring.frontMovieConnection = connection
            }
        }
        if let backMovie = wiring.backMovieOutput,
           let mic = AVCaptureDevice.default(for: .audio),
           let micInput = try? AVCaptureDeviceInput(device: mic),
           session.canAddInput(micInput) {
            session.addInputWithNoConnections(micInput)
            if let micPort = micInput.ports(for: .audio, sourceDeviceType: mic.deviceType, sourceDevicePosition: .unspecified).first {
                let audioConnection = AVCaptureConnection(inputPorts: [micPort], output: backMovie)
                if session.canAddConnection(audioConnection) {
                    session.addConnection(audioConnection)
                }
            }
        }
        return wiring
    }

    private func makeDuoCoordinators(backLayer: AVCaptureVideoPreviewLayer, frontLayer: AVCaptureVideoPreviewLayer) {
        if let device = backDevice {
            let coordinator = AVCaptureDevice.RotationCoordinator(device: device, previewLayer: backLayer)
            backCoordinator = coordinator
            backPreviewObservation = coordinator.observe(
                \.videoRotationAngleForHorizonLevelPreview,
                options: [.initial, .new]) { [weak self] coordinator, change in
                    guard let self, let rawAngle = change.newValue else { return }
                    self.applyAngle(rawAngle, to: self.backPreviewConnection)
                    let captureAngle = coordinator.videoRotationAngleForHorizonLevelCapture
                    self.applyAngle(captureAngle, to: self.backMovieConnection)
                    self.applyAngle(captureAngle, to: self.backPhotoConnection)
                }
        }
        if let device = frontDevice {
            let coordinator = AVCaptureDevice.RotationCoordinator(device: device, previewLayer: frontLayer)
            frontCoordinator = coordinator
            frontPreviewObservation = coordinator.observe(
                \.videoRotationAngleForHorizonLevelPreview,
                options: [.initial, .new]) { [weak self] coordinator, change in
                    guard let self, let rawAngle = change.newValue else { return }
                    self.applyAngle(rawAngle, to: self.frontPreviewConnection)
                    let captureAngle = coordinator.videoRotationAngleForHorizonLevelCapture
                    self.applyAngle(captureAngle, to: self.frontMovieConnection)
                    self.applyAngle(captureAngle, to: self.frontPhotoConnection)
                }
        }
        // Apply the current angles right away — do not wait for the
        // phone to move before the pictures sit the right way up.
        applyCurrentAngles()
    }

    // MARK: - Rotation

    private func effectiveAngle(_ angle: CGFloat) -> CGFloat {
        var result = (angle + rotationOffset).truncatingRemainder(dividingBy: 360)
        if result < 0 { result += 360 }
        return result
    }

    private func applyAngle(_ angle: CGFloat, to connection: AVCaptureConnection?) {
        guard let connection else { return }
        let effective = effectiveAngle(angle)
        guard connection.isVideoRotationAngleSupported(effective) else { return }
        connection.videoRotationAngle = effective
    }

    private func applyCurrentAngles() {
        if let coordinator = backCoordinator {
            applyAngle(coordinator.videoRotationAngleForHorizonLevelPreview, to: backPreviewConnection)
            applyAngle(coordinator.videoRotationAngleForHorizonLevelCapture, to: backMovieConnection)
            applyAngle(coordinator.videoRotationAngleForHorizonLevelCapture, to: backPhotoConnection)
        }
        if let coordinator = frontCoordinator {
            applyAngle(coordinator.videoRotationAngleForHorizonLevelPreview, to: frontPreviewConnection)
            applyAngle(coordinator.videoRotationAngleForHorizonLevelCapture, to: frontMovieConnection)
            applyAngle(coordinator.videoRotationAngleForHorizonLevelCapture, to: frontPhotoConnection)
        }
    }

    /// One tap = 90 degrees more correction, everywhere at once. The
    /// new offset is remembered for the next launch.
    func rotateBy90() {
        var next = rotationOffset + 90
        next = next.truncatingRemainder(dividingBy: 360)
        if next < 0 { next += 360 }
        rotationOffset = next
    }

    // MARK: - Main / PiP swap

    /// Trades which dual camera is main and which rides
    /// picture-in-picture. Pure state — no session reconfiguration.
    func swapMainCamera() {
        guard multiCamActive else { return }
        DispatchQueue.main.async { self.mainIsFront.toggle() }
    }

    // MARK: - Photo

    /// A still from whichever camera is main right now.
    func capturePhoto(completion: @escaping (Data?) -> Void) {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            self.photoCompletion = completion
            let settings = AVCapturePhotoSettings()
            settings.photoQualityPrioritization = .quality
            let output: AVCapturePhotoOutput? = self.mainIsFront ? self.duoFrontPhotoOutput : self.duoBackPhotoOutput
            guard let output else {
                self.finishPhoto(nil)
                return
            }
            output.capturePhoto(with: settings, delegate: self)
        }
    }

    private func finishPhoto(_ data: Data?) {
        guard let completion = photoCompletion else { return }
        photoCompletion = nil
        DispatchQueue.main.async { completion(data) }
    }

    // MARK: - Video

    /// Starts recording on both cameras at once. The files land in the
    /// temporary directory; the caller merges them on stop.
    func startRecording() {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if self.multiCamActive {
                guard let back = self.duoBackMovieOutput, let front = self.duoFrontMovieOutput else { return }
                self.duoBackDone = false
                self.duoFrontDone = false
                self.duoBackURL = nil
                self.duoFrontURL = nil
                back.startRecording(to: self.temporaryURL(prefix: "isd-duo-back"), recordingDelegate: self)
                front.startRecording(to: self.temporaryURL(prefix: "isd-duo-front"), recordingDelegate: self)
            }
        }
    }

    /// Stops recording. The completion runs on the main queue with the
    /// back camera's file first and the front camera's second.
    func stopRecording(completion: @escaping (URL?, URL?) -> Void) {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if self.multiCamActive {
                self.duoStopCompletion = completion
                self.duoBackDone = self.duoBackMovieOutput == nil
                self.duoFrontDone = self.duoFrontMovieOutput == nil
                self.duoBackMovieOutput?.stopRecording()
                self.duoFrontMovieOutput?.stopRecording()
                if self.duoBackDone && self.duoFrontDone {
                    self.finishDuoStop()
                }
            } else {
                DispatchQueue.main.async { completion(nil, nil) }
            }
        }
    }

    private func finishDuoStop() {
        guard let completion = duoStopCompletion else { return }
        duoStopCompletion = nil
        let back = duoBackURL
        let front = duoFrontURL
        DispatchQueue.main.async { completion(back, front) }
    }

    private func temporaryURL(prefix: String) -> URL {
        FileManager.default.temporaryDirectory
            .appendingPathComponent("\(prefix)-\(UUID().uuidString).mov")
    }
}

extension CameraService: AVCapturePhotoCaptureDelegate {
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        finishPhoto(error == nil ? photo.fileDataRepresentation() : nil)
    }
}

extension CameraService: AVCaptureFileOutputRecordingDelegate {
    func fileOutput(_ output: AVCaptureFileOutput, didStartRecordingTo fileURL: URL, from connections: [AVCaptureConnection]) {
        DispatchQueue.main.async { self.isRecording = true }
    }

    func fileOutput(_ output: AVCaptureFileOutput, didFinishRecordingTo outputFileURL: URL, from connections: [AVCaptureConnection], error: Error?) {
        guard output === duoBackMovieOutput || output === duoFrontMovieOutput else { return }
        if output === duoBackMovieOutput {
            duoBackURL = error == nil ? outputFileURL : nil
            duoBackDone = true
        } else {
            duoFrontURL = error == nil ? outputFileURL : nil
            duoFrontDone = true
        }
        if duoBackDone && duoFrontDone {
            DispatchQueue.main.async { self.isRecording = false }
            finishDuoStop()
        }
    }
}
