import AVFoundation
import SwiftUI

/// Embeds a camera preview in SwiftUI — the Apple Way, as in
/// Apple's own AVMultiCamPiP sample.
///
/// The preview layer IS the view's backing layer (`layerClass`),
/// not a standalone layer pasted into a plain view. A standalone
/// sublayer keeps whatever frame it was last given: if its host view
/// is zero-sized when the layer is attached, or layout never
/// re-fires after the layer arrives, the layer stays zero-sized and
/// black — while another preview that does have an explicit frame
/// (the PiP) works fine. That is exactly the v7 bug Jeremy's
/// screenshots showed (both cameras live in the PiP, main black for
/// either one). With `layerClass` the layer can never be a
/// different size from its view, and there is no add-sublayer or
/// frame-sync step to go stale. No explicit frame, no re-attach.
///
/// The view owns its layer; the camera service only connects it to
/// a camera port. The view registers its layer under its role when
/// made, rebinds it when the role changes (SWAP), and unregisters
/// it when it goes away.
struct CameraPreviewView: UIViewRepresentable {
    /// Which camera this view shows. The main view's role flips on
    /// SWAP; the layer is rebound to the other camera's port.
    enum Role { case back, front, outerBack, outerFront }

    let role: Role
    @ObservedObject var camera: CameraService

    func makeCoordinator() -> Coordinator {
        Coordinator(camera: camera)
    }

    func makeUIView(context: Context) -> PreviewView {
        let view = PreviewView()
        view.previewLayer.videoGravity = .resizeAspectFill
        camera.registerPreviewLayer(view.previewLayer, role: role)
        return view
    }

    func updateUIView(_ uiView: PreviewView, context: Context) {
        // The layer IS the view: nothing to sync, nothing to
        // re-attach. If the role changed since this view was made
        // (SWAP), rebind the layer to the other camera's port.
        camera.rebindPreviewLayerIfNeeded(uiView.previewLayer, role: role)
    }

    static func dismantleUIView(_ uiView: PreviewView, coordinator: Coordinator) {
        coordinator.camera.unregisterPreviewLayer(uiView.previewLayer)
    }

    final class Coordinator {
        let camera: CameraService
        init(camera: CameraService) { self.camera = camera }
    }

    /// A view whose backing layer presents the camera's video.
    final class PreviewView: UIView {
        override class var layerClass: AnyClass {
            AVCaptureVideoPreviewLayer.self
        }

        var previewLayer: AVCaptureVideoPreviewLayer {
            layer as! AVCaptureVideoPreviewLayer
        }
    }
}
